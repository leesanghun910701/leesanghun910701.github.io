﻿using System;
using System.IO;

namespace sbdd
{
    public class ClassRawFile
    {

        public static void SaveRawFile(RAWfile CS, string RawFileName, string TopName)
        {
            using(BinaryWriter ofd = new BinaryWriter(File.Open(RawFileName, FileMode.Create)))
            {
                short ID;
                int EventNum, CutsetNum, ElementNum, EventIndex;
                float EventProb;
                double TopProb;
                char BlockType;
                string BlockName, EventName;
                                
                ID = 20301;
                ofd.Write(ID);

                #region write data block

                BlockType = 'd';
                BlockName = new string(' ', 32);
                EventNum = CS.XData.NumOfEvent;
                ofd.Write(BlockType);
                WriteStr(ofd, BlockName);
                ofd.Write(EventNum);

                for (int i = 0; i < EventNum; i++)
                {
                    EventProb = CS.XData.EventProb[i];                    
                    EventName = CheckEvtNameLength(CS.XData.EventName[i]);
                    ofd.Write(EventProb);
                    WriteStr(ofd, EventName);
                }
                EventProb = 0.0f;
                ofd.Write(EventProb);

                #endregion

                #region write cutset block

                BlockType = '-';
                BlockName = CheckEvtNameLength(TopName);
                CutsetNum = CS.XCutset.NumOfCutSet;
                ofd.Write(BlockType);
                WriteStr(ofd, BlockName);
                ofd.Write(CutsetNum);
                TopProb = 0.0;
                for (int i = 0; i < CutsetNum; i++)
                {
                    float CutsetProb = CS.XCutset.XaCutSet[i].CutProba;
                    ElementNum = CS.XCutset.XaCutSet[i].NoElem;
                    ofd.Write(CutsetProb);
                    ofd.Write(ElementNum);

                    for (int j = 0; j < ElementNum; j++)
                    {
                        EventIndex = CS.XCutset.XaCutSet[i].Elems[j];
                        ofd.Write(EventIndex);
                    }
                    TopProb += CutsetProb;
                }

                ofd.Write(TopProb);

                #endregion

                ofd.Close();
            }
        }

        public static string CheckEvtNameLength(string EventName)
        {
            if (EventName.Length > 32) return EventName.Substring(0, 32);
            else return EventName.PadRight(32, ' ');
        }
        
        public static void WriteStr(BinaryWriter file, string str)
        {
            char[] arr = str.ToCharArray(0, 32);
            foreach (char c in arr) file.Write(c);
        }
        
        public static void WriteLogFile()
        {
            StreamWriter strWriter;
            
            
            strWriter = new StreamWriter(new FileStream(Constants.LogFilePath, FileMode.Append));
            strWriter.Write(sbdd.RstTxt);
            sbdd.RstTxt = String.Empty;

            strWriter.Close();
        }

    }
}
