#pragma once

#include "GeoPoint.h"
#include <cmath>

class GeoTrans
{

public:
	int GEO;// = 0;
	int KATEC;// = 1;
	int TM;// = 2;
	int GRS80;// = 3;
	int UTMK;// = 4;
	GeoTrans();
	~GeoTrans();

	long double m_arFalseNorthing[5];

private:
	long double EPSLN;
	long double M_PI;
	long double m_Ind[5];
	long double m_Es[5];
	long double m_Esp[5];
	long double src_m[5];
	long double dst_m[5];

	long double m_arMajor[5];
	long double m_arMinor[5];
	long double m_arLonCenter[5];
	long double m_arLatCenter[5];


	long double m_arScaleFactor[5];

	long double m_arFalseEasting[5];

	long double datum_params[3];
	//long double datum_params_ForGRS[3];





	double D2R(double degree);
	double R2D(double radian);
	double e0fn(double x);
	double e1fn(double x);
	double e2fn(double x);
	double e3fn(double x);
	double mlfn(double e0, double e1, double e2, double e3, double phi);
	double asinz(double value);

public:
	GeoPoint* convert(int srctype, int dsttype, GeoPoint* in_pt);

	void geo2tm(int dsttype, GeoPoint* in_pt, GeoPoint* out_pt);

	void tm2geo(int srctype, GeoPoint* in_pt, GeoPoint* out_pt);
	double getDistancebyGeo(GeoPoint* pt1, GeoPoint* pt2);
	double getDistancebyKatec(GeoPoint* pt1, GeoPoint* pt2);
	double getDistancebyTm(GeoPoint* pt1, GeoPoint* pt2);
	double getDistancebyUTMK(GeoPoint* pt1, GeoPoint* pt2);
	double getDistancebyGrs80(GeoPoint* pt1, GeoPoint* pt2);

private:
	long getTimebySec(double distance);

public:
	long getTimebyMin(double distance);

private:
	long double HALF_PI;
	long double COS_67P5; // cosine of 67.5 degrees
	long double AD_C;
	/* Toms region 1 constant */

	void transform(int srctype, int dsttype, GeoPoint* point);

	bool geodetic_to_geocentric(int type, GeoPoint* p);
	void geocentric_to_geodetic(int type, GeoPoint* p);
	void geocentric_to_wgs84(GeoPoint* p);
	void geocentric_from_wgs84(GeoPoint* p);

	//void geocentric_to_wgs84_ForGRS(GeoPoint* p);
	//void geocentric_from_wgs84_ForGRS(GeoPoint* p);

};