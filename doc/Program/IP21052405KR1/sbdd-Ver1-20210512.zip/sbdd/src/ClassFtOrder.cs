﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace sbdd
{
    class ClassFtOrder
    {

        public static List<int> SolveGateOrder;
        public static List<int> BEOrder;
        public static List<int> BEList;
        public static List<int> BEDepth;
        public static List<int> BEFreq;
        
        public static void DefineGateOrder(int GateIndex) 
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = ClassFtData.XEvent[GateIndex];

            #region order gates (bottom-up)

            if (Gate.Child.Count > 0)
            {
                for (int i = 0; i < Gate.Child.Count; i++)
                {
                    int ChildIndex = Gate.Child[i];
                    DefineGateOrder(ChildIndex);
                }
                if (SolveGateOrder.IndexOf(GateIndex) == -1) SolveGateOrder.Add(GateIndex);
            }

            #endregion

        }
        
        public static void DefineBEOrderTD(int EventIndex, int Depth)
        {

            int nOrder = 1;

            #region Order IE, Seq first

            for (int i = 0; i < ClassFtData.XEvent.Count; i++)
            {
                if (ClassFtData.XEvent[i].ie > 0) // 
                {
                    Event Event;
                    Event = ClassFtData.XEvent[i];
                    Event.BEOrder = nOrder++;
                    ClassFtData.XEvent[i] = Event;
                }
            }

            #endregion

            #region Find depth

            FindBEDepth(EventIndex, Depth);

            #endregion

            #region Order by depth (ascending)

            var joined = BEList.Zip(BEDepth, (n, a) => new { Name = n, Depth = a }).OrderBy(x => x.Depth);
            BEOrder = joined.Select(x => x.Name).ToList();

            for (int i = 0; i < BEOrder.Count; i++)
            {
                if (ClassFtData.XEvent[BEOrder[i]].ie == 0)
                {
                    Event Event;
                    Event = ClassFtData.XEvent[BEOrder[i]];
                    Event.BEOrder = nOrder++;
                    ClassFtData.XEvent[BEOrder[i]] = Event;
                }
            }

            #endregion

            BEOrder.Clear();
            BEList.Clear();
            BEDepth.Clear();
        }

        public static void DefineBEOrderBU(int EventIndex, int Depth)
        {
            int nOrder = 1;

            #region order IE, Seq first

            for (int i = 0; i < ClassFtData.XEvent.Count; i++)
            {
                if (ClassFtData.XEvent[i].ie > 0) // 
                {
                    Event Event;
                    Event = ClassFtData.XEvent[i];
                    Event.BEOrder = nOrder++;
                    ClassFtData.XEvent[i] = Event;
                }
            }

            #endregion

            #region Find depth

            FindBEDepth(EventIndex, Depth);

            #endregion

            #region Order by depth (descending)

            var joined = BEList.Zip(BEDepth, (n, a) => new { Name = n, Depth = a }).OrderByDescending(x => x.Depth);
            BEOrder = joined.Select(x => x.Name).ToList();

            for (int i = 0; i < BEOrder.Count; i++)
            {
                if (ClassFtData.XEvent[BEOrder[i]].ie == 0)
                {
                    Event Event;
                    Event = ClassFtData.XEvent[BEOrder[i]];
                    Event.BEOrder = nOrder++;
                    ClassFtData.XEvent[BEOrder[i]] = Event;
                }
            }

            #endregion

            BEOrder.Clear();
            BEList.Clear();
            BEDepth.Clear();
        }

        public static void DefineBEOrderMF(int EventIndex)
        {
            int nOrder = 1;

            #region Order IE, Seq first

            for (int i = 0; i < ClassFtData.XEvent.Count; i++)
            {
                if (ClassFtData.XEvent[i].ie > 0) // 
                {
                    Event Event;
                    Event = ClassFtData.XEvent[i];
                    Event.BEOrder = nOrder++;
                    ClassFtData.XEvent[i] = Event;
                }
            }

            #endregion

            #region find depth

            FindBEFreq(Math.Abs(EventIndex));

            #endregion

            #region order by depth (descending)

            var joined = BEList.Zip(BEFreq, (n, a) => new { Name = n, Freq = a }).OrderByDescending(x => x.Freq);
            BEOrder = joined.Select(x => x.Name).ToList();            

            for (int i = 0; i < BEOrder.Count; i++)
            {

                if (ClassFtData.XEvent[BEOrder[i]].ie == 0)
                {
                    Event Event;
                    Event = ClassFtData.XEvent[BEOrder[i]];
                    Event.BEOrder = nOrder++;
                    ClassFtData.XEvent[BEOrder[i]] = Event;
                }
            }

            #endregion

            BEOrder.Clear();
            BEList.Clear();
            BEFreq.Clear();
        }

        static void FindBEDepth(int EventIndex, int Depth)
        {
            EventIndex = Math.Abs(EventIndex);

            if (ClassFtData.XEvent[EventIndex].Child.Count > 0)
            {
                Depth++;
                for (int i = 0; i < ClassFtData.XEvent[EventIndex].Child.Count; i++)
                {
                    int ChildIndex = ClassFtData.XEvent[EventIndex].Child[i];
                    FindBEDepth(ChildIndex, Depth);
                }
            }
            else
            {
                if (BEList.IndexOf(EventIndex) == -1)
                {
                    BEList.Add(EventIndex);
                    BEDepth.Add(Depth);
                }
                else
                {
                    BEDepth[BEList.IndexOf(EventIndex)] = Math.Min(BEDepth[BEList.IndexOf(EventIndex)], Depth);
                }
            }
        }
        
        static void FindBEFreq(int EventIndex)
        {

            if (ClassFtData.XEvent[EventIndex].Child.Count > 0)
            {
                for (int i = 0; i < ClassFtData.XEvent[EventIndex].Child.Count; i++)
                {
                    int ChildIndex = ClassFtData.XEvent[EventIndex].Child[i];
                    FindBEFreq(Math.Abs(ChildIndex));
                }
            }
            else
            {
                if (BEList.IndexOf(EventIndex) == -1)
                {
                    BEList.Add(EventIndex);
                    BEFreq.Add(1);
                }
                else
                {
                    BEFreq[BEList.IndexOf(EventIndex)]++;
                }
            }
        }

    }
}
