﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace sbdd
{
    public class ClassFtData
    {
        public static List<Event> XEvent;
        public static List<NegGate> NegateBeRelationList;
        public static List<int> NegateBeIndexList;
        public static bool EventProbExceedOne;
        public static List<GateProbExceedOne> EventProbExceedOneList;
        public static float EventProbMax;
                       
        public static void ReadFT(sbdd form, string file)
        {
            StreamReader strReader = new StreamReader(file);

            sbdd.ReadFTTime = new Stopwatch();
            sbdd.ReadFTTime.Start();

            #region define TRUE/FALSE event
            // define FALSE event
            Event Event = new Event();
            Event.Name = "FALSE";
            Event.Type = 'B';
            Event.Prob = 0.0f;
            Event.Child = new List<int>();
            Event.BEOrder = 0;
            Event.ite = 0;
            XEvent.Add(Event);

            // define TRUE event
            Event = new Event();
            Event.Name = "TRUE";
            Event.Type = 'B';
            Event.Prob = 1.0f;
            Event.Child = new List<int>();
            Event.BEOrder = 0;
            Event.ite = 1;
            XEvent.Add(Event);
            #endregion

            #region read gate block

            ReadGateBlock(strReader);

            #endregion

            #region read data block

            ReadEventBlock(strReader);

            #endregion

            #region save negate gate relation

            CheckNegateBERelation();

            #endregion

            sbdd.ReadFTTime.Stop();

            form.txtboxCmd.AppendText("(" + sbdd.ReadFTTime.Elapsed.TotalSeconds + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += "(" + sbdd.ReadFTTime.Elapsed.TotalSeconds + "sec)" + Environment.NewLine;
            
            strReader.Close();
        }
        
        public static void LoadFT(string file)
        {
            string Line;
            string[] LineSplit;
            StreamReader strReader = new StreamReader(file);

            #region read TopName
            while (strReader.Peek() != -1)
            {
                Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;
                LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (String.Equals(LineSplit[0], "PROCESS")) // Top event
                {
                    sbdd.TopName = LineSplit[1];
                }
                if (String.Equals(Line, "IMPORT"))
                {
                    break;
                }
            }
            #endregion

            #region read cutoff value
            while (strReader.Peek() != -1)
            {
                Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;
                LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                if (String.Equals(LineSplit[0], "LIMIT"))
                {
                    Constants.Cutoff = Single.Parse(LineSplit[1]);
                    break;
                }                
            }
            #endregion

            strReader.Close();
        }
        
        public static void ReadGateBlock(StreamReader strReader)
        {
            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    if (String.Equals(Line, "ENDTREE")) break;
                    string[] LineSplit = Line.Split(new char[] {' ', '\t'}, StringSplitOptions.RemoveEmptyEntries);

                    // define gate index, type
                    int GateIndex = GetEventIndex(LineSplit[0]);
                    Event Event = XEvent[GateIndex];
                    Event.Type = Convert.ToChar(LineSplit[1]);
                    
                    // define gate child(s)                    
                    for (int j = 2; j < LineSplit.Length; j++)
                    {
                        int ChildIndex = GetEventIndex(LineSplit[j]);
                        Event.Child.Add(ChildIndex);
                    }
                    XEvent[GateIndex] = Event;
                }
            }
        }

        public static void ReadEventBlock(StreamReader strReader)
        {
            while (strReader.Peek() != -1)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (String.Equals(Line, "IMPORT"))
                {
                    break;
                }
            }

            while (strReader.Peek() != -1)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                string[] LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);                
                if (String.Equals(LineSplit[0], "LIMIT"))
                {
                    break;
                }

                float EventProb = Convert.ToSingle(LineSplit[0]);
                int EventIndex = GetEventIndex(LineSplit[1]);
                
                // define BE type, prob
                Event Event = XEvent[EventIndex];
                Event.Type = 'B';
                Event.Prob = EventProb;
                if (EventProb > 1.0f)
                {
                    GateProbExceedOne Gate = new GateProbExceedOne();
                    Gate.EventName = LineSplit[1];
                    Gate.EventProb = EventProb;
                    EventProbExceedOneList.Add(Gate);

                    EventProbExceedOne = true;
                    EventProbMax = Math.Max(EventProbMax, EventProb);
                }
                
                
                // check for Initiating events or Sequence events
                if (LineSplit.Length > 2)  
                {
                    if (LineSplit[2] == "I") Event.ie = 1;
                }
                if (LineSplit[1][0] == '#') Event.ie = 2;
                XEvent[EventIndex] = Event;
            }
            
        }
        
        public static void CheckNegateBERelation()
        {
            // check negate gate relations -> later used for checking non-sense cutsets
            for (int i = 0; i < ClassFtNegate.WriteNegateBEList.Count; i++)
            {
                string NegateBEName = ClassFtNegate.WriteNegateBEList[i];
                string OriginalBEName = NegateBEName.Substring(0, NegateBEName.Length - 4); // exclude "_NOT"
                
                NegGate NegateRelation;
                int EventIndex = GetEventIndex(OriginalBEName);
                int nEventIndex = GetEventIndex(NegateBEName);

                NegateRelation.oIndex = EventIndex;
                NegateRelation.nIndex = nEventIndex;

                NegateBeIndexList.Add(nEventIndex);
                NegateBeRelationList.Add(NegateRelation);
            }
        }

        public static int GetEventIndex(string EvtName)
        {
            int Negate = 1;
            
            if (String.Equals(EvtName.Substring(0, 1), "-"))
            {
                Negate = -1;
                EvtName = EvtName.Substring(1, EvtName.Length - 1);
            }
            
            int EventIndex = XEvent.FindIndex(xEvent => xEvent.Name == EvtName);
            // if old event, return index
            if (EventIndex > -1) 
            {
                return EventIndex * Negate;
            }
            // if new event, add to XEvent
            else
            {
                Event Event = new Event();
                Event.Name = EvtName;
                Event.Type = ' ';
                Event.Prob = 0.0f;
                Event.Child = new List<int>();
                Event.BEOrder = 0;
                Event.ite = 0;
                XEvent.Add(Event);

                return (XEvent.Count - 1) * Negate;
            }
        }

        public static bool isEventIE(int EventIndex)
        {
            if (XEvent[EventIndex].ie == 1) return true;
            else return false;
        }

        public static bool isEventSeq(int EventIndex)
        {
            if (XEvent[EventIndex].ie == 2) return true;
            else return false;
        }

        public static bool isEventFlag(int EventIndex)
        {
            string EventName = XEvent[EventIndex].Name;
            if (EventName == "TRUE" || EventName == "FALSE") return true;
            else return false;
        }

    }
}
