﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace sbdd
{
    class ClassFtRestruct
    {

        public static int nReduceGate;
        public static int nAbsorbGate;

        public static void CheckRestruct(sbdd form, int GateIndex)
        
        {
            #region reduce FT

            // reduce gate's childs if
            // 1) all childs have same types, 
            // 2) contains at least one same grandchild 
            
            //ReduceFT(GateIndex);

            //form.txtboxCmd.AppendText("(" + nReduceGate.ToString() + " gate(s) reduced, ");
            //sbdd.CmdTxt += "(" + nReduceGate.ToString() + " gate(s) reduced, ";

            #endregion

            #region absorb FT

            // absorb gate's grandchild if child has same type with gate

            AbsorbFT(GateIndex);
            RemoveDuplicateBEs(GateIndex); // remove duplicate BEs after absorption            

            form.txtboxCmd.AppendText(nAbsorbGate.ToString() + " gate(s) absorbed, ");
            sbdd.CmdTxt += nAbsorbGate.ToString() + " gate(s) absorbed, ";

            #endregion
        }

        public static char ReduceFT(int GateIndex) 
        {
            
            GateIndex = Math.Abs(GateIndex);
            Event Gate = ClassFtData.XEvent[GateIndex];
            char GateType = Gate.Type;
            List<int> ChildList = Gate.Child;

            if (ChildList.Count > 0)
            {
                List<int> oChildList = new List<int>(); // original child list

                #region derive intersecting grand childs

                int nReducableChild = 0;
                List<int> gChildIntersect = new List<int>();

                for (int i = 0; i < ChildList.Count; i++)
                {
                    int ChildIndex = Math.Abs(ChildList[i]);
                    Event Child = ClassFtData.XEvent[ChildIndex];
                    oChildList.Add(ChildIndex);
                    
                    // repeat for child(s)
                    char ChildType = ReduceFT(ChildIndex);

                    // define gChildIntersect
                    if ((GateType == '+' && ChildType == '*') || (GateType == '*' && ChildType == '+')) 
                    {
                        List<int> gChildList = Child.Child;
                        if (i == 0) gChildIntersect = gChildList;
                        else gChildIntersect = gChildIntersect.Intersect(gChildList).ToList();
                        nReducableChild++;
                    }
                }

                #endregion

                bool gChildIntersectNeg = CheckIntersect(gChildIntersect);

                if (nReducableChild > 1 && nReducableChild == ChildList.Count && gChildIntersect.Any() && !gChildIntersectNeg)
                {
                    #region remove gchild from child & add gchild to gate
                    
                    for (int i = 0; i < gChildIntersect.Count; i++)
                    {
                        #region remove gChildIntersect from child list of child gate

                        for (int j = 0; j < ChildList.Count; j++)
                        {
                            int ChildIndex = ChildList[j];
                            ClassFtData.XEvent[ChildIndex].Child.Remove(gChildIntersect[i]);
                        }
                        
                        #endregion

                        #region  add gChildIntersect to gate

                        Gate.Child.Add(gChildIntersect[i]);    
                        
                        #endregion
                    }

                    #endregion

                    #region define new gate and append to original gate

                    if (GateType == '+' || GateType == '*')
                    {
                        #region change original gate type

                        if (GateType == '+') Gate.Type = '*';
                        else if (GateType == '*') Gate.Type = '+';
                        ClassFtData.XEvent[GateIndex] = Gate;

                        #endregion

                        #region create new gate which contains other grand childs (except intersect grand childs)

                        Event NewGate = new Event();
                        NewGate.Name = Gate.Name + "_RED";

                        if (GateType == '+') NewGate.Type = '+';
                        else if (GateType == '*') NewGate.Type = '*';

                        // remove original childs from original gate & add original childs to new gate
                        NewGate.Child = new List<int>();
                        for (int i = 0; i < oChildList.Count; i++)
                        {
                            Gate.Child.Remove(oChildList[i]);
                            NewGate.Child.Add(oChildList[i]);
                        }

                        #endregion

                        #region add new gate to original gate

                        ClassFtData.XEvent.Add(NewGate);
                        Gate.Child.Add(ClassFtData.XEvent.Count - 1);

                        nReduceGate++;

                        #endregion
                    }

                    #endregion
                }
            }
            else
            {
                return 'B'; // if no child, basic event
            }
            return Gate.Type;
        }

        public static bool CheckIntersect(List<int> gChildIntersect)
        {
            for (int i = 0; i < gChildIntersect.Count; i++)
            {
                // if (ClassFtData.isEventIE(Math.Abs(gChildIntersect[i]))) return true;                
                if (gChildIntersect[i] < 0) return true;
            }
            return false;
        }

        public static char AbsorbIESeq(int GateIndex)
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = ClassFtData.XEvent[GateIndex];

            if (Gate.Child.Count > 0)
            {
                for (int i = 0; i < Gate.Child.Count; i++)
                {
                    int ChildIndex = ClassFtData.XEvent[GateIndex].Child[i];
                    int ChildSign = Math.Sign(ChildIndex);
                    Event Child = ClassFtData.XEvent[Math.Abs(ChildIndex)];
                    Child.Type = AbsorbIESeq(ChildIndex);
                    if (Child.Type == 'B') { }
                    else if (Gate.Type == Child.Type)
                    {
                        switch (Gate.Type)
                        {
                            // case '*':
                            case '+':
                                for (int j = 0; j < Child.Child.Count; j++)
                                {
                                    int gChildIndex = Child.Child[j];

                                    if (ClassFtData.isEventIE(Math.Abs(gChildIndex)) || ClassFtData.isEventSeq(Math.Abs(gChildIndex)))
                                    {
                                        Child.Child.Remove(gChildIndex); // child gate에서 해당 gchild를 없애고
                                        Gate.Child.Add(ChildSign * gChildIndex); // gate에 해당 gchild를 넣는다.
                                    }

                                }
                                break;
                            default:
                                break;
                        }
                    }

                }
            }
            else return 'B';
            return Gate.Type;
        }
        
        public static char AbsorbFT(int GateIndex)
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = ClassFtData.XEvent[GateIndex];
            List<int> ChildList = Gate.Child;

            if (ChildList.Count > 0)
            {
                for (int i = 0; i < ChildList.Count; i++)
                {
                    int ChildIndex = ClassFtData.XEvent[GateIndex].Child[i];
                    int ChildSign = Math.Sign(ChildIndex);
                    ChildIndex = Math.Abs(ChildIndex);
                    Event Child = ClassFtData.XEvent[ChildIndex];

                    // repeat for child(s)
                    Child.Type = AbsorbFT(ChildIndex);

                    #region if gate and child has same type, remove child from gate and add grandchilds to gate

                    if (Child.Type != 'B' && (Gate.Type == Child.Type))
                    {
                        switch (Gate.Type)
                        {
                            case '+':
                            case '*':

                                // remove child from original gate
                                ChildList.Remove(ChildIndex);
                                nAbsorbGate++;
                                i--;

                                // add grand childs to original gate
                                List<int> gChildList = Child.Child;
                                for (int j = 0; j < gChildList.Count; j++)
                                {                                    
                                    ChildList.Add(ChildSign * gChildList[j]);
                                }
                                i += gChildList.Count;

                                break;
                            default:
                                break;
                        }
                    }

                    #endregion
                }

            }
            else // if no child, basic event
            {
                return 'B'; 
            }
            return Gate.Type;
        }

        public static void RemoveDuplicateBEs(int GateIndex)
        {

            Event Gate = ClassFtData.XEvent[GateIndex];
            List<int> ChildList = Gate.Child;

            if (ChildList.Count > 0)
            {
                for (int i = 0; i < ChildList.Count; i++)
                {
                    int ChildIndex = Math.Abs(ChildList[i]);
                    RemoveDuplicateBEs(ChildIndex);
                }

                Event Event = Gate;
                Event.Child = ChildList.Distinct().ToList();
                ClassFtData.XEvent[GateIndex] = Event;
            }
            // if no child, basic event
            return;
        }
        
    }
}
