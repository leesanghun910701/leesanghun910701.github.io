﻿
// ShapeFiles2TxtDlg.h: 헤더 파일
//


#pragma once


#include "GeoTrans.h"
#include "GeoPoint.h"

// CShapeFiles2TxtDlg 대화 상자
class CShapeFiles2TxtDlg : public CDialogEx
{
// 생성입니다.
public:
	CShapeFiles2TxtDlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SHAPEFILES2TXT_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;
	BOOL openFolder(CString sPath);
	void moveTopFolder_ForSubFolder(CString sTopFolderPath, CString sNowFolderPath);
	void deleteTmpopyFile(CString sFolderPath);

	BOOL readRule();
	void init();

	CString m_sFolderPath;

	BOOL m_bSubFolder;
	int m_nCntFileList;		//작업 대상 파일 개수
	CString* m_saFileList;	//작업 대상 파일에서 추출한 주제 리스트
	CString* m_saFileList_Province;	//작업 대상 파일의 지역명칭 리스트
	CString getProvinceByFileName(CString sFileNM); //파일명에서 지역명칭 추출 함수
	CString getMegaNMByProvince(CString sProvince); //지역명에서 광역시 추출 함수
	CString getCtyNMByProvince(CString sProvince); //지역명에서 시군구 추출 함수

	int m_nRuleCnt;
	CString* m_saRuleList1;
	CString* m_saRuleList2;
	CString getCleanProvinceName(CString sProvinceName);

	//파일명 작성 규칙 등이 정상인지 점검
	BOOL checkFileNameRule();


	void changeTotalShpNM_to_NewTempNM_inFolder(CString sFolderPath, CString sNewNM);
	//작업 폴더 내 임시 shp 확장자 정상 shp 확장자로 변경
	void changeTotalFineShpNM(CString sFolderPath);

	



	CString m_saFieldList[100];
	int m_nCntFieldList;
	int m_nError;

	int getFieldOrderByArray(CString  sField);
	CString getFieldOrderStringByArray(CString  sField);

	void createFieldList(); //선택한 파일 리스트를 기반으로 전체 필드 리스트 추출 함수
	CString getFieldByFileName(CString sFileNM); //파일명에서 필드 추출 함수
	BOOL addFieldList(CString sField); //필드 리스트(m_saFieldList)에 추가함수, 동일한 필드명 등 체크
	CString getFieldListStringByFileArray();


	int splitString(CString str, CString var, CStringArray& strs);

	CString m_sLastSelectedFolder;



	/*
	UTMK: 		GRS80 UTMK(EPSG: 5179)
	KA:			카텍좌표계
	KTM: 		Bessel TM 중부원점(EPSG:5174)
	GRS: 		GRS80 TM 중부원점(EPSG: 5186, 가산 20만/60만 최신)
	GRS_OLD:	GRS80 TM 중부원점(EPSG: 5181, 가산 20만/50만 과거)
	GEO: 		WGS84 경위도(EPSG:4326)
	*/

	GeoPoint* pt1;
	GeoPoint* pt2;
	GeoTrans* m_oTrans;

	CString UTMK2TM(double fX, double fY);
	CString UTMK2KTM(double fX, double fY);
	CString UTMK2KA(double fX, double fY);
	CString UTMK2GEO(double fX, double fY);
	CString UTMK2GRS(double fX, double fY);
	CString UTMK2GRS_OLD(double fX, double fY);
	CString KA2TM(double fX, double fY);
	CString KA2KTM(double fX, double fY);
	CString KA2GRS(double fX, double fY);
	CString KA2GRS_OLD(double fX, double fY);
	CString KA2GEO(double fX, double fY);
	CString KA2UTMK(double fX, double fY);
	CString TM2KA(double fX, double fY);
	CString KTM2KA(double fX, double fY);
	CString TM2GEO(double fX, double fY);
	CString KTM2GEO(double fX, double fY);
	CString TM2UTMK(double fX, double fY);
	CString KTM2UTMK(double fX, double fY);
	CString KTM2GRS(double fX, double fY);
	CString KTM2GRS_OLD(double fX, double fY);
	CString GEO2TM(double fX, double fY);
	CString GEO2KTM(double fX, double fY);
	CString GEO2KA(double fX, double fY);
	CString GEO2UTMK(double fX, double fY);
	CString GEO2GRS(double fX, double fY);
	CString GEO2GRS_OLD(double fX, double fY);

	CString GRS2KA(double fX, double fY);
	CString GRS2KTM(double fX, double fY);
	CString GRS2GEO(double fX, double fY);
	CString GRS2UTMK(double fX, double fY);
	CString GRS2GRS_OLD(double fX, double fY);


	CString GRS_OLD2KA(double fX, double fY);
	CString GRS_OLD2KTM(double fX, double fY);
	CString GRS_OLD2GEO(double fX, double fY);
	CString GRS_OLD2UTMK(double fX, double fY);
	CString GRS_OLD2GRS(double fX, double fY);


	double getKTM_X_byTM(double fX, double fY);
	double getKTM_Y_byTM(double fX, double fY);
	double getTM_X_byKTM(double fX, double fY);
	double getTM_Y_byKTM(double fX, double fY);










	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	int m_nRadioGubun;
	int m_nRadioPrj;
	CString m_sEditFileList;
	CString m_sEditFieldList;
	CString m_sEditComma;
	CProgressCtrl m_ctrlProgress;
	BOOL m_nCheckTmpFolderNoDelete;
	afx_msg void OnBnClickedOk();
	afx_msg void OnEnChangeEditComma();
	afx_msg void OnBnClickedButtonFolderOpen();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton3();
};
