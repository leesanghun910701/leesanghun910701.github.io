﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace sbdd
{
    class ClassModular
    {

        public static int[] GateUsed;
        public static int[] GateOcc;
        public static List<ModGate> ModularGate;
        public static List<int> ModularGateList;
        
        public static void CheckModular(sbdd form, int TopIndex)        
        {
            
            #region calculate the gate/be occurence

            GateUsed = new int[ClassFtData.XEvent.Count];
            GateOcc = new int[ClassFtData.XEvent.Count];
            EventOcc(TopIndex, GateUsed, GateOcc); // -> GateUsed, GateOcc

            #endregion

            #region derive modular gates

            // derive modular gates that have single occurence BEs (except IE, Seq)
            GateUsed = new int[ClassFtData.XEvent.Count];
            FTModular(TopIndex, GateUsed, GateOcc, true); // -> ModularGate

            form.txtboxCmd.AppendText("(" + ModularGate.Count.ToString() + " modular gate(s) found)" + Environment.NewLine);
            form.txtboxCmd.AppendText("Processing modular gates... ");

            sbdd.CmdTxt += "(" + ModularGate.Count.ToString() + " modular gate(s) found)" + Environment.NewLine;
            sbdd.CmdTxt += "Processing modular gates... ";

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();


            #endregion

            #region add modular gates to ite (e.g., XX_MOD)

            for (int i = 0; i < ModularGate.Count; i++)
            {
                Event Evt = new Event();
                Evt = ClassFtData.XEvent[ModularGate[i].EventIndex];
                Evt.ite = ClassIte.CreateIte(ModularGate[i].EventIndex, 1, 0);
                ClassFtData.XEvent[ModularGate[i].EventIndex] = Evt;
            }

            #endregion

        }

        public static void EventOcc(int GateIndex, int[] GateUsed, int[] GateOcc) 
        {
            // if gate is BE, pass gate
            if (ClassFtData.XEvent[GateIndex].Child.Count < 1) return; 

            // if gate is already checked, pass gate 
            if (GateUsed[GateIndex] > 0) return;

            // continue for childs
            GateUsed[GateIndex]++;
            List<int> ChildList = ClassFtData.XEvent[GateIndex].Child;
            for (int i = 0; i < ChildList.Count; i++)
            {
                int ChildIndex = Math.Abs(ChildList[i]);
                GateOcc[ChildIndex]++;
                EventOcc(ChildIndex, GateUsed, GateOcc); 
            }
        }

        public static void FTModular(int GateIndex, int[] GateUsed, int[] GateOcc, bool isTopEvent) // 
        {
            // if gate is BE, pass gate
            if (ClassFtData.XEvent[GateIndex].Child.Count < 1) return;

            // if gate is already checked, pass gate 
            if (GateUsed[GateIndex] > 0) return;
            GateUsed[GateIndex]++;

            // continue for childs
            List<int> ChildList = ClassFtData.XEvent[GateIndex].Child;
            for (int i = 0; i < ChildList.Count; i++)
            {
                int ChildIndex = Math.Abs(ChildList[i]);
                FTModular(ChildIndex, GateUsed, GateOcc, false);
            }

            // modular for gates containing single occurence BE (except top event)
            if (!isTopEvent) GateModular(GateIndex, GateOcc); // -> ModularGate
        }

        public static void GateModular(int GateIndex, int[] GateOcc)
        {

            #region no modular rule

            // if no child, no modular for gate
            int nChild = ClassFtData.XEvent[GateIndex].Child.Count;
            if (nChild < 1) return;

            // no modular for child gates of Top event
            if (ClassFtData.XEvent[sbdd.TopIndex].Child.IndexOf(GateIndex) > -1) return;

            #endregion

            #region check single occurence childs (except IE, Seq)
                        
            int nSingleOccBE = 0;
            for (int i = 0; i < nChild; i++)
            {
                int ChildIndex = ClassFtData.XEvent[GateIndex].Child[i];

                if (IsSingleOcc(ChildIndex, GateOcc) &&
                    ClassFtData.XEvent[ChildIndex].Prob > Constants.Cutoff &&
                    ModularGate.FindIndex(modulargate => modulargate.EventIndex == ChildIndex) < 0)
                {
                    nSingleOccBE++;
                }
            }

            #endregion

            #region modular gate if child are all single occurence BEs (>= 2)

            if (nSingleOccBE > 1)
            {                
                if (nSingleOccBE == nChild) 
                {
                    // add GateIndex to ModularGateIndex
                    ModularGateList.Add(GateIndex);

                    #region generate ite for modular gate

                    ModGate gateModule = new ModGate();
                    gateModule.EventIndex = GateIndex;

                    Event Event = ClassFtData.XEvent[GateIndex];                    
                    Event.ite = ClassSolveGate.SolveGate(GateIndex);
                    Event.nite = ClassBdd.BddNegate(Event.ite);
                    
                    if ('c'.Equals(Char.ToLower(Constants.mcs)))
                    {
                        gateModule.ite = ClassMcs.MinimizeBdd(Event.ite);
                    }
                    else if('p'.Equals(Char.ToLower(Constants.mcs)))
                    {
                        gateModule.ite = Event.ite;
                        gateModule.nite = Event.nite;
                    }
                    else // zbdd
                    {
                        gateModule.ite = ClassMcs.MinimizeBdd(Event.ite);
                    }

                    #endregion

                    #region generate cutset for modular gate

                    if ('c'.Equals(Char.ToLower(Constants.mcs)))
                    {
                        ClassSaveMcs.ModularGateCutSet = new List<List<int>>();

                        int[] EventList = new int[ClassFtData.XEvent.Count];
                        int nEventinCutSet = -1;
                        gateModule.CutSet = ClassSaveMcs.ExpandMCSforMod(gateModule.ite, EventList, nEventinCutSet, 1.0f);
                    }
                    else if('p'.Equals(Char.ToLower(Constants.mcs)))
                    {
                        ClassSaveBdd.ModularGatePI = new List<List<int>>();

                        int[] EventList = new int[ClassFtData.XEvent.Count];
                        int nEventinCutSet = -1;
                        gateModule.CutSet = ClassSaveBdd.ExpandBddforMod(gateModule.ite, EventList, nEventinCutSet, 1.0f);
                                                
                        ClassSaveBdd.ModularGatePI = new List<List<int>>();

                        EventList = new int[ClassFtData.XEvent.Count];
                        nEventinCutSet = -1;
                        gateModule.nCutSet = ClassSaveBdd.ExpandBddforMod(gateModule.nite, EventList, nEventinCutSet, 1.0f);
                    }
                    else //zbdd
                    {
                        ClassSaveMcs.ModularGateCutSet = new List<List<int>>();

                        int[] EventList = new int[ClassFtData.XEvent.Count];
                        int nEventinCutSet = -1;
                        gateModule.CutSet = ClassSaveMcs.ExpandMCSforMod(gateModule.ite, EventList, nEventinCutSet, 1.0f);
                    }
                    ModularGate.Add(gateModule);

                    #endregion

                    #region remove all childs in gate

                    Event.Child = new List<int>();
                    Event.Type = 'B';
                    Event.Prob = ClassIte.IteList[Event.ite].prob;
                    ClassFtData.XEvent[GateIndex] = Event;

                    #endregion

                }
            }

            #endregion

        }

        public static bool IsSingleOcc(int EventIndex, int[] Occurence)
        {

            if (ClassFtData.XEvent[Math.Abs(EventIndex)].Child.Count < 1 &&
                    Occurence[Math.Abs(EventIndex)] == 1 &&
                    !(ClassFtData.isEventIE(EventIndex) ||
                      ClassFtData.isEventSeq(EventIndex) ||
                      ClassFtData.isEventFlag(EventIndex)))
            {
                return true;
            }
            else return false;

        }

        public static List<XaCutSetType> ExpandMod(List<XaCutSetType> XCutSet)
        {
            List<XaCutSetType> XCutsetpp = new List<XaCutSetType>();
            
            for (int i = 0; i < XCutSet.Count; i++)
            {
                bool ContainsMod = false;
                List<int> BEList = new List<int>();
                List<List<List<int>>> ModGateCSList = new List<List<List<int>>>();

                #region check for modular gates in cutset

                for (int j = 0; j < XCutSet[i].NoElem; j++)
                {
                    #region if modular gate, save to ModGateCSList

                    int ModularGateListIndex = ModularGateList.IndexOf(Math.Abs(XCutSet[i].Elems[j]) + 1);
                    if (ModularGateListIndex > -1)
                    {
                        ContainsMod = true;

                        // if modular gate is negated
                        if (Math.Sign(XCutSet[i].Elems[j]) < 0) 
                        {
                            ModGateCSList.Add(ModularGate[ModularGateListIndex].nCutSet); 
                        }
                        else 
                        {
                            ModGateCSList.Add(ModularGate[ModularGateListIndex].CutSet);
                        }
                    }
                    else // if basic event, save to BEList
                    {
                        BEList.Add(XCutSet[i].Elems[j]);
                    }

                    #endregion

                }

                #endregion

                #region if cutset contains modular gate, combine cutsets

                if (ContainsMod)
                {
                    #region generate modular gates combinations

                    List<int[]> ModGateCSComb = ModComb(ModGateCSList);

                    #endregion

                    #region add modular gate expansion result to XCutsetpp

                    for (int j = 0; j < ModGateCSComb.Count; j++)
                    {
                        XaCutSetType NewCutset = new XaCutSetType();

                        int[] Elems = new int[BEList.Count + ModGateCSComb[j].Length];
                        int ElemsIndex = 0;

                        // append basic events to Elems
                        for (int k = 0; k < BEList.Count; k++)
                        {
                            Elems[ElemsIndex++] = BEList[k];
                        }

                        // append modular gates to Elems
                        for (int k = 0; k < ModGateCSComb[j].Length; k++)
                        {
                            Elems[ElemsIndex++] = ModGateCSComb[j][k];
                        }

                        NewCutset.NoElem = ElemsIndex;
                        NewCutset.Elems = Elems.ToList();
                        NewCutset.CutProba = CalElemsVal(Elems);
                        if (NewCutset.CutProba < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR) continue;
                        else { XCutsetpp.Add(NewCutset); }
                    }

                    #endregion

                }
                else // if cutset not contains modular gate, add XCutSet to XCutsetpp
                {
                    XCutsetpp.Add(XCutSet[i]);
                }

                #endregion

            }

            return XCutsetpp;
        }

        // return List<int[]> of combinations in Mod
        public static List<int[]> ModComb(List<List<List<int>>> Mod)
        {   
            int nListFinal = 1;
            for (int i = 0; i < Mod.Count; i++) nListFinal *= Mod[i].Count;

            int[] LSdiv1 = Enumerable.Repeat(1, Mod.Count).ToArray();
            int[] LSdiv2 = Enumerable.Repeat(1, Mod.Count).ToArray();

            for (int i = 0; i < Mod.Count; i++)
            {
                for (int j = 0; j < i + 1; j++)
                {
                    LSdiv1[i] *= Mod[j].Count;
                }
                for (int j = 0; j < i; j++)
                {
                    LSdiv2[i] *= Mod[j].Count;
                }
            }

            List<int[]> ListIndex = new List<int[]>();
            List<int[]> ListFinal = new List<int[]>();

            for (int i = 0; i < nListFinal; i++)
            {
                int[] ListIndexVal = new int[Mod.Count];
                for (int j = 0; j < Mod.Count; j++)
                {
                    int firstdiv = i % LSdiv1[j];
                    int seconddiv = firstdiv / LSdiv2[j];
                    ListIndexVal[j] = seconddiv;
                }
                ListIndex.Add(ListIndexVal);
            }

            for (int i = 0; i < ListIndex.Count; i++)
            {
                int numval = 0;
                for (int j = 0; j < Mod.Count; j++)
                {
                    numval += Mod[j][ListIndex[i][j]].Count;
                }

                int[] ListVal = new int[numval];
                int ListValIndex = 0;
                for (int j = 0; j < Mod.Count; j++)
                {
                    for (int k = 0; k < Mod[j][ListIndex[i][j]].Count; k++)
                    {
                        ListVal[ListValIndex++] = Mod[j][ListIndex[i][j]][k];
                    }
                }
                ListFinal.Add(ListVal);
            }

            return ListFinal;
        }

        public static float CalElemsVal(int[] Elems)
        {
            float val = 1.0f;

            for (int i = 0; i < Elems.Length; i++)
            {
                int SignElems = Math.Sign(Elems[i]);
                int ElemsID = Math.Abs(Elems[i]) + 1;
                if (SignElems == 1)
                {
                    val *= ClassFtData.XEvent[ElemsID].Prob;
                }
                else // negative
                {
                    val *= (1.0f - ClassFtData.XEvent[ElemsID].Prob);
                }
            }

            return val;
        }

    }
}
