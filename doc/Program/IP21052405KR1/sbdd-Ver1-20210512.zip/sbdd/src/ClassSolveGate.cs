﻿using System;
using System.Collections.Generic;

namespace sbdd
{
    class ClassSolveGate
    {

        public static int SolveTop(sbdd form)
        {
            int GateIte = 0;

            for (int i = 0; i < ClassFtOrder.SolveGateOrder.Count; i++)
            {

                int GateIndex = ClassFtOrder.SolveGateOrder[i];

                // derive ite for gate                
                int prevline = form.txtboxCmd.Text.LastIndexOf(Environment.NewLine);
                form.txtboxCmd.AppendText("Solving...   " + ClassFtData.XEvent[GateIndex].Name + Environment.NewLine);

                GateIte = SolveGate(GateIndex);
                // if (Constants.zbdd == 1) { GateIte = ClassMcs.MinimizeBdd(GateIte); }

                form.txtboxCmd.Text = form.txtboxCmd.Text.Substring(0, prevline + 2);

                form.Refresh();

                // set ite for gate
                Event Event = ClassFtData.XEvent[GateIndex];
                Event.ite = GateIte;
                ClassFtData.XEvent[GateIndex] = Event;
            }
            
            return GateIte;
        }

        public static int SolveGate(int GateIndex)
        {
            int GateIte = 0;
            char Operator = ClassFtData.XEvent[GateIndex].Type;
            
            switch (Operator)
            {
                case 'B': // basic event
                    break;
                case '+': // or
                case '*': // and
                    GateIte = SolveAndOr(GateIndex); break;
                case '=': // equal
                    GateIte = SolveEqual(GateIndex); break;
                case 'N': // not
                    GateIte = SolveNot(GateIndex); break;
                case '2': // n-out-of-m (m = 2-9)
                case '3': 
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    List<int> GateList = ClassFtData.XEvent[GateIndex].Child;
                    GateIte = SolveNooM(GateList, Int32.Parse(Operator.ToString()), ClassFtData.XEvent[GateIndex].Child.Count);
                    break;
                default:
                    break;
            }

            return GateIte;
        }

        public static int SolveAndOr(int GateIndex)
        {
            int ChildNumber;
            int EventIndex, EventIndexSign;
            int EventIndex1, EventIndexSign1;
            int EventIte, EventIte1;
            char Operator;
            
            Operator = ClassFtData.XEvent[GateIndex].Type;
            ChildNumber = ClassFtData.XEvent[GateIndex].Child.Count;

            EventIndex = ClassFtData.XEvent[GateIndex].Child[0];
            EventIndexSign = Math.Sign(EventIndex);
            EventIndex = Math.Abs(EventIndex);
            EventIte = ClassFtData.XEvent[EventIndex].ite;
            
            if (EventIndexSign == -1) EventIte = ClassBdd.BddNegate(EventIte);
            
            for (int j = 1; j < ChildNumber; j++)
            {
                EventIndex1 = ClassFtData.XEvent[GateIndex].Child[j];
                EventIndexSign1 = Math.Sign(EventIndex1);
                EventIndex1 = Math.Abs(EventIndex1);
                EventIte1 = ClassFtData.XEvent[EventIndex1].ite;
                
                if (EventIndexSign1 == -1) EventIte1 = ClassBdd.BddNegate(EventIte1);
                
                //if ('z'.Equals(Char.ToLower(Constants.mcs))) EventIte = ClassBdd.ZBddSolve(Operator, EventIte, EventIte1);
                //else EventIte = ClassBdd.BddSolve(Operator, EventIte, EventIte1);

                EventIte = ClassBdd.BddSolve(Operator, EventIte, EventIte1);

            }

            return EventIte;
        }

        public static int SolveEqual(int GateIndex)
        {
            int EventIndex;
            int EventIndexSign;
            int EventIte;

            EventIndex = ClassFtData.XEvent[GateIndex].Child[0];
            EventIndexSign = Math.Sign(EventIndex);
            EventIndex = Math.Abs(EventIndex);
            EventIte = ClassFtData.XEvent[EventIndex].ite;

            if (EventIndexSign == -1) EventIte = ClassBdd.BddNegate(EventIte);

            return EventIte;
        }

        public static int SolveNot(int GateIndex)
        {
            int EventIndex;
            int EventIndexSign;
            int EventIte;

            EventIndex = ClassFtData.XEvent[GateIndex].Child[0];
            EventIndexSign = Math.Sign(EventIndex);
            EventIndex = Math.Abs(EventIndex);
            EventIte = ClassFtData.XEvent[EventIndex].ite;

            if (EventIndexSign == -1) EventIte = ClassBdd.BddNegate(EventIte);

            EventIte = ClassBdd.BddNegate(EventIte);

            return EventIte;
        }

        public static int SolveNooM(List<int> EvtList, int n, int m)
        {
            char Operator;
            int EventIndex, EventIndexSign;
            int EventIndex1, EventIndex1Sign;
            int EventIte;
            int EventIte1;
            int EventIte2;
            
            if(n == 1) // 1-out-of-M (OR)
            {

                EventIndex = EvtList[0];
                EventIndexSign = Math.Sign(EventIndex);
                EventIndex = Math.Abs(EventIndex);
                EventIte = ClassFtData.XEvent[EventIndex].ite;

                if (EventIndexSign == -1) EventIte = ClassBdd.BddNegate(EventIte);

                for (int i = 1; i < EvtList.Count; i++)
                {
                    EventIndex1 = EvtList[i];
                    EventIndex1Sign = Math.Sign(EventIndex1);
                    EventIndex1 = Math.Abs(EventIndex1);
                    EventIte1 = ClassFtData.XEvent[EventIndex1].ite;

                    if (EventIndex1Sign == -1) EventIte1 = ClassBdd.BddNegate(EventIte1);

                    Operator = '+';

                    //if ('z'.Equals(Char.ToLower(Constants.mcs))) EventIte = ClassBdd.ZBddSolve(Operator, EventIte, EventIte1);
                    //else EventIte = ClassBdd.BddSolve(Operator, EventIte, EventIte1);

                    EventIte = ClassBdd.BddSolve(Operator, EventIte, EventIte1);
                }
            }
            else if(n == m) // N-out-of-N (AND)
            {
                EventIndex = EvtList[0];
                EventIndexSign = Math.Sign(EventIndex);
                EventIndex = Math.Abs(EventIndex);
                EventIte = ClassFtData.XEvent[EventIndex].ite;

                if (EventIndexSign == -1) EventIte = ClassBdd.BddNegate(EventIte);

                for (int i = 1; i < EvtList.Count; i++)
                {
                    EventIndex1 = EvtList[i];
                    EventIndex1Sign = Math.Sign(EventIndex1);
                    EventIndex1 = Math.Abs(EventIndex1);
                    EventIte1 = ClassFtData.XEvent[EventIndex1].ite;

                    if (EventIndex1Sign == -1) EventIte1 = ClassBdd.BddNegate(EventIte1);

                    Operator = '*';

                    //if ('z'.Equals(Char.ToLower(Constants.mcs))) EventIte = ClassBdd.ZBddSolve(Operator, EventIte, EventIte1);
                    //else EventIte = ClassBdd.BddSolve(Operator, EventIte, EventIte1);

                    EventIte = ClassBdd.BddSolve(Operator, EventIte, EventIte1);
                }
            }
            else // N-out-of-M (2 < N < M)
            {
                EventIndex = EvtList[0];
                EventIndexSign = Math.Sign(EventIndex);
                EventIndex = Math.Abs(EventIndex);
                EventIte = ClassFtData.XEvent[EventIndex].ite;

                if (EventIndexSign == -1) EventIte = ClassBdd.BddNegate(EventIte);
                
                EventIte1 = SolveNooM(EvtList.GetRange(1, EvtList.Count - 1), n - 1, m - 1);
                EventIte2 = SolveNooM(EvtList.GetRange(1, EvtList.Count - 1), n, m - 1);
                //if ('z'.Equals(Char.ToLower(Constants.mcs))) EventIte = ClassBdd.ZBddSolve('*', EventIte, EventIte1);
                //else EventIte = ClassBdd.BddSolve('*', EventIte, EventIte1);

                EventIte = ClassBdd.BddSolve('*', EventIte, EventIte1);

                //if ('z'.Equals(Char.ToLower(Constants.mcs))) EventIte = ClassBdd.ZBddSolve('+', EventIte, EventIte2);
                //else EventIte = ClassBdd.BddSolve('+', EventIte, EventIte2);

                EventIte = ClassBdd.BddSolve('+', EventIte, EventIte2);
            }

            return EventIte;
        }
        
    }
}
