﻿namespace sbdd
{
    partial class sbdd
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtboxOutFileName = new System.Windows.Forms.TextBox();
            this.OutFileNameLabel = new System.Windows.Forms.Label();
            this.btnReadFile = new System.Windows.Forms.Button();
            this.btnSolve = new System.Windows.Forms.Button();
            this.txtboxCutoff = new System.Windows.Forms.TextBox();
            this.txtboxInFileName = new System.Windows.Forms.TextBox();
            this.CutoffLabel = new System.Windows.Forms.Label();
            this.txtboxTopEvent = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.InFileNameLabel = new System.Windows.Forms.Label();
            this.StatusBar = new System.Windows.Forms.StatusBar();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtboxMaxPICS = new System.Windows.Forms.TextBox();
            this.radMcs = new System.Windows.Forms.RadioButton();
            this.radBdd = new System.Windows.Forms.RadioButton();
            this.txtboxCmd = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.radMF = new System.Windows.Forms.RadioButton();
            this.radBU = new System.Windows.Forms.RadioButton();
            this.radTD = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.txtboxOutFileName);
            this.groupBox1.Controls.Add(this.OutFileNameLabel);
            this.groupBox1.Controls.Add(this.btnReadFile);
            this.groupBox1.Controls.Add(this.btnSolve);
            this.groupBox1.Controls.Add(this.txtboxCutoff);
            this.groupBox1.Controls.Add(this.txtboxInFileName);
            this.groupBox1.Controls.Add(this.CutoffLabel);
            this.groupBox1.Controls.Add(this.txtboxTopEvent);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.InFileNameLabel);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(588, 137);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Read FT";
            // 
            // txtboxOutFileName
            // 
            this.txtboxOutFileName.Location = new System.Drawing.Point(96, 46);
            this.txtboxOutFileName.Name = "txtboxOutFileName";
            this.txtboxOutFileName.Size = new System.Drawing.Size(396, 21);
            this.txtboxOutFileName.TabIndex = 12;
            // 
            // OutFileNameLabel
            // 
            this.OutFileNameLabel.AutoSize = true;
            this.OutFileNameLabel.Location = new System.Drawing.Point(16, 49);
            this.OutFileNameLabel.Name = "OutFileNameLabel";
            this.OutFileNameLabel.Size = new System.Drawing.Size(50, 12);
            this.OutFileNameLabel.TabIndex = 11;
            this.OutFileNameLabel.Text = "RawFile";
            // 
            // btnReadFile
            // 
            this.btnReadFile.Location = new System.Drawing.Point(498, 20);
            this.btnReadFile.Name = "btnReadFile";
            this.btnReadFile.Size = new System.Drawing.Size(27, 23);
            this.btnReadFile.TabIndex = 10;
            this.btnReadFile.Text = "...";
            this.btnReadFile.UseVisualStyleBackColor = true;
            this.btnReadFile.Click += new System.EventHandler(this.BtnReadFile_Click);
            // 
            // btnSolve
            // 
            this.btnSolve.Location = new System.Drawing.Point(498, 86);
            this.btnSolve.Name = "btnSolve";
            this.btnSolve.Size = new System.Drawing.Size(84, 33);
            this.btnSolve.TabIndex = 4;
            this.btnSolve.Text = "Solve";
            this.btnSolve.UseVisualStyleBackColor = true;
            this.btnSolve.Click += new System.EventHandler(this.BtnSolve_Click);
            // 
            // txtboxCutoff
            // 
            this.txtboxCutoff.Location = new System.Drawing.Point(96, 98);
            this.txtboxCutoff.Name = "txtboxCutoff";
            this.txtboxCutoff.Size = new System.Drawing.Size(396, 21);
            this.txtboxCutoff.TabIndex = 9;
            // 
            // txtboxInFileName
            // 
            this.txtboxInFileName.Enabled = false;
            this.txtboxInFileName.Location = new System.Drawing.Point(96, 20);
            this.txtboxInFileName.Name = "txtboxInFileName";
            this.txtboxInFileName.Size = new System.Drawing.Size(396, 21);
            this.txtboxInFileName.TabIndex = 8;
            // 
            // CutoffLabel
            // 
            this.CutoffLabel.AutoSize = true;
            this.CutoffLabel.Location = new System.Drawing.Point(17, 101);
            this.CutoffLabel.Name = "CutoffLabel";
            this.CutoffLabel.Size = new System.Drawing.Size(41, 12);
            this.CutoffLabel.TabIndex = 7;
            this.CutoffLabel.Text = "Cutoff ";
            // 
            // txtboxTopEvent
            // 
            this.txtboxTopEvent.Location = new System.Drawing.Point(96, 73);
            this.txtboxTopEvent.Name = "txtboxTopEvent";
            this.txtboxTopEvent.Size = new System.Drawing.Size(396, 21);
            this.txtboxTopEvent.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "Top Event";
            // 
            // InFileNameLabel
            // 
            this.InFileNameLabel.AutoSize = true;
            this.InFileNameLabel.Location = new System.Drawing.Point(16, 23);
            this.InFileNameLabel.Name = "InFileNameLabel";
            this.InFileNameLabel.Size = new System.Drawing.Size(42, 12);
            this.InFileNameLabel.TabIndex = 2;
            this.InFileNameLabel.Text = "FtpFile";
            // 
            // StatusBar
            // 
            this.StatusBar.Location = new System.Drawing.Point(0, 583);
            this.StatusBar.Name = "StatusBar";
            this.StatusBar.Size = new System.Drawing.Size(612, 22);
            this.StatusBar.TabIndex = 5;
            this.StatusBar.Text = " ";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.txtboxMaxPICS);
            this.groupBox3.Location = new System.Drawing.Point(380, 155);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(220, 97);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Options";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 12);
            this.label1.TabIndex = 13;
            this.label1.Text = "Max # of PI/CS";
            // 
            // txtboxMaxPICS
            // 
            this.txtboxMaxPICS.Location = new System.Drawing.Point(104, 21);
            this.txtboxMaxPICS.Name = "txtboxMaxPICS";
            this.txtboxMaxPICS.Size = new System.Drawing.Size(110, 21);
            this.txtboxMaxPICS.TabIndex = 13;
            this.txtboxMaxPICS.Text = "100000";
            // 
            // radMcs
            // 
            this.radMcs.AutoSize = true;
            this.radMcs.Location = new System.Drawing.Point(18, 42);
            this.radMcs.Name = "radMcs";
            this.radMcs.Size = new System.Drawing.Size(51, 16);
            this.radMcs.TabIndex = 14;
            this.radMcs.TabStop = true;
            this.radMcs.Text = "MCS";
            this.radMcs.UseVisualStyleBackColor = true;
            // 
            // radBdd
            // 
            this.radBdd.AutoSize = true;
            this.radBdd.Location = new System.Drawing.Point(18, 20);
            this.radBdd.Name = "radBdd";
            this.radBdd.Size = new System.Drawing.Size(47, 16);
            this.radBdd.TabIndex = 13;
            this.radBdd.TabStop = true;
            this.radBdd.Text = "BDD";
            this.radBdd.UseVisualStyleBackColor = true;
            // 
            // txtboxCmd
            // 
            this.txtboxCmd.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtboxCmd.Location = new System.Drawing.Point(13, 258);
            this.txtboxCmd.Multiline = true;
            this.txtboxCmd.Name = "txtboxCmd";
            this.txtboxCmd.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtboxCmd.Size = new System.Drawing.Size(587, 319);
            this.txtboxCmd.TabIndex = 7;
            this.txtboxCmd.DragDrop += new System.Windows.Forms.DragEventHandler(this.FileDragDrop);
            this.txtboxCmd.DragEnter += new System.Windows.Forms.DragEventHandler(this.FileDragEnter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radBdd);
            this.groupBox2.Controls.Add(this.radMcs);
            this.groupBox2.Location = new System.Drawing.Point(12, 155);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(152, 97);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PI/CS";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radMF);
            this.groupBox4.Controls.Add(this.radBU);
            this.groupBox4.Controls.Add(this.radTD);
            this.groupBox4.Location = new System.Drawing.Point(170, 155);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(204, 97);
            this.groupBox4.TabIndex = 16;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "BE ordering";
            // 
            // radMF
            // 
            this.radMF.AutoSize = true;
            this.radMF.Location = new System.Drawing.Point(18, 67);
            this.radMF.Name = "radMF";
            this.radMF.Size = new System.Drawing.Size(102, 16);
            this.radMF.TabIndex = 2;
            this.radMF.TabStop = true;
            this.radMF.Text = "Most-frequent";
            this.radMF.UseVisualStyleBackColor = true;
            // 
            // radBU
            // 
            this.radBU.AutoSize = true;
            this.radBU.Location = new System.Drawing.Point(18, 44);
            this.radBU.Name = "radBU";
            this.radBU.Size = new System.Drawing.Size(82, 16);
            this.radBU.TabIndex = 1;
            this.radBU.TabStop = true;
            this.radBU.Text = "Bottom-up";
            this.radBU.UseVisualStyleBackColor = true;
            // 
            // radTD
            // 
            this.radTD.AutoSize = true;
            this.radTD.Location = new System.Drawing.Point(18, 21);
            this.radTD.Name = "radTD";
            this.radTD.Size = new System.Drawing.Size(82, 16);
            this.radTD.TabIndex = 0;
            this.radTD.TabStop = true;
            this.radTD.Text = "Top-down";
            this.radTD.UseVisualStyleBackColor = true;
            // 
            // sbdd
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 605);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.txtboxCmd);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.StatusBar);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "sbdd";
            this.Text = " sbdd";
            this.Load += new System.EventHandler(this.sbdd_Load);
            this.Shown += new System.EventHandler(this.bddc_Shown);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label InFileNameLabel;
        private System.Windows.Forms.TextBox txtboxTopEvent;
        private System.Windows.Forms.Button btnSolve;
        private System.Windows.Forms.StatusBar StatusBar;
        private System.Windows.Forms.Label CutoffLabel;
        private System.Windows.Forms.TextBox txtboxInFileName;
        private System.Windows.Forms.TextBox txtboxCutoff;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnReadFile;
        private System.Windows.Forms.RadioButton radMcs;
        private System.Windows.Forms.RadioButton radBdd;
        public System.Windows.Forms.TextBox txtboxCmd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radMF;
        private System.Windows.Forms.RadioButton radBU;
        private System.Windows.Forms.RadioButton radTD;
        private System.Windows.Forms.TextBox txtboxOutFileName;
        private System.Windows.Forms.Label OutFileNameLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtboxMaxPICS;
    }
}

