﻿using System.Collections.Generic;

namespace sbdd
{
    class ClassIte
    {
        public static List<iteDef> IteList;
        public static MultiKeyDictionary<int, int, int, int> IteListDict; // <op, ite1, ite2, ite_result>
        // public static Dictionary<ulong, int> IteListDict;

        public static int CreateIte(int x, int l, int r)
        {

            iteDef ite;
            float pv, vx, vl, vr;
            int iteid;

            #region simple case
            
            if (l == r) return l; // x * F + /x * F = F

            #endregion

            #region find ite at hashtable
            if (IteListDict.TryGetValue(x, l, r, out iteid)) { return iteid; }

            // ulong IteKey = (ulong)x * (ulong)100000000000000 + (ulong)l * (ulong)10000000 + (ulong)r;
            // if (IteListDict.TryGetValue(IteKey, out iteid)) { return iteid; }

            #endregion

            #region if new, create ite

            ite.x = x;
            ite.l = l;
            ite.r = r;            
            vx = ClassFtData.XEvent[x].Prob;
            vl = IteList[l].prob;
            vr = IteList[r].prob;
            if (ClassFtData.isEventIE(x) || ClassFtData.isEventSeq(x)) pv = vx * vl + vr;
            else pv = vx * vl + (1 - vx) * vr;
            ite.prob = pv;

            #endregion

            #region cutoff truncation            
            // if (pv < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR) return 0;

            #endregion

            #region if new, add to hashtable

            IteList.Add(ite);
            iteid = IteList.Count - 1;
            IteListDict.Add(x, l, r, iteid);
            // IteListDict.Add(IteKey, iteid);

            #endregion
            
            return iteid;            
        }
        
    }
}
