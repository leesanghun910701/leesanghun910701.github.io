﻿namespace STPATool
{
    partial class ResultCalc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DGV_Res = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Res)).BeginInit();
            this.SuspendLayout();
            // 
            // DGV_Res
            // 
            this.DGV_Res.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGV_Res.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_Res.Location = new System.Drawing.Point(13, 13);
            this.DGV_Res.Name = "DGV_Res";
            this.DGV_Res.RowTemplate.Height = 23;
            this.DGV_Res.Size = new System.Drawing.Size(272, 417);
            this.DGV_Res.TabIndex = 0;
            // 
            // ResultCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(303, 450);
            this.Controls.Add(this.DGV_Res);
            this.Name = "ResultCalc";
            this.Text = "ResultCalc";
            this.Load += new System.EventHandler(this.ResultCalc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_Res)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView DGV_Res;
    }
}