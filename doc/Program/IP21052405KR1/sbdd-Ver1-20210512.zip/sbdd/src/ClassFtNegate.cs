﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Diagnostics;

namespace sbdd
{
    class ClassFtNegate
    {


        public static List<Gate> oGateList;
        public static string NegFileName;
        public static List<string> NegateGateList;
        public static List<string> NegateGateListDone;
        public static List<Gate> GateList;
        public static List<string> WriteNegateGateList;
        public static List<string> WriteNegateBEList;

        public static void WriteNegate(StreamWriter strwriter, string GateName)
        {

            #region if event is basic event, save to WriteNegateBEList
            
            string nGateName = GateName + "_NOT";
            int GateListIndex = GateList.FindIndex(Gate => Gate.Name == GateName);
            if (GateListIndex < 0)
            {
                if (!'p'.Equals(Char.ToLower(Constants.mcs))) WriteNegateBEList.Add(nGateName);
            }

            #endregion

            #region if event is gate, propagate WriteNegate

            else
            {
                #region change gate type

                char nType;
                switch (GateList[GateListIndex].Type)
                {
                    case '+': // or
                        nType = '*'; break;
                    case '*': // and
                        nType = '+'; break;
                    case '=': // equal
                        nType = '='; break;
                    case 'N': // not
                        nType = 'N'; break;
                    case '2': // n-out-of-m (m = 2-9) (ASCII = 50-57)
                    case '3':
                    case '4':
                    case '5':
                    case '6':
                    case '7':
                    case '8':
                    case '9':
                        int m = GateList[GateListIndex].Child.Count;
                        int n = int.Parse(GateList[GateListIndex].Type.ToString());
                        nType = Convert.ToChar((m - n + 1).ToString());
                        break;
                    default:
                        nType = ' '; break; // not applicable
                }

                #endregion

                List<string> ChildList = new List<string>();

                for (int i = 0; i < GateList[GateListIndex].Child.Count; i++)
                {
                    string ChildName = GateList[GateListIndex].Child[i];

                    #region if child is basic event
                    if (GateList.FindIndex(Gate => Gate.Name == ChildName) < 0)
                    {
                        if (ChildName == "FALSE") ChildList.Add("TRUE");
                        else if (ChildName == "TRUE") ChildList.Add("FALSE");
                        else if (String.Equals(ChildName.Substring(0, 1), "-"))
                        {
                            ChildList.Add(ChildName.Substring(1, ChildName.Length - 1));
                        }
                        else ChildList.Add("-" + ChildName);
                    }
                    #endregion

                    #region if child is gate, WriteNegate for child
                    else
                    {
                        ChildList.Add(ChildName + "_NOT");
                        if (!NegateGateListDone.Contains(ChildName))
                        {
                            NegateGateListDone.Add(ChildName);
                            WriteNegate(strwriter, ChildName);
                        }
                    }
                    #endregion

                }

                #region if new negate gate, write to output file

                if (WriteNegateGateList.FindIndex(Gate => Gate == nGateName) < 0)
                {
                    string Line = nGateName + " " + nType;
                    for (int i = 0; i < ChildList.Count; i++)
                    {
                        Line += " " + ChildList[i];
                    }
                    strwriter.WriteLine(Line);
                    WriteNegateGateList.Add(nGateName);
                }

                #endregion

            }
            #endregion
            
        }

        public static void CheckNegate(sbdd form, string file, bool CmdMod)
        {
            sbdd.NegProcTime = new Stopwatch();
            sbdd.NegProcTime.Start();

            StreamReader strReader = new StreamReader(file);

            #region identify gates (to later change gate name to "_NOT"

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (String.Equals(Line, "ENDTREE")) { break; }

                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    string[] LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    Gate Gate = new Gate();
                    Gate.Name = LineSplit[0];
                    Gate.Type = Convert.ToChar(LineSplit[1]);
                    Gate.Child = new List<string>();

                    oGateList.Add(Gate);

                }
            }

            strReader.Close();

            #endregion

            string FileName = Path.GetFileNameWithoutExtension(sbdd.InputFilePath);
            FileName = FileName.Substring(0, FileName.Length - 5); // "_circ" 제거

            string NegFileNameOnly = FileName + "_neg" + Path.GetExtension(sbdd.InputFilePath);
            NegFileName = sbdd.WorkingDir + "\\" + NegFileNameOnly;
            if (File.Exists(NegFileName)){File.Delete(NegFileName);}

            StreamWriter strWriter = new StreamWriter(new FileStream(NegFileName, FileMode.Create));
            
            #region write gate block (change negate childs)

            strReader = new StreamReader(file); 

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (String.Equals(Line, "ENDTREE")) { break; }
                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    string[] LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                    Gate Gate = new Gate();
                    Gate.Name = LineSplit[0];
                    Gate.Type = Convert.ToChar(LineSplit[1]);
                    Gate.Child = new List<string>();

                    #region check gate child(s) for negate

                    for (int j = 2; j < LineSplit.Length; j++)
                    {
                        string EvtName = LineSplit[j];
                        Gate.Child.Add(EvtName);

                        // detect negate gate and change in ftp
                        if (String.Equals(EvtName.Substring(0, 1), "-"))
                        {
                            EvtName = EvtName.Substring(1, EvtName.Length - 1);
                            if (EvtName == "TRUE") LineSplit[j] = "FALSE";
                            else if (EvtName == "FALSE") LineSplit[j] = "TRUE";
                            else
                            {
                                
                                if (!'p'.Equals(Char.ToLower(Constants.mcs)))
                                {
                                    NegateGateList.Add(EvtName);
                                    LineSplit[j] = EvtName + "_NOT"; // if '-' exists, add '_NOT' at the end
                                }
                                else // 'p'
                                {
                                    int GateListIndex = oGateList.FindIndex(Gatee => Gatee.Name == EvtName);
                                    if (GateListIndex > -1)
                                    {
                                        NegateGateList.Add(EvtName);
                                        LineSplit[j] = EvtName + "_NOT"; // if '-' exists, add '_NOT' at the end
                                    }
                                }
                            }
                        }
                    }

                    #endregion

                    Line = string.Join(" ", LineSplit);
                    GateList.Add(Gate);
                }
                strWriter.WriteLine(Line);
            }

            #endregion

            #region write negate gate

            NegateGateList = NegateGateList.Distinct().ToList();
            form.txtboxCmd.AppendText("(" + NegateGateList.Count.ToString() + " negate gate(s) found)" + Environment.NewLine);
            form.txtboxCmd.AppendText("Processing negate gates... ");

            sbdd.CmdTxt += "(" + NegateGateList.Count.ToString() + " negate gate(s) found)" + Environment.NewLine;
            sbdd.CmdTxt += "Processing negate gates... ";

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();


            for (int i = 0; i < NegateGateList.Count; i++) WriteNegate(strWriter, NegateGateList[i]);

            #endregion

            #region write ENDTREE ~ IMPORT block

            strWriter.WriteLine("ENDTREE");

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                strWriter.WriteLine(Line);
                if (String.Equals(Line, "IMPORT"))
                {
                    break;
                }
            }

            #endregion

            #region write negate basic event

            WriteNegateBEList = WriteNegateBEList.Distinct().ToList();

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                string[] LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                if (String.Equals(LineSplit[0], "LIMIT"))
                {
                    strWriter.WriteLine(Line);
                    break;
                }

                strWriter.WriteLine(Line);
                for (int i = 0; i < WriteNegateBEList.Count; i++)
                {
                    if (WriteNegateBEList[i].Contains(LineSplit[1]))
                    {
                        float BEProb = Convert.ToSingle(LineSplit[0]);
                        float NegateBEProb = 1.0f - BEProb;
                        string NegateBEProbLine = "    " + NegateBEProb.ToString("e7") + " " + LineSplit[1] + "_NOT";
                        strWriter.WriteLine(NegateBEProbLine);
                    }
                }
            }

            #endregion

            #region write rest of file

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                strWriter.WriteLine(Line);
            }

            #endregion

            strReader.Close();
            strWriter.Close();
            
            sbdd.NegProcTime.Stop();

            form.txtboxCmd.AppendText("(" + sbdd.NegProcTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += "(" + sbdd.NegProcTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();


        }

    }
}
