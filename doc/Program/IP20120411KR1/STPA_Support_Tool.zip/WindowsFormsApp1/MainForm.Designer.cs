﻿namespace STPATool
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadCS = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loadProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveProjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DGV_FB = new System.Windows.Forms.DataGridView();
            this.DGV_CA = new System.Windows.Forms.DataGridView();
            this.btnSelCA = new System.Windows.Forms.Button();
            this.btnSelFB = new System.Windows.Forms.Button();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnSelCont = new System.Windows.Forms.Button();
            this.DGV_CT = new System.Windows.Forms.DataGridView();
            this.gbCT = new System.Windows.Forms.GroupBox();
            this.gbCA = new System.Windows.Forms.GroupBox();
            this.gbFB = new System.Windows.Forms.GroupBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.chkInitFilter = new System.Windows.Forms.CheckBox();
            this.radOR = new System.Windows.Forms.RadioButton();
            this.radAND = new System.Windows.Forms.RadioButton();
            this.cbFilter2Cond = new System.Windows.Forms.ComboBox();
            this.cbFilter1Cond = new System.Windows.Forms.ComboBox();
            this.txtFilter2 = new System.Windows.Forms.TextBox();
            this.txtFilter1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_FB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_CA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_CT)).BeginInit();
            this.gbCT.SuspendLayout();
            this.gbCA.SuspendLayout();
            this.gbFB.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLoadCS
            // 
            this.btnLoadCS.Location = new System.Drawing.Point(12, 27);
            this.btnLoadCS.Name = "btnLoadCS";
            this.btnLoadCS.Size = new System.Drawing.Size(90, 23);
            this.btnLoadCS.TabIndex = 0;
            this.btnLoadCS.Text = "Load files";
            this.btnLoadCS.UseVisualStyleBackColor = true;
            this.btnLoadCS.Click += new System.EventHandler(this.BtnLoadCS_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(832, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.loadProjectToolStripMenuItem,
            this.saveProjectToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // loadProjectToolStripMenuItem
            // 
            this.loadProjectToolStripMenuItem.Name = "loadProjectToolStripMenuItem";
            this.loadProjectToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.loadProjectToolStripMenuItem.Text = "Load Project";
            // 
            // saveProjectToolStripMenuItem
            // 
            this.saveProjectToolStripMenuItem.Name = "saveProjectToolStripMenuItem";
            this.saveProjectToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.saveProjectToolStripMenuItem.Text = "Save Project";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // DGV_FB
            // 
            this.DGV_FB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGV_FB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_FB.Location = new System.Drawing.Point(15, 89);
            this.DGV_FB.Name = "DGV_FB";
            this.DGV_FB.RowTemplate.Height = 23;
            this.DGV_FB.Size = new System.Drawing.Size(770, 180);
            this.DGV_FB.TabIndex = 2;
            // 
            // DGV_CA
            // 
            this.DGV_CA.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGV_CA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_CA.Location = new System.Drawing.Point(15, 19);
            this.DGV_CA.Name = "DGV_CA";
            this.DGV_CA.RowTemplate.Height = 23;
            this.DGV_CA.Size = new System.Drawing.Size(770, 180);
            this.DGV_CA.TabIndex = 3;
            // 
            // btnSelCA
            // 
            this.btnSelCA.Location = new System.Drawing.Point(205, 27);
            this.btnSelCA.Name = "btnSelCA";
            this.btnSelCA.Size = new System.Drawing.Size(90, 23);
            this.btnSelCA.TabIndex = 4;
            this.btnSelCA.Text = "Select CA";
            this.btnSelCA.UseVisualStyleBackColor = true;
            this.btnSelCA.Click += new System.EventHandler(this.BtnSelCA_Click);
            // 
            // btnSelFB
            // 
            this.btnSelFB.Location = new System.Drawing.Point(301, 27);
            this.btnSelFB.Name = "btnSelFB";
            this.btnSelFB.Size = new System.Drawing.Size(90, 23);
            this.btnSelFB.TabIndex = 5;
            this.btnSelFB.Text = "Select FB";
            this.btnSelFB.UseVisualStyleBackColor = true;
            this.btnSelFB.Click += new System.EventHandler(this.BtnSelFB_Click);
            // 
            // btnCalc
            // 
            this.btnCalc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCalc.Location = new System.Drawing.Point(695, 18);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(90, 23);
            this.btnCalc.TabIndex = 6;
            this.btnCalc.Text = "Calculate IM";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.BtnCalc_Click);
            // 
            // btnSelCont
            // 
            this.btnSelCont.Location = new System.Drawing.Point(109, 27);
            this.btnSelCont.Name = "btnSelCont";
            this.btnSelCont.Size = new System.Drawing.Size(90, 23);
            this.btnSelCont.TabIndex = 8;
            this.btnSelCont.Text = "Select Cont";
            this.btnSelCont.UseVisualStyleBackColor = true;
            this.btnSelCont.Click += new System.EventHandler(this.btnSelCont_Click);
            // 
            // DGV_CT
            // 
            this.DGV_CT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DGV_CT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_CT.Location = new System.Drawing.Point(16, 19);
            this.DGV_CT.Name = "DGV_CT";
            this.DGV_CT.RowTemplate.Height = 23;
            this.DGV_CT.Size = new System.Drawing.Size(770, 180);
            this.DGV_CT.TabIndex = 9;
            // 
            // gbCT
            // 
            this.gbCT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCT.Controls.Add(this.DGV_CT);
            this.gbCT.Location = new System.Drawing.Point(12, 71);
            this.gbCT.Name = "gbCT";
            this.gbCT.Size = new System.Drawing.Size(800, 210);
            this.gbCT.TabIndex = 13;
            this.gbCT.TabStop = false;
            this.gbCT.Text = "Controller";
            // 
            // gbCA
            // 
            this.gbCA.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCA.Controls.Add(this.DGV_CA);
            this.gbCA.Location = new System.Drawing.Point(13, 292);
            this.gbCA.Name = "gbCA";
            this.gbCA.Size = new System.Drawing.Size(800, 210);
            this.gbCA.TabIndex = 14;
            this.gbCA.TabStop = false;
            this.gbCA.Text = "Control Action";
            // 
            // gbFB
            // 
            this.gbFB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbFB.Controls.Add(this.btnSelect);
            this.gbFB.Controls.Add(this.chkInitFilter);
            this.gbFB.Controls.Add(this.radOR);
            this.gbFB.Controls.Add(this.radAND);
            this.gbFB.Controls.Add(this.cbFilter2Cond);
            this.gbFB.Controls.Add(this.btnCalc);
            this.gbFB.Controls.Add(this.cbFilter1Cond);
            this.gbFB.Controls.Add(this.txtFilter2);
            this.gbFB.Controls.Add(this.txtFilter1);
            this.gbFB.Controls.Add(this.DGV_FB);
            this.gbFB.Location = new System.Drawing.Point(13, 509);
            this.gbFB.Name = "gbFB";
            this.gbFB.Size = new System.Drawing.Size(800, 289);
            this.gbFB.TabIndex = 15;
            this.gbFB.TabStop = false;
            this.gbFB.Text = "Feedback";
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(429, 19);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(90, 23);
            this.btnSelect.TabIndex = 10;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.BtnSelect_Click);
            // 
            // chkInitFilter
            // 
            this.chkInitFilter.AutoSize = true;
            this.chkInitFilter.Location = new System.Drawing.Point(312, 51);
            this.chkInitFilter.Name = "chkInitFilter";
            this.chkInitFilter.Size = new System.Drawing.Size(250, 16);
            this.chkInitFilter.TabIndex = 9;
            this.chkInitFilter.Text = "From selected FB list / From this FB list";
            this.chkInitFilter.UseVisualStyleBackColor = true;
            this.chkInitFilter.CheckedChanged += new System.EventHandler(this.ChkInitFilter_CheckedChanged);
            // 
            // radOR
            // 
            this.radOR.AutoSize = true;
            this.radOR.Location = new System.Drawing.Point(371, 25);
            this.radOR.Name = "radOR";
            this.radOR.Size = new System.Drawing.Size(40, 16);
            this.radOR.TabIndex = 8;
            this.radOR.TabStop = true;
            this.radOR.Text = "OR";
            this.radOR.UseVisualStyleBackColor = true;
            // 
            // radAND
            // 
            this.radAND.AutoSize = true;
            this.radAND.Location = new System.Drawing.Point(312, 25);
            this.radAND.Name = "radAND";
            this.radAND.Size = new System.Drawing.Size(48, 16);
            this.radAND.TabIndex = 7;
            this.radAND.TabStop = true;
            this.radAND.Text = "AND";
            this.radAND.UseVisualStyleBackColor = true;
            // 
            // cbFilter2Cond
            // 
            this.cbFilter2Cond.FormattingEnabled = true;
            this.cbFilter2Cond.Items.AddRange(new object[] {
            "Included",
            "Not Included"});
            this.cbFilter2Cond.Location = new System.Drawing.Point(172, 49);
            this.cbFilter2Cond.Name = "cbFilter2Cond";
            this.cbFilter2Cond.Size = new System.Drawing.Size(121, 20);
            this.cbFilter2Cond.TabIndex = 6;
            // 
            // cbFilter1Cond
            // 
            this.cbFilter1Cond.FormattingEnabled = true;
            this.cbFilter1Cond.Items.AddRange(new object[] {
            "Included",
            "Not Included"});
            this.cbFilter1Cond.Location = new System.Drawing.Point(172, 21);
            this.cbFilter1Cond.Name = "cbFilter1Cond";
            this.cbFilter1Cond.Size = new System.Drawing.Size(121, 20);
            this.cbFilter1Cond.TabIndex = 5;
            // 
            // txtFilter2
            // 
            this.txtFilter2.Location = new System.Drawing.Point(15, 49);
            this.txtFilter2.Name = "txtFilter2";
            this.txtFilter2.Size = new System.Drawing.Size(150, 21);
            this.txtFilter2.TabIndex = 4;
            // 
            // txtFilter1
            // 
            this.txtFilter1.Location = new System.Drawing.Point(15, 21);
            this.txtFilter1.Name = "txtFilter1";
            this.txtFilter1.Size = new System.Drawing.Size(150, 21);
            this.txtFilter1.TabIndex = 3;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 815);
            this.Controls.Add(this.gbFB);
            this.Controls.Add(this.gbCA);
            this.Controls.Add(this.gbCT);
            this.Controls.Add(this.btnSelCont);
            this.Controls.Add(this.btnSelFB);
            this.Controls.Add(this.btnSelCA);
            this.Controls.Add(this.btnLoadCS);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_FB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_CA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_CT)).EndInit();
            this.gbCT.ResumeLayout(false);
            this.gbCA.ResumeLayout(false);
            this.gbFB.ResumeLayout(false);
            this.gbFB.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoadCS;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveProjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.DataGridView DGV_FB;
        private System.Windows.Forms.DataGridView DGV_CA;
        private System.Windows.Forms.Button btnSelCA;
        private System.Windows.Forms.Button btnSelFB;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnSelCont;
        private System.Windows.Forms.DataGridView DGV_CT;
        private System.Windows.Forms.GroupBox gbCT;
        private System.Windows.Forms.GroupBox gbCA;
        private System.Windows.Forms.GroupBox gbFB;
        private System.Windows.Forms.TextBox txtFilter2;
        private System.Windows.Forms.TextBox txtFilter1;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.CheckBox chkInitFilter;
        private System.Windows.Forms.RadioButton radOR;
        private System.Windows.Forms.RadioButton radAND;
        private System.Windows.Forms.ComboBox cbFilter2Cond;
        private System.Windows.Forms.ComboBox cbFilter1Cond;
    }
}

