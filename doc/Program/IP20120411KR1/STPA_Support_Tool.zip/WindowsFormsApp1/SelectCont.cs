﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STPATool
{
    public partial class SelectCont : Form
    {
        public SelectCont()
        {
            InitializeComponent();
        }

        private void SelectCont_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < MainForm.Cont.Count; i++)
            {
                if (!LB_CT.Items.Contains(MainForm.Cont[i])) LB_CT.Items.Add(MainForm.Cont[i]);
            }
        }

        private void BtnSelect_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
