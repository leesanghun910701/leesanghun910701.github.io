﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STPATool
{
    public partial class ResultCalc : Form
    {
        public ResultCalc()
        {
            InitializeComponent();
        }

        private void ResultCalc_Load(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Component", typeof(string));
            table.Columns.Add("V", typeof(string));
            table.Columns.Add("NiF", typeof(string));
            table.Columns.Add("IM", typeof(string));

            for (int i = 0; i < MainForm.Comp.Count; i++)
            {
                object[] values = new object[4];
                values[0] = MainForm.Comp[i].Name;
                values[1] = MainForm.CompNV[i];
                values[2] = MainForm.CompProp[i].ToString("N4");
                values[3] = MainForm.CompIM[i].ToString("N4");
                table.Rows.Add(values);
            }
            
            DGV_Res.DataSource = table;
            

        }
    }
}
