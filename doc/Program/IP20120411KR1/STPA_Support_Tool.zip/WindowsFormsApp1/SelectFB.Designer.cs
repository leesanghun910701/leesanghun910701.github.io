﻿namespace STPATool
{
    partial class SelectFB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LB_FB = new System.Windows.Forms.CheckedListBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.chkFBSelAll = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // LB_FB
            // 
            this.LB_FB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LB_FB.CheckOnClick = true;
            this.LB_FB.FormattingEnabled = true;
            this.LB_FB.Location = new System.Drawing.Point(13, 13);
            this.LB_FB.Name = "LB_FB";
            this.LB_FB.Size = new System.Drawing.Size(409, 212);
            this.LB_FB.TabIndex = 0;
            // 
            // btnSelect
            // 
            this.btnSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSelect.Location = new System.Drawing.Point(347, 231);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.BtnSelect_Click);
            // 
            // chkFBSelAll
            // 
            this.chkFBSelAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkFBSelAll.AutoSize = true;
            this.chkFBSelAll.Location = new System.Drawing.Point(13, 235);
            this.chkFBSelAll.Name = "chkFBSelAll";
            this.chkFBSelAll.Size = new System.Drawing.Size(77, 16);
            this.chkFBSelAll.TabIndex = 2;
            this.chkFBSelAll.Text = "Select All";
            this.chkFBSelAll.UseVisualStyleBackColor = true;
            this.chkFBSelAll.CheckedChanged += new System.EventHandler(this.ChkFBSelAll_CheckedChanged);
            // 
            // SelectFB
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 261);
            this.Controls.Add(this.chkFBSelAll);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.LB_FB);
            this.Name = "SelectFB";
            this.Text = "SelectFB";
            this.Load += new System.EventHandler(this.SelectFB_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.CheckedListBox LB_FB;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.CheckBox chkFBSelAll;
    }
}