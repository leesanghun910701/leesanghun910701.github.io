﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace sbdd
{
    class ClassSaveBdd
    {
        public static RAWfile PrimeImplicant;
        public static List<XaCutSetType> XCutsetppPI;
        public static List<List<int>> ModularGatePI;

        public static void SaveBDD(sbdd form, string TopName, string RawFileName, bool CmdMod) // RAW file: EPRI format
        {

            #region remove FALSE gates in XEvent

            // remove FALSE gates from ClassFtCircular
            for (int i = 2; i < ClassFtData.XEvent.Count; i++)
            {   
                if (ClassFtData.XEvent[i].Name == "FALSE") ClassFtData.XEvent.RemoveAt(i--);
            }

            #endregion

            #region save event data

            PrimeImplicant.XData.BlockName = "DATA";
            int EventNumber = ClassFtData.XEvent.Count;
            // PrimeImplicant.XData.NumOfEvent = EventNumber - 2; // excluding TRUE, FALSE
            PrimeImplicant.XData.NumOfEvent = EventNumber; // excluding TRUE, FALSE
            PrimeImplicant.XData.EventName = new string[PrimeImplicant.XData.NumOfEvent];
            PrimeImplicant.XData.EventProb = new float[PrimeImplicant.XData.NumOfEvent];
            
            for (int i = 2; i < EventNumber; i++)
            {
                string EventName = ClassFtData.XEvent[i].Name;
                if (EventName.Length > 4 && EventName.Substring(EventName.Length - 4, 4) == "_NOT")
                {
                    EventName = "/" + EventName.Substring(0, EventName.Length - 4);
                    PrimeImplicant.XData.EventName[i - 2] = EventName;
                    PrimeImplicant.XData.EventProb[i - 2] = 0;
                }
                else
                {
                    PrimeImplicant.XData.EventName[i - 2] = EventName;
                    PrimeImplicant.XData.EventProb[i - 2] = ClassFtData.XEvent[i].Prob;
                }
                
            }

            // add TRUE, FALSE events
            PrimeImplicant.XData.EventName[EventNumber - 2] = "FALSE";
            PrimeImplicant.XData.EventProb[EventNumber - 2] = 0.0f;

            PrimeImplicant.XData.EventName[EventNumber - 1] = "TRUE";
            PrimeImplicant.XData.EventProb[EventNumber - 1] = 1.0f;


            #endregion
            
            int TopIte = ClassFtData.XEvent[sbdd.TopIndex].ite;

            if (TopIte == 0) // FALSE (e.g., A * /A = FALSE)
            {

                PrimeImplicant.XCutset.BlockName = TopName;
                PrimeImplicant.XCutset.NumOfCutSet = 1;

                XaCutSetType FalseCutset = new XaCutSetType();
                FalseCutset.CutProba = 0.0f;
                FalseCutset.NoElem = 1;
                FalseCutset.Elems = new List<int> { EventNumber - 1 };

                sbdd.pCutset = 0.0f;
                sbdd.nCutset = 1;

                PrimeImplicant.XCutset.XaCutSet = new List<XaCutSetType>();
                PrimeImplicant.XCutset.XaCutSet.Add(FalseCutset);

                ClassRawFile.SaveRawFile(PrimeImplicant, RawFileName, TopName);

            }
            else if(TopIte == 1) // TRUE (e.g., A + /A = TRUE)
            {

                PrimeImplicant.XCutset.BlockName = TopName;
                PrimeImplicant.XCutset.NumOfCutSet = 1;

                XaCutSetType TrueCutset = new XaCutSetType();
                TrueCutset.CutProba = 1.0f;
                TrueCutset.NoElem = 1;
                TrueCutset.Elems = new List<int> { EventNumber };

                sbdd.pCutset = 1.0f;
                sbdd.nCutset = 1;

                PrimeImplicant.XCutset.XaCutSet = new List<XaCutSetType>();
                PrimeImplicant.XCutset.XaCutSet.Add(TrueCutset);

                ClassRawFile.SaveRawFile(PrimeImplicant, RawFileName, TopName);

            }
            else
            {
                
                #region save cutset data

                int[] EventList = new int[EventNumber];
                int EventNumberinPI = -1;
                XCutsetppPI = new List<XaCutSetType>();

                form.txtboxCmd.AppendText("Expanding Prime Implicant(s)... ");
                sbdd.CmdTxt += "Expanding Prime Implicant(s)... ";
                form.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                Stopwatch ExpandBddTime = new Stopwatch();
                ExpandBddTime.Start();

                ExpandBdd(TopIte, EventList, EventNumberinPI, 1.0f);

                ExpandBddTime.Stop();
                form.txtboxCmd.AppendText("(" + ExpandBddTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                sbdd.CmdTxt += "(" + ExpandBddTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
                form.Refresh();

                #endregion

                #region post-process for modular gate

                if (ClassModular.ModularGate.Count > 0)
                {
                    form.txtboxCmd.AppendText("Post-processing for modular gates... ");
                    sbdd.CmdTxt += "Post-processing for modular gates... ";

                    sbdd.RstTxt += sbdd.CmdTxt;
                    // if (CmdMod) Console.Write(sbdd.CmdTxt);
                    sbdd.CmdTxt = String.Empty;
                    ClassRawFile.WriteLogFile();


                    Stopwatch ExpandModTime = new Stopwatch();
                    ExpandModTime.Start();

                    XCutsetppPI = ClassModular.ExpandMod(XCutsetppPI);

                    ExpandModTime.Stop();

                    form.txtboxCmd.AppendText("(" + ExpandModTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                    sbdd.CmdTxt += "(" + ExpandModTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;

                    sbdd.RstTxt += sbdd.CmdTxt;
                    // if (CmdMod) Console.Write(sbdd.CmdTxt);
                    sbdd.CmdTxt = String.Empty;
                    ClassRawFile.WriteLogFile();

                }

                #endregion

                #region Sort by cutset value

                // if (NumOfCutSet > max cutset num), sort by cutset value -> print max cutset num to result file

                PrimeImplicant.XCutset.BlockName = TopName;
                List<XaCutSetType> XCutsetppPISort = XCutsetppPI.OrderByDescending(x => x.CutProba).ToList();
                PrimeImplicant.XCutset.XaCutSet = new List<XaCutSetType>();

                if (Constants.CutsetSort && XCutsetppPI.Count > Constants.maxCutset)
                {
                    sbdd.pCutset = 0.0f;
                    for (int i = 0; i < Constants.maxCutset; i++)
                    {
                        PrimeImplicant.XCutset.XaCutSet.Add(XCutsetppPISort[i]);
                        sbdd.pCutset += ClassSaveBdd.XCutsetppPI[i].CutProba;
                    }

                    PrimeImplicant.XCutset.NumOfCutSet = (int)Constants.maxCutset;
                    sbdd.nCutset = (int)Constants.maxCutset;
                }
                else
                {
                    PrimeImplicant.XCutset.XaCutSet = XCutsetppPISort;
                    PrimeImplicant.XCutset.NumOfCutSet = XCutsetppPISort.Count;
                    sbdd.nCutset = ClassSaveBdd.XCutsetppPI.Count;

                    sbdd.pCutset = 0.0f;
                    for (int i = 0; i < sbdd.nCutset; i++) { sbdd.pCutset += ClassSaveBdd.XCutsetppPI[i].CutProba; }
                }

                //if (!Constants.CutsetSort)
                //{
                //    PrimeImplicant.XCutset.XaCutSet = XCutsetppPISort;
                //    PrimeImplicant.XCutset.NumOfCutSet = XCutsetppPISort.Count;
                //    sbdd.nCutset = ClassSaveBdd.XCutsetppPI.Count;

                //    sbdd.pCutset = 0.0f;
                //    for (int i = 0; i < sbdd.nCutset; i++) { sbdd.pCutset += ClassSaveBdd.XCutsetppPI[i].CutProba; }
                //}
                //else
                //{
                //    if (XCutsetppPI.Count > Constants.maxCutset)
                //    {
                //        sbdd.pCutset = 0.0f;
                //        for (int i = 0; i < Constants.maxCutset; i++)
                //        {
                //            PrimeImplicant.XCutset.XaCutSet.Add(XCutsetppPISort[i]);
                //            sbdd.pCutset += ClassSaveBdd.XCutsetppPI[i].CutProba;
                //        }

                //        PrimeImplicant.XCutset.NumOfCutSet = (int)Constants.maxCutset;
                //        sbdd.nCutset = (int)Constants.maxCutset;
                //    }
                //}

                #endregion

                #region save raw file

                ClassRawFile.SaveRawFile(PrimeImplicant, RawFileName, TopName);

                #endregion

            }

        }

        public static void ExpandBdd(int ite, int[] EventList, int nEventinCutset, float prob)
        {

            switch (ite)
            {
                case 0: // FALSE -> Do nothing
                    break;

                case 1: // TRUE -> add cutset to PI

                    if (prob >= Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR)
                    {
                        XaCutSetType Cutset = new XaCutSetType();
                        Cutset.Elems = new List<int>();
                        int IENum = 0;
                        int SeqNum = 0;
                        
                        for (int i = 0; i < nEventinCutset + 1; i++)
                        {
                            #region check for non-sense cutset (double initiator)

                            if (ClassFtData.isEventIE(Math.Abs(EventList[i])))
                            {
                                if (EventList[i] < 0) continue; // if initiating event negate
                                IENum++;
                                if (IENum > 1) break;
                            }

                            if (ClassFtData.isEventSeq(Math.Abs(EventList[i])))
                            {
                                if (EventList[i] < 0) continue; // if sequence negate
                                SeqNum++;
                                if (SeqNum > 1) break;
                            }

                            #endregion
                            
                            Cutset.Elems.Add(Math.Sign(EventList[i]) * (Math.Abs(EventList[i]) - 1));
                        }

                        #region add to cutset (except non-sense cutsets)

                        if (IENum < 2 && SeqNum < 2)
                        {
                            Cutset.Elems.Remove(0);
                            Cutset.NoElem = Cutset.Elems.Count;
                            Cutset.CutProba = prob;
                            XCutsetppPI.Add(Cutset);
                        }

                        #endregion
                    }
                    break;

                default:

                    if (prob < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR) break;

                    #region expand for ite

                    int x = ClassIte.IteList[ite].x;
                    float prob_x = ClassFtData.XEvent[x].Prob;
                    int l = ClassIte.IteList[ite].l;
                    int r = ClassIte.IteList[ite].r;

                    // left side - positive
                    nEventinCutset++;
                    EventList[nEventinCutset] = x;
                    ExpandBdd(l, EventList, nEventinCutset, prob * prob_x);

                    // right side - negative
                    EventList[nEventinCutset] = -x;

                    // don't add to EventList if IE or Seq (e.g., /%SGTR, P(%SGTR) = 1.0)
                    if (ClassFtData.isEventSeq(x) || ClassFtData.isEventIE(x)) 
                    {
                        ExpandBdd(r, EventList, nEventinCutset - 1, prob);
                    }
                    else
                    {
                        ExpandBdd(r, EventList, nEventinCutset, prob * (1.0f - prob_x));
                    }

                    #endregion

                    break;
            }

        }
        
        public static List<List<int>> ExpandBddforMod(int ite, int[] EventList, int nEventinCutset, float prob)
        {
            
            switch (ite)
            {
                case 0: // FALSE -> Do nothing
                    break;

                case 1: // TRUE -> add cutset to ModularGatePI

                    if (prob >= Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR)
                    {

                        List<int> Cutset = new List<int>();
                        int IENum = 0;
                        int SeqNum = 0;

                        for (int i = 0; i < nEventinCutset + 1; i++)
                        {
                            #region check for non-sense cutset (double initiator)

                            if (ClassFtData.isEventIE(Math.Abs(EventList[i])))
                            {
                                if (EventList[i] < 0) continue; // if initiating event negate
                                IENum++;
                                if (IENum > 1) break;
                            }

                            if (ClassFtData.isEventSeq(Math.Abs(EventList[i])))
                            {
                                if (EventList[i] < 0) continue; // if sequence negate
                                SeqNum++;
                                if (SeqNum > 1) break;
                            }

                            #endregion

                            Cutset.Add(Math.Sign(EventList[i]) * (Math.Abs(EventList[i]) - 1));
                        }

                        #region add to cutset (except non-sense cutsets)

                        if (IENum < 2 && SeqNum < 2)
                        {
                            ModularGatePI.Add(Cutset);
                        }

                        #endregion
                        
                    }
                    break;

                default: // p > 1

                    if (prob < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR) break;

                    #region expand for ite

                    int x = ClassIte.IteList[ite].x;
                    float prob_x = ClassFtData.XEvent[x].Prob;
                    int l = ClassIte.IteList[ite].l;
                    int r = ClassIte.IteList[ite].r;

                    // left side - positive
                    nEventinCutset++;
                    EventList[nEventinCutset] = x;
                    ExpandBdd(l, EventList, nEventinCutset, prob * prob_x);

                    // right side - negative
                    EventList[nEventinCutset] = -x;

                    // don't add to EventList if IE or Seq (e.g., /%SGTR, P(%SGTR) = 1.0)
                    if (ClassFtData.isEventSeq(x) || ClassFtData.isEventIE(x))
                    {
                        ExpandBdd(r, EventList, nEventinCutset - 1, prob);
                    }
                    else
                    {
                        ExpandBdd(r, EventList, nEventinCutset, prob * (1.0f - prob_x));
                    }

                    #endregion

                    break;
            }

            return ModularGatePI;
        }


    }
}
