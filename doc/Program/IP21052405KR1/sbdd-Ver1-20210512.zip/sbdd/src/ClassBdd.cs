﻿using System.Collections.Generic;

namespace sbdd
{
    public class ClassBdd
    {   
        public static List<int> BddList;
        public static MultiKeyDictionary<int, int, int, int> BddListDict; // <op, ite1, ite2, ite_result>
        
        public static int BddSolve(char op, int g, int h)
        {
            // g <op> h
            // g = ite(x, gl, gr)
            // h = ite(y, hl, hr)
            
            int p, pl, pr, x, y, gl, gr, hl, hr;

            #region simple case
            // if G and H are same ite
            if (g == h) return g;

            // if G or H is TRUE or FALSE
            if (g <= 1 | h <= 1) 
            {
                if (op == '+') // +
                {
                    if (g == 0) return h; // 0 + H
                    if (g == 1) return 1; // 1 + H
                    if (h == 0) return g; // G + 0
                    if (h == 1) return 1; // G + 1
                }
                else if (op == '*')
                {
                    if (g == 0) return 0; // 0 * H
                    if (g == 1) return h; // 1 * H
                    if (h == 0) return 0; // G * 0
                    if (h == 1) return g; // G * 1
                }
                else
                {
                    
                }
            }
            #endregion

            #region solve bdd

            // find at hash table
            if (BddListDict.TryGetValue(op, g, h, out int bddid)) return BddList[bddid];

            // ulong bddkey = (ulong)op * (ulong)10000000000000000 + (ulong)g * (ulong)100000000 + (ulong)h;
            // if (BddListDict.TryGetValue(bddkey, out int bddid)) return BddList[bddid];
            
            // if g <op> h is new, solve bdd and create ite
            x = ClassIte.IteList[g].x;
            gl = ClassIte.IteList[g].l;
            gr = ClassIte.IteList[g].r;

            y = ClassIte.IteList[h].x;
            hl = ClassIte.IteList[h].l;
            hr = ClassIte.IteList[h].r;
  
            // if order (x < y) -> G <op> H = ite(x, G1 <op> H, G2 <op> H)
            if (ClassFtData.XEvent[x].BEOrder < ClassFtData.XEvent[y].BEOrder)
            {
                if ((ClassFtData.isEventIE(x) && ClassFtData.isEventIE(y)) || (ClassFtData.isEventSeq(x) && ClassFtData.isEventSeq(y)))
                {
                    // (2020-07-23)
                    //if (op == '*') pl = BddSolve(op, gl, hr);
                    //else pl = gl;
                    pl = BddSolve(op, gl, hr); 
                    pr = BddSolve(op, gr, h);
                    p = ClassIte.CreateIte(x, pl, pr);
                }
                else
                {
                    pl = BddSolve(op, gl, h);
                    pr = BddSolve(op, gr, h);
                    p = ClassIte.CreateIte(x, pl, pr);
                }
                
            }
            // if order (x > y) -> G <op> H = ite(y, G <op> Hl, G <op> Hr)
            else if (ClassFtData.XEvent[x].BEOrder > ClassFtData.XEvent[y].BEOrder)
            {
                if ((ClassFtData.isEventIE(x) && ClassFtData.isEventIE(y)) || (ClassFtData.isEventSeq(x) && ClassFtData.isEventSeq(y)))
                {
                    // (2020-07-23)
                    //if (op == '*') pl = BddSolve(op, hl, gr);
                    //else pl = hl;
                    pl = BddSolve(op, hl, gr); 
                    pr = BddSolve(op, hr, g);
                    p = ClassIte.CreateIte(y, pl, pr);
                }
                else
                {
                    pl = BddSolve(op, g, hl);
                    pr = BddSolve(op, g, hr);
                    p = ClassIte.CreateIte(y, pl, pr);
                }                
            }
            // if order (x = y) -> G <op> H = ite(x, Gl <op> Hl, Gr <op> Hr)
            else
            {
                pl = BddSolve(op, gl, hl);
                pr = BddSolve(op, gr, hr);
                p = ClassIte.CreateIte(x, pl, pr);
            }
            
            // add to hash table
            BddList.Add(p);
            bddid = BddList.Count - 1;
            BddListDict.Add(op, g, h, bddid);
            // BddListDict.Add(bddkey, bddid);
            #endregion

            return p;
        }

        public static int ZBddSolve(char op, int g, int h)
        {
            int p, pl, pr, x, y, gl, gr, hl, hr;
            int pl1, pl2, pl3, pl4;

            #region simple case
            // if G and H are same ite
            if (g == h) return g;

            // if G or H is TRUE or FALSE
            if (g <= 1 | h <= 1)
            {
                if (op == '+') // +
                {
                    if (g == 0) return h; // 0 + H
                    if (g == 1) return 1; // 1 + H
                    if (h == 0) return g; // G + 0
                    if (h == 1) return 1; // G + 1
                }
                else if (op == '*')
                {
                    if (g == 0) return 0; // 0 * H
                    if (g == 1) return h; // 1 * H
                    if (h == 0) return 0; // G * 0
                    if (h == 1) return g; // G * 1
                }
                else
                {

                }
            }
            #endregion

            #region solve bdd

            // find at hash table
            if (BddListDict.TryGetValue(op, g, h, out int bddid)) return BddList[bddid];

            // ulong bddkey = (ulong)op * (ulong)10000000000000000 + (ulong)g * (ulong)100000000 + (ulong)h;
            // if (BddListDict.TryGetValue(bddkey, out int bddid)) return BddList[bddid];

            // if g <op> h is new, solve bdd and create ite
            x = ClassIte.IteList[g].x;
            gl = ClassIte.IteList[g].l;
            gr = ClassIte.IteList[g].r;

            y = ClassIte.IteList[h].x;
            hl = ClassIte.IteList[h].l;
            hr = ClassIte.IteList[h].r;

            // if order (x < y) -> G <op> H = ite(x, Gl <op> H, G2 <op> H)
            if (ClassFtData.XEvent[x].BEOrder < ClassFtData.XEvent[y].BEOrder)
            {
                if ((ClassFtData.isEventIE(x) && ClassFtData.isEventIE(y)) || (ClassFtData.isEventSeq(x) && ClassFtData.isEventSeq(y)))
                {
                    if (op == '+') pl = gl;
                    else pl = ZBddSolve(op, gl, h);
                    pr = ZBddSolve(op, gr, h);
                    p = ClassIte.CreateIte(x, pl, pr);
                }
                else
                {
                    if (op == '+') // G <+> H = ite(x, Gl, Gr <+> H)
                    {
                        pl = gl;
                        pr = ZBddSolve(op, gr, h);
                        p = ClassIte.CreateIte(x, pl, pr);
                    }
                    else // op == '*', G <*> H = ite(x, G1 <*> H, G2 <*> H)
                    {
                        pl = ZBddSolve(op, gl, h);
                        pr = ZBddSolve(op, gr, h);
                        p = ClassIte.CreateIte(x, pl, pr);
                    }
                }

            }
            // if order (x > y) -> G <op> H = ite(y, G <op> Hl, G <op> Hr)
            else if (ClassFtData.XEvent[x].BEOrder > ClassFtData.XEvent[y].BEOrder)
            {
                if ((ClassFtData.isEventIE(x) && ClassFtData.isEventIE(y)) || (ClassFtData.isEventSeq(x) && ClassFtData.isEventSeq(y)))
                {
                    if (op == '+') pl = hl;
                    else pl = ZBddSolve(op, hl, g);
                    pr = ZBddSolve(op, hr, g);
                    p = ClassIte.CreateIte(y, pl, pr);
                }
                else
                {
                    if (op == '+')
                    {
                        pl = hl;
                        pr = ZBddSolve(op, hr, g);
                        p = ClassIte.CreateIte(y, pl, pr);
                    }
                    else // op == '*'
                    {
                        pl = ZBddSolve(op, hl, g);
                        pr = ZBddSolve(op, hr, g);
                        p = ClassIte.CreateIte(y, pl, pr);
                    }
                }
            }
            // if order (x = y) -> G <op> H = ite(x, Gl <op> Hl, Gr <op> Hr)
            else
            {   
                if (op == '+')
                {
                    pl = ZBddSolve(op, gl, hl);
                    pr = ZBddSolve(op, gr, hr);
                    p = ClassIte.CreateIte(x, pl, pr);
                }
                else // op == '*'
                {
                    pl1 = ZBddSolve('*', gl, hl);
                    pl2 = ZBddSolve('*', gr, hl);
                    pl3 = ZBddSolve('*', gl, hr);
                    pl4 = ZBddSolve('+', pl1, pl2);
                    pl = ZBddSolve('+', pl4, pl3);
                    pr = ZBddSolve(op, gr, hr);
                    p = ClassIte.CreateIte(x, pl, pr);
                }

            }

            // minimize bdd
            p = ClassMcs.MinimizeBdd(p);

            // add to hash table
            BddList.Add(p);
            bddid = BddList.Count - 1;
            BddListDict.Add(op, g, h, bddid);
            // BddListDict.Add(bddkey, bddid);
            #endregion

            return p;
        }

        public static int BddNegate(int p)
        {
            // ite = x * pl + /x * pr
            // negate(ite) = x * /pl + /x * /pr

            int x, pl, pr, npl, npr, nite;

            #region negate ite

            // calculate negate(ite)

            x = ClassIte.IteList[p].x;
            pl = ClassIte.IteList[p].l;
            pr = ClassIte.IteList[p].r;

            switch (pl)
            {
                case 0: npl = 1; break;
                case 1: npl = 0; break;
                default: npl = BddNegate(pl); break;
            }

            switch (pr)
            {
                case 0: npr = 1; break;
                case 1: npr = 0; break;
                default: npr = BddNegate(pr); break;
            }

            // save negate(ite)
            nite = ClassIte.CreateIte(x, npl, npr);

            #endregion
            
            return nite;
        }
        
    }
}
