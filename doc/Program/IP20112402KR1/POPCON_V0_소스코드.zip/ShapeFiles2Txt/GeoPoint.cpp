// GeoPoint.cpp: implementation of the GeoPoint class.
//
//////////////////////////////////////////////////////////////////////

#include "pch.h"
#include "GeoPoint.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GeoPoint::GeoPoint()
{
	InitializeInstanceFields();
}

GeoPoint::GeoPoint(double x, double y)
{
	InitializeInstanceFields();
	this->x = x;
	this->y = y;
	this->z = 0;
}

GeoPoint::GeoPoint(double x, double y, double z)
{
	InitializeInstanceFields();
	this->x = x;
	this->y = y;
	this->z = z;
}

GeoPoint::~GeoPoint()
{

}

void GeoPoint::setX(double fx)
{
	x = fx;
}

void GeoPoint::setY(double fy)
{
	y = fy;
}

void GeoPoint::setZ(double fz)
{
	z = fz;
}

double GeoPoint::getX()
{
	return x;
}

double GeoPoint::getY()
{
	return y;
}

double GeoPoint::getZ()
{
	return z;
}

void GeoPoint::InitializeInstanceFields()
{
	x = 0;
	y = 0;
	z = 0;
}