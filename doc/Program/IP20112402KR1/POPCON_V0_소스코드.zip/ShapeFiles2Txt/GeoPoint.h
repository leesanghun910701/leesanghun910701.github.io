#pragma once


class GeoPoint
{
public:
	double x;
	double y;
	double z;
	GeoPoint();
	GeoPoint(double x, double y);
	GeoPoint(double x, double y, double z);

	~GeoPoint();

	double getX();
	double getY();
	double getZ();

	void setX(double fx);
	void setY(double fy);
	void setZ(double fz);

private:
	void InitializeInstanceFields();
};
