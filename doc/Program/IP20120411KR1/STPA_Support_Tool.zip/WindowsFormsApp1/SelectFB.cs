﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STPATool
{
    public partial class SelectFB : Form
    {
        public SelectFB()
        {
            InitializeComponent();
        }

        private void SelectFB_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < MainForm.FBSig.Count; i++)
            {
                if (MainForm.FBSig[i].CALink.Intersect(MainForm.CASel).Count() == MainForm.CASel.Count)
                {
                    LB_FB.Items.Add(MainForm.FBSig[i].Name);
                }
            }
        }

        private void BtnSelect_Click(object sender, EventArgs e)
        {
            //if (chkFBSelAll.Checked)
            //{
            //    for (int i = 0; i < LB_FB.Items.Count; i++) LB_FB.SetItemChecked(i, true);
            //}

            Close();
        }

        private void ChkFBSelAll_CheckedChanged(object sender, EventArgs e)
        {
            if (!chkFBSelAll.Checked) { for (int i = 0; i < LB_FB.Items.Count; i++) LB_FB.SetItemChecked(i, false); }
            else { for (int i = 0; i < LB_FB.Items.Count; i++) LB_FB.SetItemChecked(i, true); }
        }
    }
}
