﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Diagnostics;

namespace sbdd
{
    class ClassFtCircular
    {

        public static List<Event> XEvent_circ;
        public static List<List<int>> CircularGatePathList;
        public static List<List<int>> CircularGateTopPathList;
        public static List<int> CircularPathGates;
        public static List<string> CircularTopName;
        public static List<string> ExpandCircularList;
        public static List<int> CircularTopList;
        public static List<CircGate> CircularGate;
        public static int[] CircularGateIndex;
        public static string CircFileName;

        public static void CheckCircular(sbdd form, string file, bool CmdMod)
        {
            sbdd.CircProcTime = new Stopwatch();
            sbdd.CircProcTime.Start();

            #region define TRUE, FALSE, XEvent_circ

            // define TRUE/FALSE event

            Event Event = new Event();
            Event.Name = "FALSE";
            Event.Type = 'B';
            Event.Prob = 0.0f;
            Event.Child = new List<int>();
            Event.BEOrder = 0;
            Event.ite = 0;
            XEvent_circ.Add(Event);

            Event = new Event();
            Event.Name = "TRUE";
            Event.Type = 'B';
            Event.Prob = 1.0f;
            Event.Child = new List<int>();
            Event.BEOrder = 0;
            Event.ite = 0;
            XEvent_circ.Add(Event);

            // read fault-tree block

            ReadGateBlockC(file);

            #endregion

            #region get circular gate path

            // get circular gate path
            int TopIndex = GetEventIndex_circ(sbdd.TopName);
            List<int> CircularGatePath = new List<int>();
            GetCircularTopPath(TopIndex, CircularGatePath); // -> CircularGateTopPathList            

            #endregion

            #region get circular gate lists

            // save circular gates and its parent gates
            GetCircularGateList(); // -> CircularGate, CircularGateList

            form.txtboxCmd.AppendText("(" + CircularTopList.Count.ToString() + " circular top(s) found)" + Environment.NewLine);
            form.txtboxCmd.AppendText("Processing circular gates... ");

            sbdd.CmdTxt += "(" + CircularTopList.Count.ToString() + " circular top(s) found)" + Environment.NewLine;
            sbdd.CmdTxt += "Processing circular gates... ";

            sbdd.RstTxt += sbdd.CmdTxt;
            

            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();


            #endregion

            #region expand for circular top

            CircularGateIndex = new int[XEvent_circ.Count];
            for (int i = 0; i < CircularTopList.Count; i++)
            {
                // initialize variables
                CircularGatePathList = new List<List<int>>();
                CircularPathGates = new List<int>();
                
                // get circular gate path for each circular tops 
                int GateIndex = CircularTopList[i];                                
                CircularGatePath = new List<int>();
                GetCircularGatePath(GateIndex, CircularGatePath); // -> CircularGatePathList, CircularPathGates
                CircularPathGates = CircularPathGates.Distinct().ToList();

                // expand for each circular top and save new line (change circular gates to TRUE/FALSE event)
                List<int> GatePath = new List<int>();
                GatePath.Add(GateIndex);
                CircularGateIndex[GateIndex]++;
                ExpandCircular(GateIndex, GatePath); // -> ExpandCircularList

                // save each CircularTopLine and CircularTopName
                string CircularTopLine = ExpandCircularList[ExpandCircularList.Count - 1];
                string[] LineSplit = CircularTopLine.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);
                CircularTopName.Add(LineSplit[0]);
            }
            
            #endregion

            sbdd.CircProcTime.Stop();

            form.txtboxCmd.AppendText("(" + sbdd.CircProcTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += "(" + sbdd.CircProcTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();


            #region save circular file

            WriteCircularFile(form, file);

            #endregion

        }

        public static void ReadGateBlockC(string file)
        {
            StreamReader strReader = new StreamReader(file);

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    // split line
                    if (String.Equals(Line, "ENDTREE")) break;
                    string[] LineSplit = Line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                    // define gate index, type
                    int GateIndex = GetEventIndex_circ(LineSplit[0]);
                    Event Event = XEvent_circ[GateIndex];
                    Event.Type = Convert.ToChar(LineSplit[1]);

                    // define gate child(s)
                    for (int j = 2; j < LineSplit.Length; j++)
                    {
                        int ChildIndex = GetEventIndex_circ(LineSplit[j]);
                        Event.Child.Add(ChildIndex);
                    }

                    // save gate information
                    XEvent_circ[GateIndex] = Event;
                }
            }

            strReader.Close();
        }

        public static int GetEventIndex_circ(string EvtName)
        {
            int Negate = 1;

            if (String.Equals(EvtName.Substring(0, 1), "-"))
            {
                Negate = -1;
                EvtName = EvtName.Substring(1, EvtName.Length - 1);
            }

            int EventIndex = XEvent_circ.FindIndex(xEvent => xEvent.Name == EvtName);
            // if old event, return index
            if (EventIndex > -1)
            {
                return EventIndex * Negate;
            }
            // if new event, add to XEvent_circ
            else
            {
                Event Event = new Event();
                Event.Name = EvtName;
                Event.Type = ' ';
                Event.Prob = 0.0f;
                Event.Child = new List<int>();
                Event.BEOrder = 0;
                Event.ite = 0;
                XEvent_circ.Add(Event);

                return (XEvent_circ.Count - 1) * Negate;
            }
        }

        public static void GetCircularTopPath(int GateIndex, List<int> CircularGatePath)
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = XEvent_circ[GateIndex];

            if (Gate.Child.Count > 0)
            {
                // add gate to CircularGatePath
                CircularGatePath.Add(GateIndex);
                
                for (int i = 0; i < Gate.Child.Count; i++)
                {
                    int ChildIndex = Gate.Child[i];

                    #region if CircularGatePath contains ChildIndex -> save circular paths

                    // if CircularGatePath contains ChildIndex -> Circular -> Add CircularGatePath to CircularGatePathList
                    if (CircularGatePath.Contains(ChildIndex))
                    {
                        // copy CircularGatePath to GatePath
                        List<int> GatePath = new List<int>();
                        for (int j = 0; j < CircularGatePath.Count; j++) GatePath.Add(CircularGatePath[j]);
                        GatePath.Add(ChildIndex);

                        // save GateTopPathList
                        List<int> GateTopPathList = new List<int>();
                        int CircularGateTopPathIndex = CircularGatePath.IndexOf(ChildIndex);
                        for (int j = 0; j < CircularGateTopPathIndex + 1; j++) GateTopPathList.Add(CircularGatePath[j]);

                        for (int j = 0; j < CircularGateTopPathList.Count; j++)
                        {
                            List<int> PathIntersect = CircularGateTopPathList[j].Intersect(GateTopPathList).ToList();
                            if (GateTopPathList.SequenceEqual(PathIntersect))
                            {
                                CircularGateTopPathList.RemoveAt(j); j--;
                            }
                        }
                        CircularGateTopPathList.Add(GateTopPathList);

                        // stop finding circular path -> go to next child
                        continue;
                    }

                    #endregion

                    #region if CircularGatePath does not contain Child --> continue finding circular path

                    GetCircularTopPath(ChildIndex, CircularGatePath);

                    #endregion
                }

                // Remove gate from CircularGatePath
                CircularGatePath.Remove(GateIndex);
            }
        }

        public static void GetCircularTopPath_original(int GateIndex, List<int> CircularGatePath)
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = XEvent_circ[GateIndex];
            
            if (Gate.Child.Count > 0)
            {
                // add gate to CircularGatePath
                CircularGatePath.Add(GateIndex);

                #region if CircularGatePath are already calculated, continue.
                bool CircularGatePathAlreadyIncluded = false;
                for (int j = 0;  j < CircularGateTopPathList.Count; j++)
                {
                    List<int> PathIntersect = CircularGateTopPathList[j].Intersect(CircularGatePath).ToList();
                    if (CircularGateTopPathList[j].SequenceEqual(PathIntersect))
                    {
                        CircularGatePathAlreadyIncluded = true;
                        break;
                    }
                }
                #endregion

                #region if CircularGatePath are new, calculate CircularGateTopPathList
                if (!CircularGatePathAlreadyIncluded)
                {
                    for (int i = 0; i < Gate.Child.Count; i++)
                    {
                        int ChildIndex = Gate.Child[i];

                        #region if CircularGatePath contains ChildIndex -> save circular paths

                        // if CircularGatePath contains ChildIndex -> Circular -> Add CircularGatePath to CircularGatePathList
                        if (CircularGatePath.Contains(ChildIndex))
                        {
                            // copy CircularGatePath to GatePath
                            List<int> GatePath = new List<int>();
                            for (int j = 0; j < CircularGatePath.Count; j++) GatePath.Add(CircularGatePath[j]);
                            GatePath.Add(ChildIndex);

                            // save GateTopPathList
                            List<int> GateTopPathList = new List<int>();
                            int CircularGateTopPathIndex = CircularGatePath.IndexOf(ChildIndex);
                            for (int j = 0; j < CircularGateTopPathIndex + 1; j++) GateTopPathList.Add(CircularGatePath[j]);

                            // 1) check if GateTopPathList is already included to CircularGateTopPathList
                            //    --> do nothing (dont add GateTopPathList to CircularGateTopPathList)
                            bool GateTopPathListAlreadyIncluded = false;
                            for (int j = 0; j < CircularGateTopPathList.Count; j++)
                            {
                                List<int> PathIntersect = CircularGateTopPathList[j].Intersect(GateTopPathList).ToList();
                                if (CircularGateTopPathList[j].SequenceEqual(PathIntersect))
                                {
                                    GateTopPathListAlreadyIncluded = true; break;
                                }
                            }

                            // 2) check if CircularGateTopPathList is included to GateTopPathList
                            //    --> remove CircularGateTopPathList & add GateTopPathList to CircularGateTopPathList
                            if (!GateTopPathListAlreadyIncluded)
                            {
                                for (int j = 0; j < CircularGateTopPathList.Count; j++)
                                {
                                    List<int> PathIntersect = CircularGateTopPathList[j].Intersect(GateTopPathList).ToList();
                                    if (GateTopPathList.SequenceEqual(PathIntersect))
                                    {
                                        CircularGateTopPathList.RemoveAt(j); j--;
                                    }
                                }
                                CircularGateTopPathList.Add(GateTopPathList);
                            }

                            // stop finding circular path -> go to next child
                            continue;
                        }

                        #endregion

                        #region if CircularGatePath does not contain Child --> continue finding circular path

                        GetCircularTopPath(ChildIndex, CircularGatePath);

                        #endregion
                    }
                }
                #endregion

                // Remove gate from CircularGatePath
                CircularGatePath.Remove(GateIndex);
            }
        }

        public static void GetCircularGateList()
        {

            for (int i = 0; i < CircularGateTopPathList.Count; i++)
            {
                CircGate NewCircularGt;
                NewCircularGt.Child = new List<int>();

                List<int> CircularGateTopPath = CircularGateTopPathList[i];
                int ParentIndex = CircularGateTopPath[CircularGateTopPath.Count - 2];
                int ChildIndex = CircularGateTopPath[CircularGateTopPath.Count - 1];                
                int CircularGateInd = CircularGate.FindIndex(x => x.Parent == ParentIndex);

                #region if parent not exist in CircularGate, add NewCircularGt to CircularGate.
                if (CircularGateInd < 0)
                {
                    NewCircularGt.Parent = ParentIndex;
                    NewCircularGt.Child.Add(ChildIndex);
                    CircularGate.Add(NewCircularGt);
                }
                #endregion

                #region if parent exist in CircularGate, check for child and add if not exist

                else
                {
                    List<int> CircularGateChild = CircularGate[CircularGateInd].Child;
                    if (!CircularGateChild.Contains(ChildIndex)) CircularGateChild.Add(ChildIndex);
                }

                #endregion

            }

            #region save CircularTopList
            for (int i = 0; i < CircularGateTopPathList.Count; i++)
            {
                List<int> CircularGateTopPath = CircularGateTopPathList[i];
                int CircularTop = CircularGateTopPath[CircularGateTopPath.Count - 1];
                if (!CircularTopList.Contains(CircularTop))
                {
                    CircularTopList.Add(CircularTop);
                }
            }
            #endregion
        }
        
        public static void GetCircularGatePath(int GateIndex, List<int> CircularGatePath)
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = XEvent_circ[GateIndex];

            if (Gate.Child.Count > 0)
            {
                // add gate to CircularGatePath
                CircularGatePath.Add(GateIndex);
                for (int i = 0; i < Gate.Child.Count; i++)
                {
                    int ChildIndex = Gate.Child[i];

                    #region if CircularGatePath contains ChildIndex -> save circular paths

                    // if CircularGatePath contains ChildIndex -> Circular -> Add CircularGatePath to CircularGatePathList
                    if (CircularGatePath.Contains(ChildIndex))
                    {
                        // copy CircularGatePath to GatePath
                        List<int> GatePath = new List<int>();
                        for (int j = 0; j < CircularGatePath.Count; j++)
                        {
                            GatePath.Add(CircularGatePath[j]);
                            CircularPathGates.Add(CircularGatePath[j]);                            
                        }
                        GatePath.Add(ChildIndex);
                        
                        // copy GatePath to CircularGatePathList
                        CircularGatePathList.Add(GatePath);

                        // save gate id related to circular paths (CircularPathGates)
                        CircularPathGates.Add(ChildIndex);
                        
                        // stop finding circular path -> go to next child
                        continue;
                    }

                    #endregion

                    #region if CircularGatePath does not contain Child --> continue finding circular path

                    GetCircularGatePath(ChildIndex, CircularGatePath);

                    #endregion
                }

                // Remove gate from CircularGatePath
                CircularGatePath.Remove(GateIndex);
            }
        }
        
        public static void ExpandCircular(int GateIndex, List<int> GatePath)
        {
            GateIndex = Math.Abs(GateIndex);
            Event Gate = XEvent_circ[GateIndex];
            
            if (Gate.Child.Count > 0 && CircularPathGates.Contains(GateIndex))
            {
                
                string NewGateName = Gate.Name + "_Circ" + CircularGateIndex[GateIndex].ToString();
                string NewLine = NewGateName + " " + Gate.Type + " ";
                
                for (int i = 0; i < Gate.Child.Count; i++)
                {
                    int ChildIndex = Gate.Child[i];
                    int ChildSign = Math.Sign(ChildIndex);
                    ChildIndex = Math.Abs(ChildIndex);
                    Event Child = XEvent_circ[ChildIndex];
                    GatePath.Add(ChildIndex);
                    int GatePathLength = GatePath.Count;
                    
                    #region if child is circular gate -> change to TRUE/FALSE event.

                    bool GatePathEqualsToCircularGatePathList = false;

                    if (CircularPathGates.Contains(ChildIndex)) 
                    {
                        for (int j = 0; j < CircularGatePathList.Count; j++) // Circular
                        {
                            if (GatePath.SequenceEqual(CircularGatePathList[j]))
                            {
                                GatePathEqualsToCircularGatePathList = true;
                                break;
                            }
                        }

                        // if GatePath is contained in CircularGatePathList, change circular gate to TRUE/FALSE event
                        if (GatePathEqualsToCircularGatePathList)
                        {
                            if (ChildSign < 0) NewLine += "TRUE ";
                            else NewLine += "FALSE ";
                        }
                        // if GatePath not contained in CircularGatePathList, create as new gate name (_circ)
                        else
                        {
                            CircularGateIndex[ChildIndex]++;
                            if (ChildSign < 0) NewLine += "-";
                            NewLine += Child.Name + "_Circ" + CircularGateIndex[ChildIndex].ToString() + " ";
                        }
                    }

                    #endregion

                    #region if child is not circular gate, just add gate name
                    else
                    {
                        if (ChildSign < 0) NewLine += "-";
                        NewLine += Child.Name + " ";
                    }
                    #endregion

                    #region if child is not circular gate, expand for child
                    if (Child.Child.Count > 0 && GatePathEqualsToCircularGatePathList == false)
                    {
                        ExpandCircular(ChildIndex, GatePath);
                    }
                    #endregion

                    GatePath.RemoveAt(GatePathLength - 1);
                }

                // add new line to ExpandCircularList
                ExpandCircularList.Add(NewLine);
            }
        }

        public static void WriteCircularFile(sbdd form, string file)
        {
            StreamReader strReader = new StreamReader(file);
            string FileName = Path.GetFileNameWithoutExtension(sbdd.InputFilePath);
            FileName = FileName.Substring(0, FileName.Length - 5); // "_flag" 제거
            string CircFileNameOnly = FileName + "_circ" + Path.GetExtension(sbdd.InputFilePath);
            CircFileName = sbdd.WorkingDir + "\\" + CircFileNameOnly;

            if (File.Exists(CircFileName)) { File.Delete(CircFileName); }
            StreamWriter strWriter = new StreamWriter(new FileStream(CircFileName, FileMode.Create));

            #region modify child gates which are circular gates
            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (String.Equals(Line, "ENDTREE")) { break; }
                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    // check for gates that are circulargates
                    if (CircularGatePathList.Count > 0)
                    {
                        string[] LineSplit = Line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                        // change parent/child gates where child gate is circular gate
                        for (int i = 0; i < CircularGate.Count; i++)
                        {
                            if (LineSplit[0] == XEvent_circ[CircularGate[i].Parent].Name) // if parent name is same
                            {
                                for (int j = 2; j < LineSplit.Length; j++)
                                {
                                    for (int k = 0; k < CircularGate[i].Child.Count; k++)
                                    {
                                        if (LineSplit[j] == XEvent_circ[CircularGate[i].Child[k]].Name) // if child name is same
                                        {
                                            // 해당 child를 CircularTopName으로 변경
                                            int CircularTopNameIndex = CircularTopList.FindIndex(x => x == CircularGate[i].Child[k]);
                                            LineSplit[j] = CircularTopName[CircularTopNameIndex];
                                        }
                                    }
                                }
                            }
                        }
                                                
                        // make new line and write
                        string NewLine = String.Empty;
                        for (int i = 0; i < LineSplit.Length; i++) NewLine += LineSplit[i] + " ";
                        strWriter.WriteLine(NewLine);
                    }
                    else
                    {
                        strWriter.WriteLine(Line);
                    }
                }
                else
                {
                    strWriter.WriteLine(Line);
                }

            }
            #endregion

            #region write circular gates related to circular top

            for (int i = 0; i < ExpandCircularList.Count; i++)
            {
                strWriter.WriteLine(ExpandCircularList[i]);
            }

            #endregion

            #region write rest of original file
            
            strWriter.WriteLine("ENDTREE");
            
            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;
                strWriter.WriteLine(Line);
            }

            #endregion

            strReader.Close();
            strWriter.Close();
        }
        
    }
}
