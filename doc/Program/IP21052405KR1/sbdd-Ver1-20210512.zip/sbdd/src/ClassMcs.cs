﻿using System.Collections.Generic;

namespace sbdd
{
    class ClassMcs
    {
        public static Dictionary<int, int> MinBddDict;
        public static MultiKeyDictionary<int, int, int> MinByDict;
        // public static Dictionary<ulong, int> MinByDict;

        public static int MinimizeBdd(int p)
        {
            int x, l, r, lmin, rmin;
            
            #region simple case

            if (p == 0 || p == 1) return p;

            #endregion

            #region find at hashtable

            int minkey = p;
            if (MinBddDict.TryGetValue(minkey, out int minid)) return minid;

            #endregion

            #region minimize p

            r = ClassIte.IteList[p].r;
            if (r == 1) return 1; // p = x * l + 1 = 1

            l = ClassIte.IteList[p].l;
            if (l == 0) p = MinimizeBdd(r); // p = 0 + r = r - r에 대해 minimize 계속.

            l = ClassIte.IteList[p].l;
            r = ClassIte.IteList[p].r;
            if (l == r) p = MinimizeBdd(r); // p = x * r + r = r - r에 대해 minimize 계속
            
            // p = x * l + \x* r
            x = ClassIte.IteList[p].x;
            l = ClassIte.IteList[p].l;
            r = ClassIte.IteList[p].r;

            #endregion

            #region rare-event approximation

            rmin = MinimizeBdd(r);
            if (rmin == 1) return 1;
            lmin = MinimizeBdd(l);

            #endregion

            #region delete-term process

            lmin = MinimizeBy(lmin, rmin);
            if (lmin == 0) p = rmin; // p = x * 0 + r = r
            else p = ClassIte.CreateIte(x, lmin, rmin);

            #endregion

            #region if new, add to hashtable

            MinBddDict.Add(minkey, p);

            #endregion

            return p;

        }

        public static int MinimizeBy(int f, int g)
        {
            int x, y, fl, fr, gl, gr, p, pl, pr;

            #region special case

            if (f == 0) return 0;
            if (g == 1) return 0;
            if (g == 0) return f;
            if (f == 1) return 1;
            if (f == g) return 0;

            #endregion

            #region find at hashtable

            if (MinByDict.TryGetValue(f, g, out int minbyid)) return minbyid;

            // ulong MinKey = (ulong)f * (ulong)100000000 + (ulong)g;
            // if (MinByDict.TryGetValue(MinKey, out int minbyid)) return minbyid;

            #endregion

            #region minimize f by g

            //   f = x * fl + fr
            x = ClassIte.IteList[f].x;
            fl = ClassIte.IteList[f].l;
            fr = ClassIte.IteList[f].r;

            //   g = y * gl + gr
            y = ClassIte.IteList[g].x;
            gl = ClassIte.IteList[g].l;
            gr = ClassIte.IteList[g].r;

            if (ClassFtData.XEvent[x].BEOrder < ClassFtData.XEvent[y].BEOrder)
            {
                // if order (x < y) -> f <op> g = ite(x, fl <op> g, fr <op> g)
                pl = MinimizeBy(fl, g); // minimize fl by g
                pr = MinimizeBy(fr, g); // minimize fr by g
                p = ClassIte.CreateIte(x, pl, pr);
            }
            else if (ClassFtData.XEvent[x].BEOrder > ClassFtData.XEvent[y].BEOrder)
            {
                // if order (x > y) -> f <op> g = ite(y, f <op> gl, f <op> gr)
                // gl은 y에 묶여있음. (y * gl + /y * gr)
                // --> f를 minimize 함에 있어, f랑 gr만 비교한다.
                p = MinimizeBy(f, gr);  // minimize f by gr
            }
            else
            {
                // if order (x = y) -> f <op> g = ite(x, fl <op> gl, fr <op> gr)
                pl = MinimizeBy(fl, gl); // minimize fl  by gl
                pl = MinimizeBy(pl, gr); // rare-event approximation에 의해 negation term 무시되므로, fl을 gr과도 비교.
                pr = MinimizeBy(fr, gr); // minimize fr by g
                p = ClassIte.CreateIte(x, pl, pr);
            }

            #endregion

            #region if new, add to hashtable

            MinByDict.Add(f, g, p);
            // MinByDict.Add(MinKey, p);

            #endregion

            return p;
            
        }
        
    }
}
