﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace sbdd
{
    class ClassSaveMcs
    {
        public static RAWfile MinimalCutSet;
        public static List<XaCutSetType> XCutsetppMCS;
        public static List<List<int>> ModularGateCutSet;
        public static float mcs_val;

        public static void SaveMCS(sbdd form, string TopName, string RawFileName, bool CmdMod)
        {

            #region minimize top

            form.txtboxCmd.AppendText("Minimizing ..." + Environment.NewLine);
            sbdd.CmdTxt += "Minimizing ..." + Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();
            form.Refresh();

            Stopwatch MinTopTime = new Stopwatch();
            MinTopTime.Start();

            int TopIte = ClassFtData.XEvent[sbdd.TopIndex].ite;
            if (!'z'.Equals(Char.ToLower(Constants.mcs))) { TopIte = ClassMcs.MinimizeBdd(TopIte); }

            Event Event = ClassFtData.XEvent[sbdd.TopIndex];
            Event.ite = TopIte;
            ClassFtData.XEvent[sbdd.TopIndex] = Event;

            MinTopTime.Stop();

            form.txtboxCmd.AppendText("Minimized for " + TopName + " (" + MinTopTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += "Minimized for " + TopName + " (" + MinTopTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();
            form.Refresh();

            #endregion

            #region remove FALSE gates in XEvent

            // remove FALSE gates from ClassFtCircular
            for (int i = 2; i < ClassFtData.XEvent.Count; i++)
            {   
                if (ClassFtData.XEvent[i].Name == "FALSE") ClassFtData.XEvent.RemoveAt(i--); 
            }

            #endregion

            #region save event data

            MinimalCutSet.XData.BlockName = "DATA";
            int EventNumber = ClassFtData.XEvent.Count;
            // MinimalCutSet.XData.NumOfEvent = EventNumber - 2; // excluding TRUE, FALSE
            MinimalCutSet.XData.NumOfEvent = EventNumber; // excluding TRUE, FALSE
            MinimalCutSet.XData.EventName = new string[MinimalCutSet.XData.NumOfEvent];
            MinimalCutSet.XData.EventProb = new float[MinimalCutSet.XData.NumOfEvent];

            for (int i = 2; i < EventNumber; i++)
            {
                string EventName = ClassFtData.XEvent[i].Name;
                if (EventName.Length > 4 && EventName.Substring(EventName.Length - 4, 4) == "_NOT")
                {
                    EventName = "/" + EventName.Substring(0, EventName.Length - 4);
                    MinimalCutSet.XData.EventName[i - 2] = EventName;
                    MinimalCutSet.XData.EventProb[i - 2] = 0;
                }
                else
                {
                    MinimalCutSet.XData.EventName[i - 2] = EventName;
                    MinimalCutSet.XData.EventProb[i - 2] = ClassFtData.XEvent[i].Prob;
                }                
            }

            // add TRUE, FALSE event
            MinimalCutSet.XData.EventName[EventNumber - 2] = "FALSE";
            MinimalCutSet.XData.EventProb[EventNumber - 2] = 0.0f;

            MinimalCutSet.XData.EventName[EventNumber - 1] = "TRUE";
            MinimalCutSet.XData.EventProb[EventNumber - 1] = 1.0f;

            #endregion

            #region save cutset data

            int[] EventList = new int[EventNumber];
            int EventNumberinCutSet = -1;
            XCutsetppMCS = new List<XaCutSetType>();

            form.txtboxCmd.AppendText("Expanding minimal cutset(s)... ");
            sbdd.CmdTxt += "Expanding minimal cutset(s)... ";
            form.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();
            
            Stopwatch ExpandMcsTime = new Stopwatch();
            ExpandMcsTime.Start();

            if (ClassFtData.EventProbExceedOne) { Constants.Cutoff = Constants.oCutoff; }
            ExpandMCS(TopIte, EventList, EventNumberinCutSet, 1.0f);

            ExpandMcsTime.Stop();

            form.txtboxCmd.AppendText("(" + ExpandMcsTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += "(" + ExpandMcsTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
            form.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // if (CmdMod) Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            #endregion
            
            // expand 했는데 XCutsetppMCS.Count = 0이면 false,
            // expand 했는데 prob = 1이면 true?

            if (XCutsetppMCS.Count == 0) // FALSE (e.g., A * /A = FALSE, below cutoff value)
            {
                MinimalCutSet.XCutset.BlockName = TopName;
                MinimalCutSet.XCutset.NumOfCutSet = 1;

                XaCutSetType FalseCutset = new XaCutSetType();
                FalseCutset.CutProba = 0.0f;
                FalseCutset.NoElem = 1;
                FalseCutset.Elems = new List<int> { EventNumber - 1 };

                sbdd.pCutset = 0.0f;
                sbdd.nCutset = 1;

                MinimalCutSet.XCutset.XaCutSet = new List<XaCutSetType>();
                MinimalCutSet.XCutset.XaCutSet.Add(FalseCutset);

                ClassRawFile.SaveRawFile(MinimalCutSet, RawFileName, TopName);
            }
            //else if (mcs_val == 1.0f) // TRUE (e.g., A + /A = TRUE)
            //{
            //    MinimalCutSet.XCutset.BlockName = TopName;
            //    MinimalCutSet.XCutset.NumOfCutSet = 1;

            //    XaCutSetType TrueCutset = new XaCutSetType();
            //    TrueCutset.CutProba = 1.0f;
            //    TrueCutset.NoElem = 1;
            //    TrueCutset.Elems = new List<int> { EventNumber };

            //    sbdd.pCutset = 1.0f;
            //    sbdd.nCutset = 1;

            //    MinimalCutSet.XCutset.XaCutSet = new List<XaCutSetType>();
            //    MinimalCutSet.XCutset.XaCutSet.Add(TrueCutset);

            //    ClassRawFile.SaveRawFile(MinimalCutSet, RawFileName, TopName);
            //}
            else
            {
                #region post-process for modular gate

                if (Constants.modular == 1 && ClassModular.ModularGate.Count > 0)
                {
                    form.txtboxCmd.AppendText("Post-processing for modular gates... ");
                    sbdd.CmdTxt += "Post-processing for modular gates... ";

                    sbdd.RstTxt += sbdd.CmdTxt;
                    // if (CmdMod) Console.Write(sbdd.CmdTxt);
                    sbdd.CmdTxt = String.Empty;
                    ClassRawFile.WriteLogFile();


                    Stopwatch ExpandModTime = new Stopwatch();
                    ExpandModTime.Start();

                    XCutsetppMCS = ClassModular.ExpandMod(XCutsetppMCS);

                    ExpandModTime.Stop();

                    form.txtboxCmd.AppendText("(" + ExpandModTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                    sbdd.CmdTxt += "(" + ExpandModTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;

                    sbdd.RstTxt += sbdd.CmdTxt;
                    // if (CmdMod) Console.Write(sbdd.CmdTxt);
                    sbdd.CmdTxt = String.Empty;
                    ClassRawFile.WriteLogFile();


                    MinimalCutSet.XCutset.XaCutSet = XCutsetppMCS;
                    MinimalCutSet.XCutset.NumOfCutSet = XCutsetppMCS.Count;
                }

                #endregion

                #region Sort by cutset value

                // if (NumOfCutSet > max cutset num), sort by cutset value -> print max cutset num to result file

                MinimalCutSet.XCutset.BlockName = TopName;
                List<XaCutSetType> XCutsetppMCSSort = XCutsetppMCS.OrderByDescending(x => x.CutProba).ToList();
                MinimalCutSet.XCutset.XaCutSet = new List<XaCutSetType>();

                if (Constants.CutsetSort && XCutsetppMCS.Count > Constants.maxCutset)
                {
                    sbdd.pCutset = 0.0f;
                    for (int i = 0; i < Constants.maxCutset; i++)
                    {
                        MinimalCutSet.XCutset.XaCutSet.Add(XCutsetppMCSSort[i]);
                        sbdd.pCutset += XCutsetppMCSSort[i].CutProba;
                    }

                    MinimalCutSet.XCutset.NumOfCutSet = (int)Constants.maxCutset;
                    sbdd.nCutset = (int)Constants.maxCutset;
                }
                else
                {
                    MinimalCutSet.XCutset.XaCutSet = XCutsetppMCSSort;
                    MinimalCutSet.XCutset.NumOfCutSet = XCutsetppMCSSort.Count;
                    sbdd.nCutset = ClassSaveMcs.XCutsetppMCS.Count;

                    sbdd.pCutset = 0.0f;
                    for (int i = 0; i < sbdd.nCutset; i++) sbdd.pCutset += XCutsetppMCS[i].CutProba;
                }

                //if (!Constants.CutsetSort)
                //{
                //    MinimalCutSet.XCutset.XaCutSet = XCutsetppMCSSort;
                //    MinimalCutSet.XCutset.NumOfCutSet = XCutsetppMCSSort.Count;
                //    sbdd.nCutset = XCutsetppMCS.Count;

                //    sbdd.pCutset = 0.0f;
                //    for (int i = 0; i < sbdd.nCutset; i++) sbdd.pCutset += XCutsetppMCS[i].CutProba;
                //}
                //else
                //{
                //    if (XCutsetppMCS.Count > Constants.maxCutset)
                //    {
                //        sbdd.pCutset = 0.0f;
                //        for (int i = 0; i < Constants.maxCutset; i++)
                //        {
                //            MinimalCutSet.XCutset.XaCutSet.Add(XCutsetppMCSSort[i]);
                //            sbdd.pCutset += XCutsetppMCSSort[i].CutProba;
                //        }

                //        MinimalCutSet.XCutset.NumOfCutSet = (int)Constants.maxCutset;
                //        sbdd.nCutset = (int)Constants.maxCutset;
                //    }
                //}

                #endregion

                #region save raw file

                ClassRawFile.SaveRawFile(MinimalCutSet, RawFileName, TopName);

                #endregion

            }




        }

        public static void ExpandMCS(int ite, int[] EventList, int nEventinCutSet, float prob)
        {

            switch (ite)
            {
                case 0: // FALSE -> Do nothing
                    break;

                case 1: // TRUE -> add cutset to MCS
                    
                    if (prob >= Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR)
                    {
                        
                        XaCutSetType Cutset = new XaCutSetType();
                        Cutset.Elems = new List<int>();
                        int IENum = 0;
                        int SeqNum = 0;
                        bool DoubleNegate = false;

                        for (int i = 0; i < nEventinCutSet + 1; i++)
                        {
                            
                            #region check for non-sense cutset (double initiator)

                            if (ClassFtData.isEventIE(Math.Abs(EventList[i]))) { IENum++; }
                            if (ClassFtData.isEventSeq(Math.Abs(EventList[i]))) { SeqNum++; }
                            
                            #endregion

                            #region check for non-sense cutset (negate gates)

                            if (ClassFtData.NegateBeIndexList.Contains(EventList[i]))
                            {
                                int NegateBeRelationListIndex = ClassFtData.NegateBeRelationList.FindIndex(kk => kk.nIndex == EventList[i]);

                                // if there is negate BE in same MCS -> double negate

                                for (int j = 0; j < nEventinCutSet + 1; j++)
                                {
                                    if (EventList[j] == ClassFtData.NegateBeRelationList[NegateBeRelationListIndex].oIndex)
                                    {
                                        DoubleNegate = true; break;
                                    }
                                }
                                
                                EventList[i] = -1 * ClassFtData.NegateBeRelationList[NegateBeRelationListIndex].oIndex; // change to original index and multiply -1

                            }

                            #endregion

                            #region add to Cutset

                            Cutset.Elems.Add(Math.Sign(EventList[i]) * (Math.Abs(EventList[i]) - 1));

                            #endregion

                        }

                        #region add to cutset (except non-sense cutsets)
                        
                        if (IENum < 2 && SeqNum < 2 && !DoubleNegate)
                        {
                            Cutset.Elems.Remove(0);
                            Cutset.NoElem = Cutset.Elems.Count;
                            Cutset.CutProba = prob;
                            XCutsetppMCS.Add(Cutset);
                            mcs_val += prob;
                        }

                        #endregion
                    }
                    break;

                default:
                    
                    if (prob < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR) break;
                    
                    #region expand for ite
                    
                    int x = ClassIte.IteList[ite].x;
                    int l = ClassIte.IteList[ite].l;
                    int r = ClassIte.IteList[ite].r;
                    float prob_x = ClassFtData.XEvent[x].Prob;

                    nEventinCutSet++;
                    EventList[nEventinCutSet] = x;
                    
                    // left side, expand
                    ExpandMCS(l, EventList, nEventinCutSet, prob * prob_x); 
                    // for right side, don't expand
                    ExpandMCS(r, EventList, nEventinCutSet - 1, prob); 

                    #endregion

                    break;
            }

        }

        public static List<List<int>> ExpandMCSforMod(int ite, int[] EventList, int nEventinCutSet, float prob)
        {
            switch (ite)
            {
                case 0: // FALSE -> Do nothing
                    break;

                case 1: // TRUE -> add cutset to ModularGateCutSet

                    if (prob >= Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR)
                    {
                        List<int> Cutset = new List<int>();
                        int IENum = 0;
                        int SeqNum = 0;
                        bool DoubleNegate = false;

                        for (int i = 0; i < nEventinCutSet + 1; i++)
                        {

                            #region check for non-sense cutset (double initiator)

                            if (ClassFtData.isEventIE(Math.Abs(EventList[i]))) { IENum++; }
                            if (ClassFtData.isEventSeq(Math.Abs(EventList[i]))) { SeqNum++; }

                            #endregion

                            #region check for non-sense cutset (negate gates)

                            if (ClassFtData.NegateBeIndexList.Contains(EventList[i]))
                            {
                                int NegateBeRelationListIndex = ClassFtData.NegateBeRelationList.FindIndex(kk => kk.nIndex == EventList[i]);

                                // if there is negate BE in same MCS -> double negate

                                for (int j = 0; j < nEventinCutSet + 1; j++)
                                {
                                    if (EventList[j] == ClassFtData.NegateBeRelationList[NegateBeRelationListIndex].oIndex)
                                    {
                                        DoubleNegate = true; break;
                                    }
                                }

                                EventList[i] = -1 * ClassFtData.NegateBeRelationList[NegateBeRelationListIndex].oIndex; // change to original index and multiply -1

                            }

                            #endregion

                            #region add to Cutset

                            Cutset.Add(Math.Sign(EventList[i]) * (Math.Abs(EventList[i]) - 1));

                            #endregion

                        }

                        if (IENum < 2 && SeqNum < 2 && !DoubleNegate)
                        {
                            ModularGateCutSet.Add(Cutset);
                        }
                        
                    }
                    break;

                default:

                    if (prob < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR) break;

                    #region expand for ite

                    int x = ClassIte.IteList[ite].x;
                    int l = ClassIte.IteList[ite].l;
                    int r = ClassIte.IteList[ite].r;
                    float prob_x = ClassFtData.XEvent[x].Prob;

                    nEventinCutSet++;
                    EventList[nEventinCutSet] = x;

                    // left side, expand
                    ExpandMCS(l, EventList, nEventinCutSet, prob * prob_x);
                    // for right side, don't expand
                    ExpandMCS(r, EventList, nEventinCutSet - 1, prob);

                    #endregion

                    break;
            }

            return ModularGateCutSet;
        }
        
    }
}
