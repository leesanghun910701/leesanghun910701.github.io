﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Linq;
using System.Collections.Generic;

namespace sbdd
{

    public class MultiKeyDictionary<K1, K2, V> : Dictionary<K1, Dictionary<K2, V>>
    {
        public V this[K1 key1, K2 key2]
        {
            get
            {
                if (!ContainsKey(key1) || !this[key1].ContainsKey(key2))
                    throw new ArgumentOutOfRangeException();
                return base[key1][key2];
            }
            set
            {
                if (!ContainsKey(key1))
                    this[key1] = new Dictionary<K2, V>();
                this[key1][key2] = value;
            }
        }
        public void Add(K1 key1, K2 key2, V value)
        {
            if (!ContainsKey(key1))
                this[key1] = new Dictionary<K2, V>();
            this[key1][key2] = value;
        }
        public bool ContainsKey(K1 key1, K2 key2)
        {
            return base.ContainsKey(key1) && this[key1].ContainsKey(key2);
        }
        public bool TryGetValue(K1 key1, K2 key2, out V value)
        {
            Dictionary<K2, V> dict3 = new Dictionary<K2, V>();
            base.TryGetValue(key1, out dict3);
            if (dict3 == null) { value = default(V); return false; }
            if (dict3.TryGetValue(key2, out V value2)) { value = value2; return true; }
            else { value = default(V); return false; }
        }
        public new IEnumerable<V> Values
        {
            get
            {
                return from baseDict in base.Values
                       from baseKey in baseDict.Keys
                       select baseDict[baseKey];
            }
        }
    }

    public class MultiKeyDictionary<K1, K2, K3, V> : Dictionary<K1, MultiKeyDictionary<K2, K3, V>>
    {
        public V this[K1 key1, K2 key2, K3 key3]
        {
            get
            {
                return ContainsKey(key1) ? this[key1][key2, key3] : default(V);
            }
            set
            {
                if (!ContainsKey(key1))
                    this[key1] = new MultiKeyDictionary<K2, K3, V>();
                this[key1][key2, key3] = value;
            }
        }
        public bool ContainsKey(K1 key1, K2 key2, K3 key3)
        {
            return base.ContainsKey(key1) && this[key1].ContainsKey(key2, key3);
        }
        public bool TryGetValue(K1 key1, K2 key2, K3 key3, out V value)
        {
            MultiKeyDictionary<K2, K3, V> dict2 = new MultiKeyDictionary<K2, K3, V>();
            base.TryGetValue(key1, out dict2);
            if (dict2 == null) { value = default(V); return false; }
            if (dict2.TryGetValue(key2, key3, out V value2)) { value = value2; return true; }
            else { value = default(V); return false; }
        }
        public void Add(K1 key1, K2 key2, K3 key3, V value)
        {
            if (!ContainsKey(key1))
                this[key1] = new MultiKeyDictionary<K2, K3, V>();
            this[key1][key2, key3] = value;
        }
    }

    static class Constants
    {
        public static float oCutoff = 0.0f;
        public static float Cutoff = 0.0f;
        public static char mcs = 'p';
        public static int simplify = 0;
        public static int modular = 0;
        public static int beorder = 0;
        public static bool CutsetSort = false;
        public static uint maxCutset = 100000;
        public static string LogFilePath = String.Empty;
        public static float CUTOFF_ADJUST_FACTOR = 0.99999f;
        public static int waitmode = 0;
    }

    static class Program
    {

        const uint WM_CHAR = 0x0102;
        const int VK_ENTER = 0x0D;

        [DllImport("kernel32.dll")]
        static extern bool AttachConsole(int dwProcessId);
        const int ATTACH_PARENT_PROCESS = -1;

        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        static extern bool FreeConsole();

        [DllImport("kernel32.dll")]
        static extern IntPtr GetConsoleWindow();

        [DllImport("user32.dll")]
        static extern int SendMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

        [STAThread]
        static int Main()
        {
            AttachConsole(ATTACH_PARENT_PROCESS);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new sbdd());

            

            IntPtr cw = GetConsoleWindow();
            SendMessage(cw, WM_CHAR, (IntPtr)VK_ENTER, IntPtr.Zero);

            return sbdd.nCutset;

         }

        

    }
}
