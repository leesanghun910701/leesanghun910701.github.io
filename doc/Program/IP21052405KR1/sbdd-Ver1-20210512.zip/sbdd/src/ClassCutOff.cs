﻿
namespace sbdd
{
    class ClassCutOff
    {

        public static int TdIteCutoffMCS(int p, float pr)
        {
            int x, l, r;

            // if prob < cutoff, save FALSE to ite
            if (pr < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR)
            {
                return 0;
            }

            // if ite is FALSE or TRUE, return as is
            if (p == 0 || p == 1) return p;

            // propagate for ite
            x = ClassIte.IteList[p].x;
            l = ClassIte.IteList[p].l;
            r = ClassIte.IteList[p].r;
            
            // truncation for l, r (MCS)
            l = TdIteCutoffMCS(l, pr * ClassFtData.XEvent[x].Prob);
            r = TdIteCutoffMCS(r, pr);

            // save ite
            p = ClassIte.CreateIte(x, l, r);

            return p;
        }

        public static int TdIteCutoffBDD(int p, float pr)
        {
            int x, l, r;

            // if prob < cutoff, save FALSE to ite
            if (pr < Constants.Cutoff * Constants.CUTOFF_ADJUST_FACTOR)
            {
                return 0;
            }

            // if ite is FALSE or TRUE, return as is
            if (p == 0 || p == 1) return p;

            // propagate for ite
            x = ClassIte.IteList[p].x;
            l = ClassIte.IteList[p].l;
            r = ClassIte.IteList[p].r;

            // truncation for l, r (BDD)            
            if (ClassFtData.isEventSeq(x))
            {
                l = TdIteCutoffBDD(l, pr * ClassFtData.XEvent[x].Prob);
                r = TdIteCutoffBDD(r, pr);
            }
            else
            {
                l = TdIteCutoffBDD(l, pr * ClassFtData.XEvent[x].Prob);
                r = TdIteCutoffBDD(r, pr * (1.0f - ClassFtData.XEvent[x].Prob));
            }

            // save ite
            p = ClassIte.CreateIte(x, l, r);

            return p;
        }

    }


}
