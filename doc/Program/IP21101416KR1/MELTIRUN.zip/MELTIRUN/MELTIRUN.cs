﻿using System;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace MELTIRUN
{
    public partial class MELTIRUN_WINFORM : Form
    {

        public int max_thread;
        
        public MELTIRUN_WINFORM()
        {
            InitializeComponent();

            max_thread = Environment.ProcessorCount;
            Lbl_CoreNum.Text = max_thread.ToString();
            
            tb_PKdir.Enabled = false;
            btn_PKdir.Enabled = false;
            tb_calunlDLL.Enabled = false;
            btn_calunlDLL.Enabled = false;

            tb_MCIFdir.Enabled = false;
            btn_MCIFdir.Enabled = false;
        }

        #region MELCOR File Directory

        private void Btn_MCdir_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    tb_MCdir.Text = ofd.FileName;
                }
            }
        }

        private void Btn_MGdir_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    tb_MGdir.Text = ofd.FileName;
                }
            }
        }

        private void Btn_PKdir_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    tb_PKdir.Text = ofd.FileName;
                }
            }
        }


        private void Btn_calunlDLL_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    tb_calunlDLL.Text = ofd.FileName;
                }
            }
        }

        #endregion

        #region Input File Directory

        private void Btn_IFdir_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog fbd = new FolderBrowserDialog())
            {
                if (fbd.ShowDialog() == DialogResult.OK)
                {
                    tb_MGIFdir.Text = fbd.SelectedPath;
                }
            }
        }

        private void Btn_MCIFdir_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    tb_MCIFdir.Text = ofd.FileName;
                }
            }
        }

        #endregion

        #region MELCOR Version button

        private void Rb_MCVer22_CheckedChanged(object sender, EventArgs e)
        {
            tb_PKdir.Enabled = true;
            btn_PKdir.Enabled = true;
            tb_calunlDLL.Enabled = true;
            btn_calunlDLL.Enabled = true;
        }

        private void Rb_MCVer186_CheckedChanged(object sender, EventArgs e)
        {
            tb_PKdir.Enabled = false;
            btn_PKdir.Enabled = false;
            tb_PKdir.Text = String.Empty;

            tb_calunlDLL.Enabled = false;
            btn_calunlDLL.Enabled = false;
            tb_calunlDLL.Text = String.Empty;
        }

        #endregion

        #region Multi-Input Loading button

        private void Rb_SingleFile_CheckedChanged(object sender, EventArgs e)
        {
            tb_MCIFdir.Enabled = false;
            btn_MCIFdir.Enabled = false;
            tb_MCIFdir.Text = String.Empty;
            
        }
        
        private void Rb_TwoFile_CheckedChanged(object sender, EventArgs e)
        {
            tb_MCIFdir.Enabled = true;
            btn_MCIFdir.Enabled = true;

        }

        #endregion

        #region Generate Files button

        private void Btn_GenFile_Click(object sender, EventArgs e)
        {
            #region validate inputs

            if (!File.Exists(tb_MCdir.Text))
            {
                string msg = "MELCOR file does not exists";
                string cpt = "Fatal Error";
                MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                return;
            }

            if (!File.Exists(tb_MGdir.Text))
            {
                string msg = "MELGEN file does not exists";
                string cpt = "Fatal Error";
                MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                return;
            }

            if (rb_MCVer22.Checked == true)
            {
                if (!File.Exists(tb_PKdir.Text))
                {
                    string msg = "Product key file does not exists";
                    string cpt = "Fatal Error";
                    MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                    MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                    MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                    return;
                }

                if (!File.Exists(tb_calunlDLL.Text))
                {
                    string msg = "calu_nl.dll file does not exists";
                    string cpt = "Fatal Error";
                    MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                    MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                    MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                    return;
                }
            }
            
            if (!Directory.Exists(tb_MGIFdir.Text))
            {
                string msg = "Input file folder does not exists";
                string cpt = "Fatal Error";
                MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                return;
            }
            
            string[] fileEntries = Directory.GetFiles(tb_MGIFdir.Text);
            if (fileEntries.Length == 0)
            {
                string msg = "File does not exist in Input file folder";
                string cpt = "Fatal Error";
                MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                return;
            }
            int FileNum = fileEntries.Length;

            int FolderNum;
            bool FolderNum_isNum = Int32.TryParse(tb_ThreadNum.Text, out FolderNum);

            if (!FolderNum_isNum || FolderNum > max_thread)
            {
                string msg = "Entered thread is not integer or larger than max thread";
                string cpt = "Fatal Error";
                MessageBoxButtons msg_btn = MessageBoxButtons.OKCancel;
                MessageBoxIcon msg_icn = MessageBoxIcon.Warning;
                MessageBox.Show(msg, cpt, msg_btn, msg_icn);
                return;
            }

            #endregion

            #region generate folders

            // delete existing folders / create new folder

            for (int i = 1; i < 400; i++)
            {
                string FolderName = "Run" + i.ToString();
                bool exists = Directory.Exists(FolderName);
                if (exists) { Directory.Delete(FolderName, recursive: true); }
            }
            
            for (int i = 1; i < FolderNum + 1; i++)
            {
                string FolderName = "Run" + i.ToString();
                Directory.CreateDirectory(FolderName);
            }

            #endregion


            #region copy & paste files to each folder
            
            int files_per_folder = FileNum / FolderNum;
            int extra_file = FileNum % FolderNum;
            int fileEntriesID = 0;
            
            for (int FolderID = 1; FolderID < FolderNum + 1; FolderID++)
            {
                int CopyFileNum;

                string srcFileDir;
                string srcFile_IN, dstFile_IN, srcFileName_IN, srcFileFolder_IN;
                string srcFile_IN2, dstFile_IN2, srcFileName_IN2;
                string srcFile_MC, dstFile_MC, srcFileName_MC;
                string srcFile_MG, dstFile_MG, srcFileName_MG;
                string srcFile_PK, dstFile_PK, srcFileName_PK;
                string srcFile_DLL, srcFileName_DLL;

                srcFileName_IN2 = String.Empty;
                string FolderName = "Run" + FolderID.ToString();
                
                if (FolderID <= extra_file) CopyFileNum = files_per_folder + 1; // (files_per_folder + 1)개씩 복붙
                else CopyFileNum = files_per_folder;                            // (files_per_folder)개씩 복붙

                string BatchFileName = "Run" + FolderID.ToString() + ".bat";
                if (File.Exists(BatchFileName)) File.Delete(BatchFileName);
                
                StreamWriter strWriter = new StreamWriter(new FileStream(BatchFileName, FileMode.Append));
                strWriter.WriteLine("cd " + FolderName);

                for (int j = 0; j < CopyFileNum; j++)
                {
                    // copy & paste MELCOR input files

                    srcFile_IN = fileEntries[fileEntriesID];
                    string[] StringSplit = fileEntries[fileEntriesID].Split('\\');
                    srcFileName_IN = StringSplit[StringSplit.Length - 1];
                    srcFileDir = Path.GetFileNameWithoutExtension(srcFile_IN);
                    srcFileFolder_IN = FolderName + "\\" + srcFileDir;
                    Directory.CreateDirectory(srcFileFolder_IN);
                    dstFile_IN = FolderName + "\\" + srcFileDir + "\\" + srcFileName_IN;
                    File.Copy(srcFile_IN, dstFile_IN, true); // overwrite if exist

                    if (rb_TwoFile.Checked)
                    {
                        srcFile_IN2 = tb_MCIFdir.Text;
                        StringSplit = srcFile_IN2.Split('\\');
                        srcFileName_IN2 = StringSplit[StringSplit.Length - 1];                        
                        dstFile_IN2 = FolderName + "\\" + srcFileDir + "\\" + srcFileName_IN2;
                        File.Copy(srcFile_IN2, dstFile_IN2, true); // overwrite if exist
                    }

                    // copy & paste MELCOR exe files 
                    srcFile_MC = tb_MCdir.Text;
                    StringSplit = srcFile_MC.Split('\\');
                    srcFileName_MC = StringSplit[StringSplit.Length - 1];
                    dstFile_MC = FolderName + "\\" + srcFileDir + "\\" + srcFileName_MC;
                    File.Copy(srcFile_MC, dstFile_MC, true); // overwrite if exist

                    // copy & paste MELGEN exe files 
                    srcFile_MG = tb_MGdir.Text;
                    StringSplit = srcFile_MG.Split('\\');
                    srcFileName_MG = StringSplit[StringSplit.Length - 1];
                    dstFile_MG = FolderName + "\\" + srcFileDir + "\\" + srcFileName_MG;
                    File.Copy(srcFile_MG, dstFile_MG, true); // overwrite if exist

                    // copy & paste Product Key and DLL files (in 2.2)
                    if (rb_MCVer22.Checked == true)
                    {
                        srcFile_PK = tb_PKdir.Text;
                        StringSplit = srcFile_PK.Split('\\');
                        srcFileName_PK = StringSplit[StringSplit.Length - 1];
                        dstFile_PK = FolderName + "\\" + srcFileDir + "\\" + srcFileName_PK;
                        File.Copy(srcFile_PK, dstFile_PK, true); // overwrite if exist

                        srcFile_DLL = tb_calunlDLL.Text;
                        StringSplit = srcFile_DLL.Split('\\');
                        srcFileName_DLL = StringSplit[StringSplit.Length - 1];
                        string dstFile_DLL = FolderName + "\\" + srcFileDir + "\\" + srcFileName_DLL;
                        File.Copy(srcFile_DLL, dstFile_DLL, true); // overwrite if exist
                    }

                    // copy MELCOR input

                    // write batch file
                    if (rb_TwoFile.Checked)
                    {
                        strWriter.WriteLine("cd " + srcFileDir);
                        strWriter.WriteLine(srcFileName_MG + " " + srcFileName_IN);
                        strWriter.WriteLine(srcFileName_MC + " " + srcFileName_IN2);
                        strWriter.WriteLine("cd..");
                        strWriter.WriteLine("ren " + srcFileDir + " " + srcFileDir + "_done");
                    }
                    else
                    {
                        strWriter.WriteLine("cd " + srcFileDir);
                        strWriter.WriteLine(srcFileName_MG + " " + srcFileName_IN);
                        strWriter.WriteLine(srcFileName_MC + " " + srcFileName_IN);
                        strWriter.WriteLine("cd..");
                        strWriter.WriteLine("ren " + srcFileDir + " " + srcFileDir + "_done");
                    }

                    fileEntriesID++;
                }
                
                strWriter.Close();
                
            }

            #endregion

            #region generate master batch file

            string MasterBatchFileName = "Run.Bat";            
            if (File.Exists(MasterBatchFileName)) File.Delete(MasterBatchFileName);
            StreamWriter strWriter2 = new StreamWriter(new FileStream(MasterBatchFileName, FileMode.Append));

            for (int FolderID = 1; FolderID < FolderNum + 1; FolderID++)
            {
                string BatchFileName = "Run" + FolderID.ToString() + ".bat";
                int core_num = (int)Math.Pow(2, FolderID - 1);

                strWriter2.WriteLine("start /affinity " + core_num.ToString("X") + " " + BatchFileName);                
            }

            strWriter2.Close();

            #endregion
            
            string msg2 = "Files Created";
            string cpt2 = "Success";
            MessageBoxButtons msg_btn2 = MessageBoxButtons.OKCancel;
            MessageBoxIcon msg_icn2 = MessageBoxIcon.Information;
            MessageBox.Show(msg2, cpt2, msg_btn2, msg_icn2);
            return;
        }

        #endregion

        #region execute button

        private void Btn_Execute_Click(object sender, EventArgs e)
        {
            Process.Start("cmd.exe", "/c Run.bat");
        }

        #endregion

    }
}
