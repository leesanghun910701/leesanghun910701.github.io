// GeoTrans.cpp: implementation of the GeoTrans class.
//
//////////////////////////////////////////////////////////////////////

#include "pch.h"
#include "GeoTrans.h"



#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

GeoTrans::GeoTrans()
{
	//M_PI=3.141592920;
	M_PI = 3.14159265358979L;
	GEO = 0;
	KATEC = 1;
	TM = 2;
	GRS80 = 3;
	UTMK = 4;

	HALF_PI = 0.5L * M_PI;
	COS_67P5 = 0.38268343236508977L;
	AD_C = 1.0026000L;

	EPSLN = 0.0000000001L;

	m_arScaleFactor[GEO] = 1;
	m_arLonCenter[GEO] = 0.0L;
	m_arLatCenter[GEO] = 0.0L;
	m_arFalseNorthing[GEO] = 0.0;
	m_arFalseEasting[GEO] = 0.0;
	m_arMajor[GEO] = 6378137.0L;
	m_arMinor[GEO] = 6356752.3142L;

	m_arScaleFactor[KATEC] = 0.9999;
	m_arLonCenter[KATEC] = 2.23402144255274L; // (PI / 180) * 128
	m_arLatCenter[KATEC] = 0.663225115757845L; // (PI / 180) * 38
	m_arFalseNorthing[KATEC] = 600000.0;
	m_arFalseEasting[KATEC] = 400000.0;
	m_arMajor[KATEC] = 6377397.155L;
	m_arMinor[KATEC] = 6356078.9633422494L;

	/* 20200715 ����
	m_arScaleFactor[TM] = 1.0;
	//this.m_arLonCenter[TM] = 2.21656815003280; // 127
	m_arLonCenter[TM] = 2.21661859489671L; // 127.+10.485 minute
	m_arLatCenter[TM] = 0.663225115757845L;
	m_arFalseNorthing[TM] = 500000.0;
	m_arFalseEasting[TM] = 200000.0;
	m_arMajor[TM] = 6377397.155L;
	m_arMinor[TM] = 6356078.9633422494L;
	*/
	///*20200720
	m_arScaleFactor[TM] = 1.0;
	//this.m_arLonCenter[TM] = 2.21656815003280; // 127
	m_arLonCenter[TM] = 2.21661859489630L; // 127.0028902777778 2.216618594896300 
	m_arLatCenter[TM] = 0.663225115757845L;
	m_arFalseNorthing[TM] = 500000.0;
	m_arFalseEasting[TM] = 200000.0;
	m_arMajor[TM] = 6377397.155L;
	m_arMinor[TM] = 6356078.9633422494L;
	//*/

	/* 20200715 ����
	m_arScaleFactor[GRS80] = 1.0; //0.9999;
	m_arLonCenter[GRS80] = 2.21656815003280L; // 127
	//m_arLonCenter[GRS80] = 2.21661859489671; // 127.+10.485 minute
	m_arLatCenter[GRS80] = 0.663225115757845L;
	m_arFalseNorthing[GRS80] = 500000.0;
	m_arFalseEasting[GRS80] = 200000.0;
	m_arMajor[GRS80] = 6378137.0L;
	m_arMinor[GRS80] = 6356752.3142L;
	*/
	m_arScaleFactor[GRS80] = 1.0; //0.9999;
	m_arLonCenter[GRS80] = 2.21656815003280L; // 127
	//m_arLonCenter[GRS80] = 2.21661859489671; // 127.+10.485 minute
	m_arLatCenter[GRS80] = 0.663225115757845L;
	m_arFalseNorthing[GRS80] = 600000.0;
	m_arFalseEasting[GRS80] = 200000.0;
	m_arMajor[GRS80] = 6378137.0L;
	m_arMinor[GRS80] = 6356752.3141L;





	m_arScaleFactor[UTMK] = 0.9996; //0.9999;
	m_arLonCenter[UTMK] = 2.22529479629277L; // 127.5
	//m_arLonCenter[UTMK]   = 2.22529470629277; // ���Ǻ��� ��������  ��¦ �̵�
	m_arLatCenter[UTMK] = 0.663225115757845L;
	//m_arLatCenter[UTMK]   = 0.663225105757845; // ���Ǻ��� ������� ��¦ �̵�
	m_arFalseNorthing[UTMK] = 2000000.0;
	m_arFalseEasting[UTMK] = 1000000.0;
	m_arMajor[UTMK] = 6378137.0L;
	m_arMinor[UTMK] = 6356752.3141403558L;



	///*
	datum_params[0] = -146.43;
	datum_params[1] = 507.89;
	datum_params[2] = 681.46;
	//*/
	/*
	datum_params[0] = -145.907;
	datum_params[1] = 505.034;
	datum_params[2] = 685.756;
	*/


	//datum_params_ForGRS[0] = -115.80;
	//datum_params_ForGRS[1] = 474.99;
	//datum_params_ForGRS[2] = 674.11;




	long double tmp = m_arMinor[GEO] / m_arMajor[GEO];
	m_Es[GEO] = 1.0L - tmp * tmp;
	m_Esp[GEO] = m_Es[GEO] / (1.0L - m_Es[GEO]);

	if (m_Es[GEO] < 0.00001)
	{
		m_Ind[GEO] = 1.0L;
	}
	else
	{
		m_Ind[GEO] = 0.0L;
	}

	tmp = m_arMinor[KATEC] / m_arMajor[KATEC];
	m_Es[KATEC] = 1.0L - tmp * tmp;
	m_Esp[KATEC] = m_Es[KATEC] / (1.0L - m_Es[KATEC]);

	if (m_Es[KATEC] < 0.00001)
	{
		m_Ind[KATEC] = 1.0L;
	}
	else
	{
		m_Ind[KATEC] = 0.0L;
	}

	tmp = m_arMinor[TM] / m_arMajor[TM];
	m_Es[TM] = 1.0L - tmp * tmp;
	m_Esp[TM] = m_Es[TM] / (1.0L - m_Es[TM]);

	if (m_Es[TM] < 0.00001)
	{
		m_Ind[TM] = 1.0L;
	}
	else
	{
		m_Ind[TM] = 0.0L;
	}

	tmp = m_arMinor[UTMK] / m_arMajor[UTMK];
	m_Es[UTMK] = 1.0L - tmp * tmp;
	m_Esp[UTMK] = m_Es[UTMK] / (1.0 - m_Es[UTMK]);

	if (m_Es[UTMK] < 0.00001)
	{
		m_Ind[UTMK] = 1.0L;
	}
	else
	{
		m_Ind[UTMK] = 0.0L;
	}

	tmp = m_arMinor[GRS80] / m_arMajor[GRS80];
	m_Es[GRS80] = 1.0L - tmp * tmp;
	m_Esp[GRS80] = m_Es[GRS80] / (1.0L - m_Es[GRS80]);

	if (m_Es[GRS80] < 0.00001)
	{
		m_Ind[GRS80] = 1.0L;
	}
	else
	{
		m_Ind[GRS80] = 0.0;
	}

	src_m[GEO] = m_arMajor[GEO] * mlfn(e0fn(m_Es[GEO]), e1fn(m_Es[GEO]), e2fn(m_Es[GEO]), e3fn(m_Es[GEO]), m_arLatCenter[GEO]);
	dst_m[GEO] = m_arMajor[GEO] * mlfn(e0fn(m_Es[GEO]), e1fn(m_Es[GEO]), e2fn(m_Es[GEO]), e3fn(m_Es[GEO]), m_arLatCenter[GEO]);
	src_m[KATEC] = m_arMajor[KATEC] * mlfn(e0fn(m_Es[KATEC]), e1fn(m_Es[KATEC]), e2fn(m_Es[KATEC]), e3fn(m_Es[KATEC]), m_arLatCenter[KATEC]);
	dst_m[KATEC] = m_arMajor[KATEC] * mlfn(e0fn(m_Es[KATEC]), e1fn(m_Es[KATEC]), e2fn(m_Es[KATEC]), e3fn(m_Es[KATEC]), m_arLatCenter[KATEC]);
	src_m[TM] = m_arMajor[TM] * mlfn(e0fn(m_Es[TM]), e1fn(m_Es[TM]), e2fn(m_Es[TM]), e3fn(m_Es[TM]), m_arLatCenter[TM]);
	dst_m[TM] = m_arMajor[TM] * mlfn(e0fn(m_Es[TM]), e1fn(m_Es[TM]), e2fn(m_Es[TM]), e3fn(m_Es[TM]), m_arLatCenter[TM]);
	src_m[GRS80] = m_arMajor[GRS80] * mlfn(e0fn(m_Es[GRS80]), e1fn(m_Es[GRS80]), e2fn(m_Es[GRS80]), e3fn(m_Es[GRS80]), m_arLatCenter[GRS80]);
	dst_m[GRS80] = m_arMajor[GRS80] * mlfn(e0fn(m_Es[GRS80]), e1fn(m_Es[GRS80]), e2fn(m_Es[GRS80]), e3fn(m_Es[GRS80]), m_arLatCenter[GRS80]);
	src_m[UTMK] = m_arMajor[UTMK] * mlfn(e0fn(m_Es[UTMK]), e1fn(m_Es[UTMK]), e2fn(m_Es[UTMK]), e3fn(m_Es[UTMK]), m_arLatCenter[UTMK]);
	dst_m[UTMK] = m_arMajor[UTMK] * mlfn(e0fn(m_Es[UTMK]), e1fn(m_Es[UTMK]), e2fn(m_Es[UTMK]), e3fn(m_Es[UTMK]), m_arLatCenter[UTMK]);
}

GeoTrans::~GeoTrans()
{

}


double GeoTrans::D2R(double degree)
{
	return degree * M_PI / 180.0;
}

double GeoTrans::R2D(double radian)
{
	return radian * 180.0 / M_PI;
}

double GeoTrans::e0fn(double x)
{
	return 1.0 - 0.25 * x * (1.0 + x / 16.0 * (3.0 + 1.25 * x));
}

double GeoTrans::e1fn(double x)
{
	return 0.375 * x * (1.0 + 0.25 * x * (1.0 + 0.46875 * x));
}

double GeoTrans::e2fn(double x)
{
	return 0.05859375 * x * x * (1.0 + 0.75 * x);
}

double GeoTrans::e3fn(double x)
{
	return x * x * x * (35.0 / 3072.0);
}

double GeoTrans::mlfn(double e0, double e1, double e2, double e3, double phi)
{
	return e0 * phi - e1 * sin(2.0 * phi) + e2 * sin(4.0 * phi) - e3 * sin(6.0 * phi);
}

double GeoTrans::asinz(double value)
{
	if (fabs(value) > 1.0)
	{
		value = (value > 0 ? 1 : -1);
	}
	return asin(value);
}

GeoPoint* GeoTrans::convert(int srctype, int dsttype, GeoPoint* in_pt)
{
	GeoPoint* tmpPt = new GeoPoint();
	GeoPoint* out_pt = new GeoPoint();

	if (srctype == GEO)
	{
		tmpPt->x = D2R(in_pt->x);
		tmpPt->y = D2R(in_pt->y);
	}
	else
	{
		tm2geo(srctype, in_pt, tmpPt);
	}

	if (dsttype == GEO)
	{
		out_pt->x = R2D(tmpPt->x);
		out_pt->y = R2D(tmpPt->y);
	}
	else
	{
		geo2tm(dsttype, tmpPt, out_pt);
		//out_pt.x = Math.round(out_pt.x);
		//out_pt.y = Math.round(out_pt.y);
	}

	delete tmpPt;

	return out_pt;
}

void GeoTrans::geo2tm(int dsttype, GeoPoint* in_pt, GeoPoint* out_pt)
{
	double x, y;

	transform(GEO, dsttype, in_pt);
	double delta_lon = in_pt->x - m_arLonCenter[dsttype];
	double sin_phi = sin(in_pt->y);
	double cos_phi = cos(in_pt->y);

	if (m_Ind[dsttype] != 0)
	{
		double b = cos_phi * sin(delta_lon);

		if ((fabs(fabs(b) - 1.0)) < EPSLN)
		{
			//Log.d("���Ѵ� ����");
			//System.out.println("���Ѵ� ����");
		}
	}
	else
	{
		double b = 0;
		x = 0.5 * m_arMajor[dsttype] * m_arScaleFactor[dsttype] * log((1.0 + b) / (1.0 - b));
		double con = acos(cos_phi * cos(delta_lon) / sqrt(1.0 - b * b));

		if (in_pt->y < 0)
		{
			con = con * -1;
			y = m_arMajor[dsttype] * m_arScaleFactor[dsttype] * (con - m_arLatCenter[dsttype]);
		}
	}

	double al = cos_phi * delta_lon;
	double als = al * al;
	double c = m_Esp[dsttype] * cos_phi * cos_phi;
	double tq = tan(in_pt->y);
	double t = tq * tq;
	double con = 1.0 - m_Es[dsttype] * sin_phi * sin_phi;
	double n = m_arMajor[dsttype] / sqrt(con);
	double ml = m_arMajor[dsttype] * mlfn(e0fn(m_Es[dsttype]), e1fn(m_Es[dsttype]), e2fn(m_Es[dsttype]), e3fn(m_Es[dsttype]), in_pt->y);

	out_pt->x = m_arScaleFactor[dsttype] * n * al * (1.0L + als / 6.0L * (1.0L - t + c + als / 20.0L * (5.0L - 18.0L * t + t * t + 72.0L * c - 58.0L * m_Esp[dsttype]))) + m_arFalseEasting[dsttype];
	out_pt->y = m_arScaleFactor[dsttype] * (ml - dst_m[dsttype] + n * tq * (als * (0.5L + als / 24.0L * (5.0L - t + 9.0L * c + 4.0L * c * c + als / 30.0L * (61.0L - 58.0L * t + t * t + 600.0L * c - 330.0L * m_Esp[dsttype]))))) + m_arFalseNorthing[dsttype];
}

void GeoTrans::tm2geo(int srctype, GeoPoint* in_pt, GeoPoint* out_pt)
{
	GeoPoint* tmpPt = new GeoPoint(in_pt->getX(), in_pt->getY());
	int max_iter = 6;

	if (m_Ind[srctype] != 0)
	{
		long double f = exp(in_pt->x / (m_arMajor[srctype] * m_arScaleFactor[srctype]));
		long double g = 0.5L * (f - 1.0L / f);
		long double temp = m_arLatCenter[srctype] + tmpPt->y / (m_arMajor[srctype] * m_arScaleFactor[srctype]);
		long double h = cos(temp);
		long double con = sqrt((1.0L - h * h) / (1.0L + g * g));
		out_pt->y = asinz(con);

		if (temp < 0)
		{
			out_pt->y *= -1;
		}

		if ((g == 0) && (h == 0))
		{
			out_pt->x = m_arLonCenter[srctype];
		}
		else
		{
			out_pt->x = atan(g / h) + m_arLonCenter[srctype];
		}
	}

	tmpPt->x -= m_arFalseEasting[srctype];
	tmpPt->y -= m_arFalseNorthing[srctype];

	long double con = (src_m[srctype] + tmpPt->y / m_arScaleFactor[srctype]) / m_arMajor[srctype];
	long double phi = con;

	int i = 0;

	while (true)
	{
		long double delta_Phi = ((con + e1fn(m_Es[srctype]) * sin(2.0L * phi) - e2fn(m_Es[srctype]) * sin(4.0L * phi) + e3fn(m_Es[srctype]) * sin(6.0L * phi)) / e0fn(m_Es[srctype])) - phi;
		phi = phi + delta_Phi;

		if (fabs(delta_Phi) <= EPSLN)
		{
			break;
		}

		if (i >= max_iter)
		{
			//Log.d("���Ѵ� ����");
			//System.out.println("���Ѵ� ����");
			break;
		}

		i++;
	}

	if (fabs(phi) < (M_PI / 2))
	{
		long double sin_phi = sin(phi);
		long double cos_phi = cos(phi);
		long double tan_phi = tan(phi);
		long double c = m_Esp[srctype] * cos_phi * cos_phi;
		long double cs = c * c;
		long double t = tan_phi * tan_phi;
		long double ts = t * t;
		long double cont = 1.0L - m_Es[srctype] * sin_phi * sin_phi;
		long double n = m_arMajor[srctype] / sqrt(cont);
		long double r = n * (1.0L - m_Es[srctype]) / cont;
		long double d = tmpPt->x / (n * m_arScaleFactor[srctype]);
		long double ds = d * d;
		out_pt->y = phi - (n * tan_phi * ds / r) * (0.5L - ds / 24.0L * (5.0L + 3.0L * t + 10.0L * c - 4.0L * cs - 9.0L * m_Esp[srctype] - ds / 30.0L * (61.0L + 90.0L * t + 298.0L * c + 45.0L * ts - 252.0L * m_Esp[srctype] - 3.0L * cs)));
		out_pt->x = m_arLonCenter[srctype] + (d * (1.0L - ds / 6.0L * (1.0L + 2.0L * t + c - ds / 20.0L * (5.0L - 2.0L * c + 28.0L * t - 3.0L * cs + 8.0L * m_Esp[srctype] + 24.0L * ts))) / cos_phi);
	}
	else
	{
		out_pt->y = M_PI * 0.5L * sin(tmpPt->y);
		out_pt->x = m_arLonCenter[srctype];
	}

	delete tmpPt;
	transform(srctype, GEO, out_pt);
}

double GeoTrans::getDistancebyGeo(GeoPoint* pt1, GeoPoint* pt2)
{
	double lat1 = D2R(pt1->y);
	double lon1 = D2R(pt1->x);
	double lat2 = D2R(pt2->y);
	double lon2 = D2R(pt2->x);

	double longitude = lon2 - lon1;
	double latitude = lat2 - lat1;

	double a = pow(sin(latitude / 2.0), 2) + cos(lat1) * cos(lat2) * pow(sin(longitude / 2.0), 2);
	return 6376.5 * 2.0 * atan2(sqrt(a), sqrt(1.0 - a));
}

double GeoTrans::getDistancebyKatec(GeoPoint* pt1, GeoPoint* pt2)
{
	pt1 = convert(KATEC, GEO, pt1);
	pt2 = convert(KATEC, GEO, pt2);

	return getDistancebyGeo(pt1, pt2);
}

double GeoTrans::getDistancebyTm(GeoPoint* pt1, GeoPoint* pt2)
{
	pt1 = convert(TM, GEO, pt1);
	pt2 = convert(TM, GEO, pt2);

	return getDistancebyGeo(pt1, pt2);
}

double GeoTrans::getDistancebyUTMK(GeoPoint* pt1, GeoPoint* pt2)
{
	pt1 = convert(UTMK, GEO, pt1);
	pt2 = convert(UTMK, GEO, pt2);

	return getDistancebyGeo(pt1, pt2);
}

double GeoTrans::getDistancebyGrs80(GeoPoint* pt1, GeoPoint* pt2)
{
	pt1 = convert(GRS80, GEO, pt1);
	pt2 = convert(GRS80, GEO, pt2);

	return getDistancebyGeo(pt1, pt2);
}

long _round(double x)
{
	return (long(x + 0.5));
}

long GeoTrans::getTimebySec(double distance)
{
	return _round(3600 * distance / 4);
}

long GeoTrans::getTimebyMin(double distance)
{
	return (long)(ceil((double)getTimebySec(distance) / 60));
}



void GeoTrans::transform(int srctype, int dsttype, GeoPoint* point)
{
	if (srctype == dsttype)
	{
		return;
	}
	/*
	int GEO;// = 0;
	int KATEC;// = 1;
	int TM;// = 2;
	int GRS80;// = 3;
	int UTMK;// = 4;
	*/
	///*
	//20200715
	if ((srctype != 0 && srctype != GRS80 && srctype != UTMK) || (dsttype != 0 && dsttype != GRS80 && dsttype != UTMK))
	{
		// Convert to geocentric coordinates.
		geodetic_to_geocentric(srctype, point);

		// Convert between datums
		if (srctype != 0 && srctype != GRS80 && srctype != UTMK)
		{
			geocentric_to_wgs84(point);
		}

		if (dsttype != 0 && dsttype != GRS80 && dsttype != UTMK)
		{
			geocentric_from_wgs84(point);
		}

		// Convert back to geodetic coordinates
		geocentric_to_geodetic(dsttype, point);
	}
	//*/
	/*20200720
	if (srctype != 0 || dsttype != 0)
	{
		// Convert to geocentric coordinates.
		geodetic_to_geocentric(srctype, point);

		// Convert between datums
		if (srctype != 0 && srctype != GRS80 && srctype != UTMK)
		{
			geocentric_to_wgs84(point);
		}
		//else if (srctype == GRS80 || srctype == UTMK)
		else if (srctype == GRS80)
		{
			geocentric_to_wgs84_ForGRS(point);
		}


		if (dsttype != 0 && dsttype != GRS80 && dsttype != UTMK)
		{
			geocentric_from_wgs84(point);
		}
		//else if (dsttype == GRS80 || dsttype == UTMK)
		else if (dsttype == GRS80)
		{
			geocentric_from_wgs84_ForGRS(point);
		}

		// Convert back to geodetic coordinates
		geocentric_to_geodetic(dsttype, point);
	}
	*/
}

bool GeoTrans::geodetic_to_geocentric(int type, GeoPoint* p)
{

	/*
	 * The function Convert_Geodetic_To_Geocentric converts geodetic coordinates
	 * (latitude, longitude, and height) to geocentric coordinates (X, Y, Z),
	 * according to the current ellipsoid parameters.
	 *
	 *		Latitude	: Geodetic latitude in radians										 (input)
	 *		Longitude : Geodetic longitude in radians										(input)
	 *		Height		: Geodetic height, in meters											 (input)
	 *		X				 : Calculated Geocentric X coordinate, in meters		(output)
	 *		Y				 : Calculated Geocentric Y coordinate, in meters		(output)
	 *		Z				 : Calculated Geocentric Z coordinate, in meters		(output)
	 *
	 */

	long double Longitude = p->x;
	long double Latitude = p->y;
	long double Height = p->z;
	long double X; // output
	long double Y;
	long double Z;

	long double Rn; //	Earth radius at location
	long double Sin_Lat; //	Math.sin(Latitude)
	long double Sin2_Lat; //	Square of Math.sin(Latitude)
	long double Cos_Lat; //	Math.cos(Latitude)

	/*
	** Don't blow up if Latitude is just a little out of the value
	** range as it may just be a rounding issue.	Also removed longitude
	** test, it should be wrapped by Math.cos() and Math.sin().	NFW for PROJ.4, Sep/2001.
	*/
	if (Latitude < -HALF_PI && Latitude > -1.001L * HALF_PI)
	{
		Latitude = -HALF_PI;
	}
	else if (Latitude > HALF_PI && Latitude < 1.001L * HALF_PI)
	{
		Latitude = HALF_PI;
	}
	else if ((Latitude < -HALF_PI) || (Latitude > HALF_PI)) // Latitude out of range
	{
		return true;
	}

	/* no errors */
	if (Longitude > M_PI)
	{
		Longitude -= (2.0L * M_PI);
	}
	Sin_Lat = sin(Latitude);
	Cos_Lat = cos(Latitude);
	Sin2_Lat = Sin_Lat * Sin_Lat;
	Rn = m_arMajor[type] / (sqrt(1.0e0 - m_Es[type] * Sin2_Lat));
	X = (Rn + Height) * Cos_Lat * cos(Longitude);
	Y = (Rn + Height) * Cos_Lat * sin(Longitude);
	Z = ((Rn * (1.0L - m_Es[type])) + Height) * Sin_Lat;

	p->x = X;
	p->y = Y;
	p->z = Z;
	return false;
} // cs_geodetic_to_geocentric()

void GeoTrans::geocentric_to_geodetic(int type, GeoPoint* p)
{

	long double X = p->x;
	long double Y = p->y;
	long double Z = p->z;
	long double Longitude;
	long double Latitude = 0.0L;
	long double Height;

	long double W; // distance from Z axis
	long double W2; // square of distance from Z axis
	long double T0; // initial estimate of vertical component
	long double T1; // corrected estimate of vertical component
	long double S0; // initial estimate of horizontal component
	long double S1; // corrected estimate of horizontal component
	long double Sin_B0; // Math.sin(B0), B0 is estimate of Bowring aux doubleiable
	long double Sin3_B0; // cube of Math.sin(B0)
	long double Cos_B0; // Math.cos(B0)
	long double Sin_p1; // Math.sin(phi1), phi1 is estimated latitude
	long double Cos_p1; // Math.cos(phi1)
	long double Rn; // Earth radius at location
	long double Sum; // numerator of Math.cos(phi1)
	bool At_Pole; // indicates location is in polar region

	At_Pole = false;
	if (X != 0.0)
	{
		Longitude = atan2(Y, X);
	}
	else
	{
		if (Y > 0)
		{
			Longitude = HALF_PI;
		}
		else if (Y < 0)
		{
			Longitude = -HALF_PI;
		}
		else
		{
			At_Pole = true;
			Longitude = 0.0;
			if (Z > 0.0) // north pole
			{
				Latitude = HALF_PI;
			}
			else if (Z < 0.0) // south pole
			{
				Latitude = -HALF_PI;
			}
			else // center of earth
			{
				Latitude = HALF_PI;
				Height = -m_arMinor[type];
				return;
			}
		}
	}
	W2 = X * X + Y * Y;
	W = sqrt(W2);
	T0 = Z * AD_C;
	S0 = sqrt(T0 * T0 + W2);
	Sin_B0 = T0 / S0;
	Cos_B0 = W / S0;
	Sin3_B0 = Sin_B0 * Sin_B0 * Sin_B0;
	T1 = Z + m_arMinor[type] * m_Esp[type] * Sin3_B0;
	Sum = W - m_arMajor[type] * m_Es[type] * Cos_B0 * Cos_B0 * Cos_B0;
	S1 = sqrt(T1 * T1 + Sum * Sum);
	Sin_p1 = T1 / S1;
	Cos_p1 = Sum / S1;
	Rn = m_arMajor[type] / sqrt(1.0 - m_Es[type] * Sin_p1 * Sin_p1);
	if (Cos_p1 >= COS_67P5)
	{
		Height = W / Cos_p1 - Rn;
	}
	else if (Cos_p1 <= -COS_67P5)
	{
		Height = W / -Cos_p1 - Rn;
	}
	else
	{
		Height = Z / Sin_p1 + Rn * (m_Es[type] - 1.0);
	}
	if (At_Pole == false)
	{
		Latitude = atan(Sin_p1 / Cos_p1);
	}

	p->x = Longitude;
	p->y = Latitude;
	p->z = Height;
	return;
} // geocentric_to_geodetic()




/*
void GeoTrans::geocentric_to_wgs84_ForGRS(GeoPoint* p)
{

	{
		//if( defn.datum_type == PJD_3PARAM )
		// if( x[io] == HUGE_VAL )
		//		continue;
		p->x += datum_params_ForGRS[0];
		p->y += datum_params_ForGRS[1];
		p->z += datum_params_ForGRS[2];
	}
} // geocentric_to_wgs84

void GeoTrans::geocentric_from_wgs84_ForGRS(GeoPoint* p)
{

	{
		//if( defn.datum_type == PJD_3PARAM )
		//if( x[io] == HUGE_VAL )
		//		continue;
		p->x -= datum_params_ForGRS[0];
		p->y -= datum_params_ForGRS[1];
		p->z -= datum_params_ForGRS[2];

	}
} //geocentric_from_wgs84()
*/


void GeoTrans::geocentric_to_wgs84(GeoPoint* p)
{

	{
		//if( defn.datum_type == PJD_3PARAM )
		// if( x[io] == HUGE_VAL )
		//		continue;
		p->x += datum_params[0];
		p->y += datum_params[1];
		p->z += datum_params[2];
	}
} // geocentric_to_wgs84

void GeoTrans::geocentric_from_wgs84(GeoPoint* p)
{

	{
		//if( defn.datum_type == PJD_3PARAM ) 
		//if( x[io] == HUGE_VAL )
		//		continue;
		p->x -= datum_params[0];
		p->y -= datum_params[1];
		p->z -= datum_params[2];

	}
} //geocentric_from_wgs84()
