﻿
// ShapeFiles2TxtDlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "ShapeFiles2Txt.h"
#include "ShapeFiles2TxtDlg.h"
#include "afxdialogex.h"

#include "shapefile.h"

#include "GeoTrans.h"
#include "GeoPoint.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif




// CShapeFiles2TxtDlg 대화 상자


void DoEvents()
{
	MSG nMsg;

	while (PeekMessage(&nMsg, NULL, 0, 0, PM_REMOVE))
	{
		TranslateMessage(&nMsg);
		DispatchMessage(&nMsg);
	}
}



CShapeFiles2TxtDlg::CShapeFiles2TxtDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SHAPEFILES2TXT_DIALOG, pParent)
	, m_nRadioGubun(1)
	, m_sEditFileList(_T(""))
	, m_sEditComma(_T(""))
	, m_sEditFieldList(_T(""))
	, m_nRadioPrj(2)
	, m_nCheckTmpFolderNoDelete(FALSE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_nRadioGubun = 1;
	m_nRadioPrj = 2;
	m_sEditFileList = "";
}

void CShapeFiles2TxtDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO_GUBUN1, m_nRadioGubun);
	DDX_Text(pDX, IDC_EDIT_FILE_LIST, m_sEditFileList);
	DDX_Text(pDX, IDC_EDIT_COMMA, m_sEditComma);
	DDV_MaxChars(pDX, m_sEditComma, 1);
	DDX_Text(pDX, IDC_EDIT_FILEDS, m_sEditFieldList);
	DDX_Radio(pDX, IDC_RADIO_PRJ1, m_nRadioPrj);
	DDX_Control(pDX, IDC_PROGRESS1, m_ctrlProgress);
	DDX_Check(pDX, IDC_CHECK1, m_nCheckTmpFolderNoDelete);
}

BEGIN_MESSAGE_MAP(CShapeFiles2TxtDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_FOLDER_OPEN, &CShapeFiles2TxtDlg::OnBnClickedButtonFolderOpen)
	ON_EN_CHANGE(IDC_EDIT_COMMA, &CShapeFiles2TxtDlg::OnEnChangeEditComma)
	ON_BN_CLICKED(IDOK, &CShapeFiles2TxtDlg::OnBnClickedOk)
	ON_WM_SYSCOMMAND()
	ON_WM_DROPFILES()
	ON_BN_CLICKED(IDC_BUTTON1, &CShapeFiles2TxtDlg::OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, &CShapeFiles2TxtDlg::OnBnClickedButton3)
END_MESSAGE_MAP()







BOOL CShapeFiles2TxtDlg::readRule()
{
	CString csFolder;
	CString sLicPath;

	GetModuleFileName(NULL, csFolder.GetBuffer(_MAX_PATH), _MAX_PATH);
	csFolder.ReleaseBuffer();
	csFolder = csFolder.Left(csFolder.ReverseFind(_TCHAR('\\')));
	csFolder.Replace("\\.\\", "\\");
	sLicPath.Format(_T("%s%s"), csFolder, "\\_sys\\rule.ini");

	//전체 길이 파악
	FILE* p_file = NULL;
	fopen_s(&p_file, LPSTR(LPCTSTR(sLicPath)), "r");

	int nLen = 0;

	if (p_file != NULL)
	{
		char buffer[100];
		char* pStr;

		while (!feof(p_file))
		{
			pStr = fgets(buffer, sizeof(buffer), p_file);
			CString sStr = pStr;
			sStr.Trim();

			if (sStr.GetLength() > 2)
				if (sStr.Left(2) != "//")
					m_nRuleCnt++;
		}
		fclose(p_file);
	}
	else
		return FALSE;


	if (m_nRuleCnt > 0)
	{
		m_saRuleList1 = new CString[m_nRuleCnt];
		m_saRuleList2 = new CString[m_nRuleCnt];

		int i = 0;

		fopen_s(&p_file, LPSTR(LPCTSTR(sLicPath)), "r");
		if (p_file != NULL)
		{
			char buffer[100];
			char* pStr;

			while (!feof(p_file))
			{
				pStr = fgets(buffer, sizeof(buffer), p_file);
				CString sStr = pStr;
				sStr.Trim();

				if (sStr.GetLength() > 2)
					if (sStr.Left(2) != "//")
					{
						CStringArray saTemp;

						int count = splitString(sStr, "\t", saTemp);
						
						if (count == 2)
						{
							m_saRuleList1[i] = saTemp.GetAt(0);
							m_saRuleList2[i] = saTemp.GetAt(1);
							i++;
						}
						saTemp.RemoveAll();						
					}
			}
			fclose(p_file);
		}
	}
	else
		return FALSE;

	return TRUE;
}

// CShapeFiles2TxtDlg 메시지 처리기
BOOL CShapeFiles2TxtDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.

	DragAcceptFiles(TRUE);

	m_bSubFolder = FALSE;
	m_sFolderPath = "";
	m_saFileList = NULL;
	m_nCntFileList = 0;
	m_nCntFieldList = 0;
	m_nError = 0;

	m_nRuleCnt = 0;
	m_saRuleList1 = NULL;
	m_saRuleList2 = NULL;

	readRule();

	m_sLastSelectedFolder = "";

	//구분자 초기화
	m_sEditComma = ",";

	//좌표변환 변수 초기화
	pt1 = NULL;
	pt2 = NULL;
	m_oTrans = NULL;


	init();

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CShapeFiles2TxtDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CShapeFiles2TxtDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CShapeFiles2TxtDlg::init()
{
	for (int i = 0; i < 100; i++)
		m_saFieldList[i] = "";


	//파일 리스트 상단 라벨 변경 
	CWnd* label = GetDlgItem(IDC_STATIC_FILE_LIST);
	label->SetWindowText("선택 폴더 내 파일 리스트");
	label = NULL;

	m_sEditFileList = "";

	

	//필드 리스트 초기화
	m_sEditFieldList = "";

	UpdateData(FALSE); //컨트롤 <- 변수
	//UpdateData(TRUE); //컨트롤 -> 변수


	m_sFolderPath = "";
	if (m_saFileList != NULL)	delete[] m_saFileList;
	m_saFileList = NULL;

	if (m_saFileList_Province != NULL)	delete[] m_saFileList_Province;
	m_saFileList_Province = NULL;

	

	m_nCntFileList = 0;
	m_nCntFieldList = 0;


}



void CShapeFiles2TxtDlg::OnBnClickedButtonFolderOpen()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	init();

	if (openFolder("") == TRUE)
	{
		createFieldList();
	}
}



int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
	switch (uMsg) {
		// 폴더선택 다이얼로그의 초기화가 끝난 경우
	case BFFM_INITIALIZED:
		SendMessage(hwnd, BFFM_SETSELECTION, TRUE, lpData);
		break;
	}
	return 0;
}

void CShapeFiles2TxtDlg::deleteTmpopyFile(CString sFolderPath)
{
	CFileFind finder;
	BOOL b = finder.FindFile(sFolderPath + _T("\\*.zip"));
	CString strFolderItem;


	while (b)
	{
		b = finder.FindNextFile();
		strFolderItem = finder.GetFilePath();

		if (finder.IsArchived() || finder.IsHidden())
		{
			CString sTmpFileName = finder.GetFileName();

			if (sTmpFileName.Find("_sub_folder_") >= 0)
			{
				::DeleteFile(sFolderPath + "\\" + sTmpFileName);
			}
		}
	}
}

void CShapeFiles2TxtDlg::moveTopFolder_ForSubFolder(CString sTopFolderPath, CString sNowFolderPath)
{
	CFileFind finder;
	BOOL b = finder.FindFile(sNowFolderPath + _T("\\*.*"));
	CString strFolderItem;
	

	while (b)
	{
		b = finder.FindNextFile();
		if (finder.IsDirectory() && !finder.IsDots())				// 디렉토리 발견시 
		{
			strFolderItem = finder.GetFilePath();
			moveTopFolder_ForSubFolder(sTopFolderPath, strFolderItem);			// 하위폴더를 검색하기 위해 재귀호출 발생  
		}
		strFolderItem = finder.GetFilePath();
		

		if (finder.IsArchived() && sTopFolderPath != sNowFolderPath) //파일이면서 상위 폴더가 아닌 경우 파일을 상위로 임시 복사
		{
			m_bSubFolder = TRUE;

			CString sFolderNM = sNowFolderPath;
			sFolderNM.Replace(sTopFolderPath, "");
			sFolderNM.Replace("\\", "");
			sFolderNM = "_sub_folder_" + sFolderNM + "_sub_folder_";


			CString sTmpFileName = finder.GetFileName();

			if (sTmpFileName.Right(4) == ".ZIP" || sTmpFileName.Right(4) == ".zip" || sTmpFileName.Right(4) == ".Zip")
			{
				CString s1;
				CString s2;

				s1.Format("%s\\%s", sNowFolderPath, sTmpFileName);
				s2.Format("%s\\%s%s", sTopFolderPath, sFolderNM, sTmpFileName);

				CopyFile(s1, s2, FALSE);
				SetFileAttributes(s2, FILE_ATTRIBUTE_HIDDEN);

			}
		}
	}
}


BOOL CShapeFiles2TxtDlg::openFolder(CString sPath)
{
	if (sPath == "")
	{
		BROWSEINFO BrInfo;
		TCHAR chFolderPath[2000];                                      // 경로저장 버퍼 

		::ZeroMemory(&BrInfo, sizeof(BROWSEINFO));
		::ZeroMemory(chFolderPath, 2000);

		BrInfo.hwndOwner = GetSafeHwnd();
		BrInfo.lpszTitle = _T("폴더를 선택하세요");
		BrInfo.ulFlags = BIF_NEWDIALOGSTYLE | BIF_EDITBOX | BIF_RETURNONLYFSDIRS;


		BrInfo.lpfn = BrowseCallbackProc;
		CString strInitPath = m_sLastSelectedFolder;
#if _DEBUG
		
		if (strInitPath == "")	strInitPath = _T("C:\\D\\Project\\_2020_원자력연구원\\input_files");
#endif
		BrInfo.lParam = (LPARAM)strInitPath.GetBuffer();

		LPITEMIDLIST pItemIdList = ::SHBrowseForFolder(&BrInfo);
		::SHGetPathFromIDList(pItemIdList, chFolderPath);               // 파일경로 읽어오기

		if (chFolderPath[0] == '\0')
			return FALSE;

		m_sFolderPath = chFolderPath;
		m_sLastSelectedFolder = chFolderPath;
	}
	else
	{
		m_sFolderPath = sPath;
		m_sLastSelectedFolder = sPath;
	}
	



	//파일 리스트 처리
	m_nCntFileList = 0;
	CString sFileLists = "";
	CString sFolderPath = m_sFolderPath + "\\*.zip";

	CFileFind finder;

	//CFileFind는 파일, 디렉터리가 존재하면 TRUE를 반환함
	

	CString fileName;
	CString DirName;

	//하위 폴더 내 파일 검색하여 작업 디렉토리로 이동
	moveTopFolder_ForSubFolder(m_sFolderPath, m_sFolderPath);


	BOOL bWorking = finder.FindFile(sFolderPath);
	
	//파일 개수 파악
	while (bWorking)
	{
		bWorking = finder.FindNextFile();
		
		if (finder.IsArchived() || finder.IsHidden()) //파일 일때
			if (finder.GetFileName().Right(4) == ".ZIP" || finder.GetFileName().Right(4) == ".zip" || finder.GetFileName().Right(4) == ".Zip")
				m_nCntFileList++;
	}

	//변수 할당
	if (m_nCntFileList > 0)
	{
		m_saFileList = new CString[m_nCntFileList];
		m_saFileList_Province = new CString[m_nCntFileList];
		int nLoc = 0;

		bWorking = finder.FindFile(sFolderPath);

		while (bWorking)
		{
			bWorking = finder.FindNextFile();

			if (finder.IsArchived() || finder.IsHidden()) //파일 일때
			{
				CString sTmpFileName = finder.GetFileName();

				if (sTmpFileName.Right(4) == ".ZIP" || sTmpFileName.Right(4) == ".zip" || sTmpFileName.Right(4) == ".Zip")
				{
					CString sTmpDisplayFileName = sTmpFileName;
					sTmpDisplayFileName.Replace("_sub_folder_", "\\");

					sFileLists.Format("%s%s\r\n", sFileLists, sTmpDisplayFileName);
					m_saFileList[nLoc] = sTmpFileName;
					m_saFileList_Province[nLoc] = getProvinceByFileName(sTmpFileName);
					m_saFileList_Province[nLoc] = getCleanProvinceName(m_saFileList_Province[nLoc]);

					nLoc++;
				}
			}
		}
	}
	


	sFileLists.Trim();

	m_sEditFileList = sFileLists;
	UpdateData(FALSE); //컨트롤 <- 변수


	CString str;
	str.Format(_T("'%s' 폴더 내 파일 리스트 (총 %d개 파일)"), m_sFolderPath, m_nCntFileList);

	CWnd* label = GetDlgItem(IDC_STATIC_FILE_LIST);
	label->SetWindowText(str);
	label = NULL;

	return checkFileNameRule();

}


//파일명 작성 규칙 등이 정상인지 점검
BOOL CShapeFiles2TxtDlg::checkFileNameRule()
{
	int nCntMega = 0; //광역시만 존재하는 경우
	int nCntMegaAndCty = 0; //광역시+시군구 존재하는 경우

	if (m_nCntFileList <= 0)
	{
		AfxMessageBox("작업할 파일이 존재하지 않습니다.");
		return FALSE;
	}

	for (int i = 0; i < m_nCntFileList; i++)
	{
		CStringArray saTemp;

		int count = splitString(m_saFileList_Province[i], _T(" "), saTemp);

		if (count == 1)
			nCntMega++;
		else if (count == 2 || count == 3)
			nCntMegaAndCty++;
		else
		{
			m_nError = 10003;

			CString sTemp;
			sTemp.Format("파일명에서 지역명을 추출하는데 실패하였습니다.\n-> %s", m_saFileList[i]);
			AfxMessageBox(sTemp);

			return FALSE;
		}
	}

	if (nCntMega > 0 && nCntMegaAndCty > 0)
	{
		m_nError = 10004;

		CString sTemp;
		sTemp.Format("광역시 파일과 시군구 파일이 혼재되어 있습니다.\n-> 광역시 파일: %d   시군구 파일:%d", nCntMega, nCntMegaAndCty);
		AfxMessageBox(sTemp);

		return FALSE;
	}
	else if (nCntMega > 0 || nCntMegaAndCty == 0) //광역시 모드 경우
	{
		m_nRadioGubun = 0;
		UpdateData(FALSE); //컨트롤 <- 변수
		(CWnd*)GetDlgItem(IDC_RADIO_GUBUN2)->EnableWindow(FALSE); //시군구 컨트롤 비활성
	}
	else if (nCntMega == 0 || nCntMegaAndCty > 0) //시군구 모드 경우
	{
		m_nRadioGubun = 1;
		UpdateData(FALSE); //컨트롤 <- 변수
		(CWnd*)GetDlgItem(IDC_RADIO_GUBUN2)->EnableWindow(TRUE); //시군구 컨트롤 활성
	}

	return TRUE;
}



void CShapeFiles2TxtDlg::createFieldList()
{
	//모든 파일 리스트에서 유니크한 필드 추출
	for (int i = 0; i < m_nCntFileList; i++)
	{
		CString sField = getFieldByFileName(m_saFileList[i]);
		//CString sProvinceNM = getProvinceNameByFileName(m_saFileList[i]);

		addFieldList(sField);

		if (m_nError != 0)	return;
	}

	
	//필드 추출에 이상이 없는지 체크
	if (m_nCntFieldList <= 0)
	{
		m_nError = 20001;
		AfxMessageBox("파일리스트에서 필드 정보를 추출하지 못하였습니다.");

		m_sEditFieldList = "";
		UpdateData(FALSE); //컨트롤 <- 변수
		return;
	}

	//추출된 필드 리스트에서 필드 리스트 문자열 추출
	m_sEditFieldList = getFieldListStringByFileArray();
	UpdateData(FALSE); //컨트롤 <- 변수
}



//필드 구분자가 변경되면 발생하는 이벤트 함수
void CShapeFiles2TxtDlg::OnEnChangeEditComma()
{
	// TODO:  RICHEDIT 컨트롤인 경우, 이 컨트롤은
	// CDialogEx::OnInitDialog() 함수를 재지정 
	//하고 마스크에 OR 연산하여 설정된 ENM_CHANGE 플래그를 지정하여 CRichEditCtrl().SetEventMask()를 호출하지 않으면
	// 이 알림 메시지를 보내지 않습니다.

	// TODO:  여기에 컨트롤 알림 처리기 코드를 추가합니다.

	//특수 공백문자-> 필드구분자를 지웠을 때 임시로 입력되는 문자
	CString sSpecial = " ";

	//이전 구분자
	CString sPreComma = m_sEditComma;

	//사용자가 컨트롤에 변경한 값이 변수에 반영
	UpdateData(TRUE); //컨트롤 -> 변수  

	//추출된 필드 리스트에서 필드 리스트 문자열 추출

	if (m_sEditComma == " " || m_sEditComma == "(" || m_sEditComma == ")")
	{
		AfxMessageBox("빈칸이나 괄호는 사용할 수 없습니다.");

		m_sEditComma = ",";
	}



	if (m_sEditComma == "") //사용자가 입력을 위해 구분자를 지웠을 때.
	{
		m_sEditFieldList.Replace(sPreComma, sSpecial);
		UpdateData(FALSE); //컨트롤 <- 변수
	}
	else
	{
		//m_sEditFieldList = getFieldListStringByFileArray();
		if (sPreComma == "") sPreComma = sSpecial;
		m_sEditFieldList.Replace(sPreComma, m_sEditComma);
		UpdateData(FALSE); //컨트롤 <- 변수
	}
}



CString CShapeFiles2TxtDlg::getFieldListStringByFileArray() //필드 배열에서 필드문자열 추출 함수
{
	//100세이상 인구 수(남자),100세이상 인구 수(여자),100세이상 인구 수(전체),
	//필드 순서를 보기 좋게 정렬할기 위해 "100세이상" 구문을 "9999세이상"으로 변경 후 정렬 -> 그리고 다시 원복
	if (m_nCntFieldList > 1)
	{
		for (int i = 0; i < m_nCntFieldList; i++)
			if (m_saFieldList[i].Find("100세이상") >= 0)
				m_saFieldList[i].Replace("100세이상", "9999세이상");

		for (int i = 0; i < m_nCntFieldList - 1; i++)
			for (int j = i+1; j < m_nCntFieldList; j++)
				if (m_saFieldList[i] > m_saFieldList[j])
				{
					CString sTmp = m_saFieldList[i];
					m_saFieldList[i] = m_saFieldList[j];
					m_saFieldList[j] = sTmp;
				}

		for (int i = 0; i < m_nCntFieldList; i++)
			if (m_saFieldList[i].Find("9999세이상") >= 0)
				m_saFieldList[i].Replace("9999세이상", "100세이상");
	}



	
	//추출된 필드 리스트에서 필드 리스트 문자열 추출
	CString sTmp = "";
	
	if (m_nRadioGubun == 0)			sTmp = "광역시";
	else if (m_nRadioGubun == 1)	sTmp = "시군구";

	for (int i = 0; i < m_nCntFieldList; i++)
	{
		if (sTmp == "")	sTmp = m_saFieldList[i];
		else			sTmp.Format("%s%s%s", sTmp, m_sEditComma, m_saFieldList[i]);
	}


	sTmp.Format("%s%s%s", sTmp, m_sEditComma, "X");
	sTmp.Format("%s%s%s", sTmp, m_sEditComma, "Y");

	return sTmp;
}

CString CShapeFiles2TxtDlg::getCleanProvinceName(CString sProvinceNM) //파일명에서 지역명칭 추출 함수
{
	for (int i = 0; i < m_nRuleCnt; i++)
		if (sProvinceNM == m_saRuleList1[i])
			return m_saRuleList2[i];
	
	return sProvinceNM;
}


CString CShapeFiles2TxtDlg::getProvinceByFileName(CString sFileNM) //파일명에서 지역명칭 추출 함수
{
	//(B100)국토통계_인구정보-100세이상 인구 수(남자)-(격자) 100M_서울특별시 성동구_202004.zip
	CStringArray saTemp;

	int count = splitString(sFileNM, _T("-"), saTemp);

	if (count == 3)
	{
		CString sTmp = saTemp.GetAt(2); //(격자) 100M_서울특별시 성동구_202004.zip

		saTemp.RemoveAll();
		count = splitString(sTmp, _T("_"), saTemp);

		if (count == 3)
			return saTemp.GetAt(1);
		else
		{
			m_nError = 10002;
			CString sTemp;
			sTemp.Format("파일명 작성 규칙이 적용되지 않은 파일이 있습니다.\n-> %s", sFileNM);
			AfxMessageBox(sTemp);
			return "";
		}
	}
	else
	{
		m_nError = 10001;
		CString sTemp;
		sTemp.Format("파일명 작성 규칙이 적용되지 않은 파일이 있습니다.\n-> %s", sFileNM);
		AfxMessageBox(sTemp);
		return "";
	}

	return "";
}

CString CShapeFiles2TxtDlg::getMegaNMByProvince(CString sProvince) //지역명에서 광역시 추출 함수
{
	//서울특별시 성동구
	CStringArray saTemp;

	int count = splitString(sProvince, _T(" "), saTemp);

	if (count == 1 || count == 2 || count == 3)
		return saTemp.GetAt(0);

	return "";
}


CString CShapeFiles2TxtDlg::getCtyNMByProvince(CString sProvince) //지역명에서 시군구 추출 함수
{
	//서울특별시 성동구
	CStringArray saTemp;

	int count = splitString(sProvince, _T(" "), saTemp);

	if (count == 2)
		return saTemp.GetAt(1);
	else if (count == 3) //"경상북도 포항시 남구"
		return saTemp.GetAt(1) + " " + saTemp.GetAt(2);


	return "";
}


CString CShapeFiles2TxtDlg::getFieldByFileName(CString sFileNM) //파일명에서 필드 추출 함수
{
	//(B100)국토통계_인구정보-100세이상 인구 수(남자)-(격자) 100M_서울특별시 성동구_202004.zip
	CStringArray saTemp;

	int count = splitString(sFileNM, _T("-"), saTemp);

	if (count == 3)
		return saTemp.GetAt(1);
	else
	{
		m_nError = 10001;
		CString sTemp;
		sTemp.Format("파일명 작성 규칙이 적용되지 않은 파일이 있습니다.\n-> %s", sFileNM);
		AfxMessageBox(sTemp);
		return "";
	}
}


BOOL CShapeFiles2TxtDlg::addFieldList(CString sField) //필드 리스트(m_saFieldList)에 추가함수, 동일한 필드명 등 체크
{
	if (sField == "")	return FALSE;

	BOOL bExist = FALSE;

	for (int i = 0; i < m_nCntFieldList; i++)
		if (m_saFieldList[i] == sField)
		{
			bExist = TRUE;
			break;
		}
			

	if (bExist == FALSE)
	{
		m_saFieldList[m_nCntFieldList] = sField;
		m_nCntFieldList++;
		return TRUE;
	}
	else
		return FALSE;
}



int CShapeFiles2TxtDlg::splitString(CString str, CString var, CStringArray& strs)
{
	int count = 0;

	CString tempStr = str;

	int length = str.GetLength();
	int nLoc = 0;

	while (1)
	{
		int find = tempStr.Find(var, nLoc);
		if (find != -1)
		{
			strs.Add(tempStr.Mid(nLoc, find - nLoc));
			nLoc = find + 1;
			count++;
		}
		else
		{
			strs.Add(tempStr.Mid(nLoc));
			count++;
			break;
		}
	}
	return count;
}


BOOL CreateDir(CString dir)
{
	CFileFind file;
	CString strFile = _T("*.*");
	BOOL bResult = file.FindFile(dir + strFile);

	if (!bResult)
	{
		bResult = CreateDirectory(dir, NULL);
	}

	return bResult;
}

BOOL DeleteDir(CString dir)
{
	if (dir == _T(""))
	{
		return FALSE;
	}

	BOOL bRval = FALSE;
	int nRval = 0;
	CString szNextDirPath = _T("");
	CString szRoot = _T("");
	CFileFind find;

	// Directory가 존재 하는지 확인 검사
	bRval = find.FindFile(dir);

	if (bRval == FALSE)
	{
		return bRval;
	}

	while (bRval)
	{
		bRval = find.FindNextFile();

		// . or .. 인 경우 무시한다.
		if (find.IsDots() == TRUE)
		{
			continue;
		}

		// Directory 일 경우
		if (find.IsDirectory())
		{
			szNextDirPath.Format(_T("%s\\*.*"), find.GetFilePath());

			// Recursion function 호출
			DeleteDir(szNextDirPath);
		}

		// file일 경우
		else
		{
			//파일 삭제
			::DeleteFile(find.GetFilePath());
		}
	}

	szRoot = find.GetRoot();
	find.Close();

	Sleep(1);
	bRval = RemoveDirectory(szRoot);

	return bRval;
}


CString AnsiToUTF8RetCString(CString InputStr)
{
	WCHAR szUnicode[40000];
	char szUTF8char[40000];

	CString strConver;
	char* szSrc = (LPSTR)(LPCTSTR)InputStr;

	char szRetVale[40000] = "";

	// 	EUC-KR 케릭터셋의 ANSI 문자를 유니코드로 변환
	int UnicodeSize = MultiByteToWideChar(CP_ACP, 0, szSrc, (int)strlen(szSrc), szUnicode, sizeof(szUnicode));
	// 	유니코드를 UTF-8 케릭터셋의 ANSI 문자로 변환
	int UTF8CodeSize = WideCharToMultiByte(CP_UTF8, 0, szUnicode, UnicodeSize, szUTF8char, sizeof(szUTF8char), NULL, NULL);

	memcpy(szRetVale, szUTF8char, UTF8CodeSize);
	strConver = szRetVale;

	return strConver;
}

void KShellExecute(HWND handle, char* exe, char* param, char* dir)
{
	DWORD ExitCode;
	SHELLEXECUTEINFO SEInfo;

	memset(&SEInfo, 0, sizeof(SEInfo));
	SEInfo.cbSize = sizeof(SHELLEXECUTEINFO);

	SEInfo.fMask = SEE_MASK_NOCLOSEPROCESS;
	SEInfo.hwnd = handle;
	SEInfo.lpFile = exe;
	SEInfo.lpParameters = param;
	SEInfo.lpDirectory = dir;
	SEInfo.nShow = SW_HIDE; // SW_SHOWNORMAL;


	if (ShellExecuteEx(&SEInfo) == TRUE)
	{
		do{
			GetExitCodeProcess(SEInfo.hProcess, &ExitCode);
		} while (ExitCode); // wait until the command is finished
	}

}




void CShapeFiles2TxtDlg::OnBnClickedOk()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	//CDialogEx::OnOK();



	if (m_nCntFileList <= 0)
	{
		AfxMessageBox("작업 폴더가 선택되지 않았습니다.");
		return;
	}

	if (m_sEditComma == "")
	{
		AfxMessageBox("필드 구분자가 입력되지 않았습니다.");
		return;
	}



	


	CString sResultFilePath = "";
	static TCHAR BASED_CODE szFilter[] = _T("txt 파일(*.txt) | *.txt |모든파일(*.*)|*.*||");
	CFileDialog dlg(FALSE, _T("*.jpg"), _T("_result"), OFN_HIDEREADONLY, szFilter);
	dlg.m_ofn.lpstrInitialDir = m_sFolderPath;
	dlg.m_ofn.lpstrTitle = TEXT("결과 파일 저장");


	if (IDOK == dlg.DoModal())
	{
		sResultFilePath = dlg.GetPathName();
	}

	if (sResultFilePath == "")
	{
		AfxMessageBox("저장할 파일을 지정하지 않았습니다.");
		return;
	}








	UpdateData(TRUE); //컨트롤 -> 변수
	//사용자가 입력한 필드 리스트 문제 없는 지 점검
	CString sTmpFields1 = m_sEditFieldList; //사용자가 입력(수정한 필드 리스트)
	CString sTmpFields2 = getFieldListStringByFileArray(); //파일에서 추출된 필드 리스트
	

	CStringArray saTmpFields1;
	int nTmpFields1 = splitString(sTmpFields1, m_sEditComma, saTmpFields1);

	CStringArray saTmpFields2;
	int nTmpFields2 = splitString(sTmpFields2, m_sEditComma, saTmpFields2);
	
	//사용자가 입력한 필드 리스트에 문제가 없는지 점검
	for (int i = 0; i < nTmpFields1; i++)
	{
		BOOL bTempExist = FALSE;
		for (int j = 0; j < nTmpFields2; j++)
		{
			CString s1 = saTmpFields1.GetAt(i); CString s2 = saTmpFields2.GetAt(j);
			if (saTmpFields1.GetAt(i) == saTmpFields2.GetAt(j))
			{
				bTempExist = TRUE;
				break;
			}
		}

		if (bTempExist == FALSE)
		{
			CString sTemp;
			sTemp.Format("필드명이 잘못 입력됐습니다..\n-> %s", saTmpFields1.GetAt(i));
			AfxMessageBox(sTemp);

			return;
		}
	}
	
	




	m_ctrlProgress.SetRange32(0, m_nCntFileList);

	

	//작업용 임시 폴더 생성
	//날짜구하기
	CString strDate;
	COleDateTime tToday = COleDateTime::GetCurrentTime();
	strDate = "_tmp_" + tToday.Format(_T("%H.%M.%S"));

	CString sTmpFolder = m_sFolderPath + "\\" + strDate;
	//CString sTmpFolder = "C:\\D\\Project\\_2020_원자력연구원\\input_files\\" + strDate;

	BOOL bResult = CreateDir(sTmpFolder);

	if (bResult == FALSE)
	{
		m_nError = 50001; //작업용 임시  폴더 생성 실패
		AfxMessageBox("작업용 임시 폴더 생성 실패!");
	}


	CWnd* labProgress = GetDlgItem(IDC_STATIC_PROGRESS);
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//1.압축 해제 + 파일명변경  
	labProgress->SetWindowText("단계별 작업 중 (1/5) ...");

	CString csFolder;
	CString sExe;

	GetModuleFileName(NULL, csFolder.GetBuffer(_MAX_PATH), _MAX_PATH);
	csFolder.ReleaseBuffer();
	csFolder = csFolder.Left(csFolder.ReverseFind(_TCHAR('\\')));
	csFolder.Replace("\\.\\", "\\");
	sExe.Format(_T("%s%s"), csFolder, "\\_sys\\7z.exe");

	

	for (int i = 0; i < m_nCntFileList; i++)
	{
		//1.압축 해제
		//파일명과 폴더명에 빈칸이 있어 문제 발생 -> 앞뒤로 따옴표 처리
		CString sZip = "\"" + m_sFolderPath + "\\" + m_saFileList[i] + "\"";
		CString sShp = "\"" + sTmpFolder + "\"";

		CString sPara;
		sPara.Format("x %s -o%s -aoa", sZip, sShp);


		char* pExe = LPSTR(LPCTSTR(sExe));
		char* Para = LPSTR(LPCTSTR(sPara));

		KShellExecute(NULL, pExe, Para, NULL);

		//2.파일명변경
		changeTotalShpNM_to_NewTempNM_inFolder(sTmpFolder, m_saFileList[i]);

		m_ctrlProgress.SetPos(i+1);
		DoEvents();
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//2. SHP 파일명으로 변경  
	labProgress->SetWindowText("단계별 작업 중 (2/5) ...");
	m_ctrlProgress.SetPos(0);
	//3. shp 파일 확장자로 복원
	changeTotalFineShpNM(sTmpFolder);
	DoEvents();


	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//3. txt 파일로 변환  
	m_ctrlProgress.SetPos(0);
	for (int i = 0; i < m_nCntFileList; i++)
	{
		CString sProvince = "";
		CString sField = "";
		
		
		if(m_nRadioGubun == 0)//광역시 모드이면 
			sProvince = getMegaNMByProvince(m_saFileList_Province[i]);
		else if (m_nRadioGubun == 1)//시군구 모드이면 
			sProvince = getCtyNMByProvince(m_saFileList_Province[i]);

		sField = getFieldByFileName(m_saFileList[i]);
		CString sOrder = getFieldOrderStringByArray(sField);
		sField.Format("%s-%s", sOrder, sField); //필드명에 필드 순서 추가
		

		CString sTempShp = sTmpFolder + "\\" + m_saFileList[i] + ".shp";
		CString sTempDbf = sTmpFolder + "\\" + m_saFileList[i] + ".dbf";
		CString sTempTxt = sTmpFolder + "\\" + m_saFileList[i] + ".txt";

		char* strTempShp = LPSTR(LPCTSTR(sTempShp));
		char* strTempDbf = LPSTR(LPCTSTR(sTempDbf));
		char* strTempTxt = LPSTR(LPCTSTR(sTempTxt));

		SHPHandle shpFile = NULL;
		DBFHandle dbfFile = NULL;
		FILE* streamOut = NULL;


		shpFile = SHPOpen(strTempShp, "rb");
		dbfFile = DBFOpen(strTempDbf, "rb");
		fopen_s(&streamOut, strTempTxt, "w");

		if (shpFile == NULL || dbfFile == NULL || streamOut == NULL)
		{
			m_nError = 50004; //SHP 파일 열기 실패
			AfxMessageBox("SHP 파일 열기 실패!");
			return;
		}

		int nRowCnt = dbfFile->nRecords;

		
		//컬럼 중 VAL 인덱스 확인
		int nColCnt = DBFGetFieldCount(dbfFile);
		int nValIdx = DBFGetFieldIndex(dbfFile, "VAL");
		int nGidIdx = DBFGetFieldIndex(dbfFile, "GID");

		if (nValIdx < 0 || nGidIdx < 0)
		{
			m_nError = 50005; //SHP 파일 필드 구조에 문제가 있습니다.
			AfxMessageBox("SHP 파일 필드 구조에 문제가 있습니다.");
			return;
		}
		
		
		//Polygon Shapefile
		if (shpFile->nShapeType == SHPT_POLYGON)
		{
			for (int i = 0; i < shpFile->nRecords; i++)
			{
				SHPObject* psShp = SHPReadObject(shpFile, i);

				double fCenterX = psShp->dfXMin + (psShp->dfXMax - psShp->dfXMin) / 2;
				double fCenterY = psShp->dfYMin + (psShp->dfYMax - psShp->dfYMin) / 2;

				double fVal = DBFReadDoubleAttribute(dbfFile, i, nValIdx);
				CString sGID = DBFReadStringAttribute(dbfFile, i, nGidIdx);

				CString sLine = "";
				sLine.Format("%s\t%s\t%s\t%f\t%f\t%f", sProvince, sGID, sField, fVal, fCenterX, fCenterY);
				fprintf(streamOut, "%s\n", sLine);

				SHPDestroyObject(psShp);
			}
		}
		else
		{
			m_nError = 50006; //SHP가 폴리곤 형태가 아닙니다.
			AfxMessageBox("SHP가 폴리곤 형태가 아닙니다.");
			return;
		}

		DBFClose(dbfFile);
		dbfFile = NULL;

		SHPClose(shpFile);
		shpFile = NULL;

		fclose(streamOut);
		streamOut = NULL;
		

		m_ctrlProgress.SetPos(i + 1);
	}
	

	labProgress->SetWindowText("단계별 작업 중 (3/5) ...");
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//4. txt 파일 통합 
	
	int nTotalFileLineCnt = 0;
	CString sTotalFile = sTmpFolder + "\\_total.txt";
	char* pTotalFile = LPSTR(LPCTSTR(sTotalFile));
	FILE* streamTotalOut = NULL;
	fopen_s(&streamTotalOut, pTotalFile, "w");

	m_ctrlProgress.SetPos(0);
	for (int i = 0; i < m_nCntFileList; i++)
	{
		CString sTxt = sTmpFolder + "\\" + m_saFileList[i] + ".txt";
		char* pTxt = LPSTR(LPCTSTR(sTxt));

		FILE* stream;
		fopen_s(&stream, pTxt, "r");

		if (stream != NULL)
		{
			char chTemp[2000];
			while (fgets(chTemp, 2000, stream) != NULL) //한줄씩 읽기
			{
				fprintf(streamTotalOut, "%s", chTemp);
				nTotalFileLineCnt++;
			}
		}
		fclose(stream);

		m_ctrlProgress.SetPos(i + 1);
	}

	fclose(streamTotalOut);
	streamTotalOut = NULL;


	m_ctrlProgress.SetPos(0);



	labProgress->SetWindowText("단계별 작업 중 (4/5) ...");
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//5. 통합 txt 파일 정렬 
	//cmsort /S=0,60 /H=0 in.CSV out.txt
	sExe.Format(_T("%s%s"), csFolder, "\\_sys\\cmsort.exe");

	//파일명과 폴더명에 빈칸이 있어 문제 발생 -> 앞뒤로 따옴표 처리
	CString sTotalIn = "\"" + sTotalFile + "\"";
	CString sTotalOut = "\"" + sTotalFile + "\"";
	sTotalOut.Replace(".txt\"", ".total\"");

	CString sPara;
	sPara.Format("/S=0,60 /H=0 %s %s", sTotalIn, sTotalOut);


	char* pExe = LPSTR(LPCTSTR(sExe));
	char* Para = LPSTR(LPCTSTR(sPara));

	KShellExecute(NULL, pExe, Para, NULL);

	DoEvents();
	


	labProgress->SetWindowText("단계별 작업 중 (5/5) ...");
	/////////////////////////////////////////////////////////////////////////////////////////////////////////
	//6. 사용자가 입력할 필드를 기준으로 txt 파일 생성
	CStringArray saInputFields;
	CString sFieldList = m_sEditFieldList;
	sFieldList.MakeUpper();

	int countCols = splitString(sFieldList, m_sEditComma, saInputFields);

	if (countCols < 3)
	{
		AfxMessageBox("'생성될 필드 리스트'의 필드 개수가 3개 미만입니다.");
		return;
	}

	BOOL bX = FALSE;
	BOOL bY = FALSE;
	for (int i = 0; i < countCols; i++)
		if (saInputFields.GetAt(i) == "X" || saInputFields.GetAt(i) == "X_AXIS")
		{
			bX = TRUE;
			break;
		}
	for (int i = 0; i < countCols; i++)
		if (saInputFields.GetAt(i) == "Y" || saInputFields.GetAt(i) == "Y_AXIS")
		{
			bY = TRUE;
			break;
		}

	if (bX == FALSE || bY == FALSE)
	{
		AfxMessageBox("'생성될 필드 리스트'에 X, Y 필드가 입력되지 않았습니다.");
		return;
	}
			


	//사용자가 입력한 필드 순으로 정보를 취합하는 변수배열 선언
	CString* saOutField = new CString[countCols];
	int nResultLoc = 0;

	//total 파일 읽어 들여 작업 시작
	m_ctrlProgress.SetRange32(0, nTotalFileLineCnt);
	
	//cmd 파라미터로 사용하기 위해 앞뒤로 따옴표 붙인 것 제외
	sTotalOut.Replace("\"", "");
	char* pTotalOut = LPSTR(LPCTSTR(sTotalOut));

	CString sResultFile = sResultFilePath; // m_sFolderPath + "\\_Result.txt";
	char* pResultFile = LPSTR(LPCTSTR(sResultFile));


	FILE* stream;
	fopen_s(&stream, pTotalOut, "r");
	FILE* streamResult = NULL;
	//fopen_s(&streamResult, pResultFile, "w"); //ansi
	fopen_s(&streamResult, pResultFile, "wb,ccs=UTF-8"); //UTF8

	//해더 추가
	
	fprintf(streamResult, "%s\n", AnsiToUTF8RetCString(m_sEditFieldList));

	{
		if (stream != NULL)
		{
			CString sGID = "";
			char chTemp[2000];
			BOOL bNewLine = TRUE;
			while (fgets(chTemp, 2000, stream) != NULL) //한줄씩 읽기
			{
				//성동구|다사565495|0000-20대 인구 수(남자)|0.000000|956550.000000|1949550.000000
				/*
				0 : 지역명
				1 : GID
				2 : Value 종류
				3 : Value
				4 : X
				5 : Y
				*/				
				CStringArray saTemp2;
				int count2 = splitString(chTemp, _T("\t"), saTemp2);

				if (count2 == 6)
				{
					if (sGID != saTemp2.GetAt(1) && sGID != "") //새로운 격자가 시작하는 경우 배열에 담긴 값을 저장
					{
						CString sRow = "";
						for (int i = 0; i < countCols; i++)
						{
							if (sRow != "")	sRow += m_sEditComma;
							sRow += saOutField[i];
						}

						//마지막에 개행 있으면 제거 
						//trim()하면 탭을 구분자로 사용했을 때 문제 발생

						if (sRow.Right(2) == "\r\n")	sRow = sRow.Mid(0, sRow.GetLength() - 2);
						if (sRow.Right(1) == "\n")		sRow = sRow.Mid(0, sRow.GetLength() - 1);
						
						/*
						//UTF8 변환
						char* chRow = LPSTR(LPCTSTR(sRow));
						char* chTempAnsi = ANSIToUTF8(chRow);
						sRow.Format("%s", chTempAnsi);
						delete chTempAnsi;
						*/
						fprintf(streamResult, "%s\n", AnsiToUTF8RetCString(sRow));

						//배열 초기화
						for (int i = 0; i < countCols; i++)
							saOutField[i] = "";

						bNewLine = TRUE;
					}

					
					if (bNewLine == TRUE) //VAL 변수를 제외한 모든 배열 값 세팅
					{
						double fX = 0;
						double fY = 0;
						int nIdxX = 0;
						int nIdxY = 0;

						for (int i = 0; i < countCols; i++)
						{
							if (saInputFields.GetAt(i) == "광역시" || saInputFields.GetAt(i) == "시군구")	
								saOutField[i] = saTemp2.GetAt(0);
							else if (saInputFields.GetAt(i) == "X" || saInputFields.GetAt(i) == "X_AXIS")
							{
								saOutField[i] = saTemp2.GetAt(4);
								fX = atof(saTemp2.GetAt(4));
								nIdxX = i;
							}
							else if (saInputFields.GetAt(i) == "Y" || saInputFields.GetAt(i) == "Y_AXIS")
							{
								saOutField[i] = saTemp2.GetAt(5);
								fY = atof(saTemp2.GetAt(5));
								nIdxY = i;
							}
						}

						//UTM -> TM 변경
						CString sNewXY = "";

						if(m_nRadioPrj == 0)		sNewXY = "";					//UTMK <- 입력 데이터가 UTMK 니까 아무 작업 안함
						else if (m_nRadioPrj == 1)	sNewXY = UTMK2GEO(fX, fY);		//경위도
						else if (m_nRadioPrj == 2)	sNewXY = UTMK2KTM(fX, fY);		//TM
						else if (m_nRadioPrj == 3)	sNewXY = UTMK2GRS(fX, fY);		//GRS80
						else if (m_nRadioPrj == 4)	sNewXY = UTMK2GRS_OLD(fX, fY);	//GRS80_OLD
						
						CStringArray saNewXY;
						int count2 = splitString(sNewXY, m_sEditComma, saNewXY);
						if (count2 == 2)
						{
							saOutField[nIdxX] = saNewXY.GetAt(0);
							saOutField[nIdxY] = saNewXY.GetAt(1);
						}
					}


					CString sValueNM = saTemp2.GetAt(2); //Value 종류
					sValueNM = sValueNM.Mid(5); //앞부분 인덱스 제거  "0000-20대 인구 수(남자)" -> "20대 인구 수(남자)"

					for (int i = 0; i < countCols; i++)
						if(saInputFields.GetAt(i) == sValueNM)
						{
							saOutField[i] = saTemp2.GetAt(3);
							break;
						}

					sGID = saTemp2.GetAt(1);
					bNewLine = FALSE;
				}

				nResultLoc++;
				if(nResultLoc % 5 == 0) //파일 용량이 큰 경우 프로그래스바 매번 갱신하면 속도 느려지는 원인: 5번에 한번씩 갱신
					m_ctrlProgress.SetPos(nResultLoc);
			}

			//마지막 Row 추가
			CString sRow = "";
			for (int i = 0; i < countCols; i++)
			{
				if (sRow != "")	sRow += m_sEditComma;
				sRow += saOutField[i];
			}

			//마지막에 개행 있으면 제거 
			//trim()하면 탭을 구분자로 사용했을 때 문제 발생
			if (sRow.Right(2) == "\r\n")	sRow = sRow.Mid(0, sRow.GetLength() - 2);
			if (sRow.Right(1) == "\n")		sRow = sRow.Mid(0, sRow.GetLength() - 1);

			/*
			//UTF8 변환
			char* chRow = LPSTR(LPCTSTR(sRow));
			char* chTempAnsi = ANSIToUTF8(chRow);
			sRow.Format("%s", chTempAnsi);
			delete chTempAnsi;
			*/
			fprintf(streamResult, "%s\n", AnsiToUTF8RetCString(sRow));

			//배열 초기화
			for (int i = 0; i < countCols; i++)
				saOutField[i] = "";


		}
	}
	
	fclose(streamResult);
	streamResult = NULL;
	fclose(stream);
	stream = NULL;

	
	

	delete[] saOutField;
	saOutField = NULL;



	//작업 완료 후 임시 폴더 삭제
	UpdateData(TRUE); //컨트롤 -> 변수
	if(m_nCheckTmpFolderNoDelete == FALSE)
		DeleteDir(sTmpFolder);

	labProgress->SetWindowText("");
	m_ctrlProgress.SetPos(0);
	labProgress = NULL;


	//서브 폴더 임시 파일 삭제
	if (m_bSubFolder == TRUE)
	{
		deleteTmpopyFile(m_sFolderPath);
		init();
	}

	AfxMessageBox("작업 완료!\r\n저장 파일 위치: " + sResultFilePath);

}




//작업 폴더 내 shp 파일을 해당 이름의 파일로 변경
void CShapeFiles2TxtDlg::changeTotalShpNM_to_NewTempNM_inFolder(CString sFolderPath, CString sNewNM)
{
	CFileFind finder;

	//CFileFind는 파일, 디렉터리가 존재하면 TRUE 를 반환함
	BOOL bWorking = finder.FindFile(sFolderPath + "\\*.*");

	CString fileName;
	CString DirName;

	while (bWorking)
	{
		bWorking = finder.FindNextFile();

		if (!finder.IsDots()) //파일 일때
		{
			CString sTmp = finder.GetFileName();
			CString sTmp2 = sTmp.MakeUpper();


			sTmp = sFolderPath + "\\" + sTmp;
			CString sOut = sFolderPath + "\\" +sNewNM;


			if (sTmp2.Right(4) == ".SHP")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sOut + ".shp_tmp"));
			else if (sTmp2.Right(4) == ".SHX")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sOut + ".shx_tmp"));
			else if (sTmp2.Right(4) == ".DBF")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sOut + ".dbf_tmp"));
			else if (sTmp2.Right(4) == ".PRJ")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sOut + ".prj_tmp"));
		}
	}
}


int CShapeFiles2TxtDlg::getFieldOrderByArray(CString  sField)
{
	for (int i = 0; i < m_nCntFieldList; i++)
		if (m_saFieldList[i] == sField)
			return i;

	return -1;
}


CString CShapeFiles2TxtDlg::getFieldOrderStringByArray(CString  sField)
{
	CString sIdx = "";
	int nIdx = 9999;
	for (int i = 0; i < m_nCntFieldList; i++)
		if (m_saFieldList[i] == sField)
		{
			nIdx = i;
			break;
		}

	if (nIdx < 10)			sIdx.Format("000%d", nIdx);
	else if (nIdx < 100)	sIdx.Format("00%d", nIdx);
	else if (nIdx < 1000)	sIdx.Format("0%d", nIdx);
	else					sIdx.Format("%d", nIdx);


	return sIdx;
}





//작업 폴더 내 임시 shp 확장자 정상 shp 확장자로 변경
void CShapeFiles2TxtDlg::changeTotalFineShpNM(CString sFolderPath)
{
	CFileFind finder;

	//CFileFind는 파일, 디렉터리가 존재하면 TRUE 를 반환함
	BOOL bWorking = finder.FindFile(sFolderPath + "\\*.*");

	CString fileName;
	CString DirName;

	while (bWorking)
	{
		bWorking = finder.FindNextFile();

		if (!finder.IsDots()) //파일 일때
		{
			CString sTmp = finder.GetFileName();


			sTmp = sFolderPath + "\\" + sTmp;

			if (sTmp.Right(8) == ".shp_tmp")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sTmp.Mid(0, sTmp.GetLength() -8) + ".shp"));
			else if (sTmp.Right(8) == ".shx_tmp")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sTmp.Mid(0, sTmp.GetLength() - 8) + ".shx"));
			else if (sTmp.Right(8) == ".dbf_tmp")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sTmp.Mid(0, sTmp.GetLength() - 8) + ".dbf"));
			else if (sTmp.Right(8) == ".prj_tmp")
				CFile::Rename(LPCTSTR(sTmp), LPCTSTR(sTmp.Mid(0, sTmp.GetLength() - 8) + ".prj"));

			DoEvents();
		}
	}
}


void ExitMFCApp()
{
	// same as double-clicking on main window close box
	ASSERT(AfxGetMainWnd() != NULL);
	AfxGetMainWnd()->SendMessage(WM_CLOSE);
}


void CShapeFiles2TxtDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (nID == SC_CLOSE)
	{
		if(m_sFolderPath != "")
			deleteTmpopyFile(m_sFolderPath);


		if (m_saRuleList1 != NULL)	delete[] m_saRuleList1;
		m_saRuleList1 = NULL;

		if (m_saRuleList2 != NULL)	delete[] m_saRuleList2;
		m_saRuleList2 = NULL;


		//종료버튼 눌릴 시
		init(); //메모리 해제

		if (m_oTrans != NULL)
			delete m_oTrans;

		ExitMFCApp();
	}

	CDialogEx::OnSysCommand(nID, lParam);
}



















/////////////////////////////////////////////////////////////////////////////////////////////////////////////
//좌표변환
/*
	UTMK: 		GRS80 UTMK(EPSG: 5179)
	KA:			카텍좌표계
	KTM: 		Bessel TM 중부원점(EPSG:5174)
	GRS: 		GRS80 TM 중부원점(EPSG: 5186, 가산 20만/60만 최신)
	GRS_OLD:	GRS80 TM 중부원점(EPSG: 5181, 가산 20만/50만 과거)
	GEO: 		WGS84 경위도(EPSG:4326)
*/

CString CShapeFiles2TxtDlg::UTMK2TM(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->UTMK, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

///*
CString CShapeFiles2TxtDlg::UTMK2KTM(double fX, double fY)
{
	//return UTMK2TM(fX,fY); //?????
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->UTMK, m_oTrans->TM, pt1);


	CString sTemp;
	sTemp.Format("%.2f%s%.2f"
		, (getTM_X_byKTM(pt2->getX(), pt2->getY()))
		, m_sEditComma
		, (getTM_Y_byKTM(pt2->getX(), pt2->getY()))
	);

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}
//*/

CString CShapeFiles2TxtDlg::UTMK2KA(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->UTMK, m_oTrans->KATEC, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::UTMK2GRS(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->UTMK, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::UTMK2GRS_OLD(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->UTMK, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::UTMK2GEO(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->UTMK, m_oTrans->GEO, pt1);

	CString sTemp;
	sTemp.Format("%f%s%f", pt2->getX(), m_sEditComma, pt2->getY());

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::KA2TM(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->KATEC, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

///*
CString CShapeFiles2TxtDlg::KA2KTM(double fX, double fY)
{
	//return KA2TM(fX,fY); //?????
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->KATEC, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f"
		, (getTM_X_byKTM(pt2->getX(), pt2->getY()))
		, m_sEditComma
		, (getTM_Y_byKTM(pt2->getX(), pt2->getY()))
	);

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}
//*/


CString CShapeFiles2TxtDlg::KA2GRS(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->KATEC, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::KA2GRS_OLD(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->KATEC, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::KA2GEO(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->KATEC, m_oTrans->GEO, pt1);

	CString sTemp;
	sTemp.Format("%f%s%f", pt2->getX(), m_sEditComma, pt2->getY());

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::KA2UTMK(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->KATEC, m_oTrans->UTMK, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::TM2KA(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->KATEC, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::TM2GEO(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->GEO, pt1);

	CString sTemp;
	sTemp.Format("%f%s%f", pt2->getX(), m_sEditComma, pt2->getY());

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::TM2UTMK(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->UTMK, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::KTM2GRS(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	//pt1 = new GeoPoint(fX, fY);
	pt1 = new GeoPoint(getKTM_X_byTM(fX, fY), getKTM_Y_byTM(fX, fY));
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::KTM2GRS_OLD(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	//pt1 = new GeoPoint(fX, fY);
	pt1 = new GeoPoint(getKTM_X_byTM(fX, fY), getKTM_Y_byTM(fX, fY));
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}



///*
CString CShapeFiles2TxtDlg::KTM2KA(double fX, double fY)
{
	//return TM2KA(fX, fY); //?????
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(getKTM_X_byTM(fX, fY), getKTM_Y_byTM(fX, fY));
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->KATEC, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}
//*/

///*
CString CShapeFiles2TxtDlg::KTM2GEO(double fX, double fY)
{
	//return TM2GEO(fX, fY); //?????
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(getKTM_X_byTM(fX, fY), getKTM_Y_byTM(fX, fY));
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->GEO, pt1);

	CString sTemp;
	sTemp.Format("%f%s%f", pt2->getX(), m_sEditComma, pt2->getY());

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}
//*/
///*
CString CShapeFiles2TxtDlg::KTM2UTMK(double fX, double fY)
{
	//return TM2UTMK(fX, fY); //?????
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(getKTM_X_byTM(fX, fY), getKTM_Y_byTM(fX, fY));
	pt2 = m_oTrans->convert(m_oTrans->TM, m_oTrans->UTMK, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}
//*/









CString CShapeFiles2TxtDlg::GEO2TM(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GEO, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

///*
CString CShapeFiles2TxtDlg::GEO2KTM(double fX, double fY)
{
	//return GEO2TM(fX,fY); //?????
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GEO, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f"
		, (getTM_X_byKTM(pt2->getX(), pt2->getY()))
		, m_sEditComma
		, (getTM_Y_byKTM(pt2->getX(), pt2->getY()))
	);

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}
//*/

CString CShapeFiles2TxtDlg::GEO2KA(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GEO, m_oTrans->KATEC, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", pt2->getX(), m_sEditComma, pt2->getY());

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::GEO2UTMK(double fX, double fY)
{
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GEO, m_oTrans->UTMK, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::GEO2GRS(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;
	
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GEO, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GEO2GRS_OLD(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GEO, m_oTrans->GRS80, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}






CString CShapeFiles2TxtDlg::GRS2KA(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->KATEC, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GRS_OLD2KA(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->KATEC, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}



CString CShapeFiles2TxtDlg::GRS2KTM(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%c%.2f"
		, (getTM_X_byKTM(pt2->getX(), pt2->getY()))
		, m_sEditComma
		, (getTM_Y_byKTM(pt2->getX(), pt2->getY()))
	);

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GRS_OLD2KTM(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->TM, pt1);

	CString sTemp;
	sTemp.Format("%.2f%c%.2f"
		, (getTM_X_byKTM(pt2->getX(), pt2->getY()))
		, m_sEditComma
		, (getTM_Y_byKTM(pt2->getX(), pt2->getY()))
	);

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GRS2GEO(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->GEO, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GRS_OLD2GEO(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->GEO, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GRS2UTMK(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 600000.0;
	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->UTMK, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}

CString CShapeFiles2TxtDlg::GRS2GRS_OLD(double fX, double fY)
{
	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (fX), m_sEditComma, (fY - 100000));

	return sTemp;
}




CString CShapeFiles2TxtDlg::GRS_OLD2UTMK(double fX, double fY)
{
	m_oTrans->m_arFalseNorthing[m_oTrans->GRS80] = 500000.0;

	if (m_oTrans == NULL)	m_oTrans = new GeoTrans();

	pt1 = new GeoPoint(fX, fY);
	pt2 = m_oTrans->convert(m_oTrans->GRS80, m_oTrans->UTMK, pt1);

	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (pt2->getX()), m_sEditComma, (pt2->getY()));

	delete pt1;
	pt1 = NULL;
	delete pt2;
	pt2 = NULL;

	return sTemp;
}


CString CShapeFiles2TxtDlg::GRS_OLD2GRS(double fX, double fY)
{
	CString sTemp;
	sTemp.Format("%.2f%s%.2f", (fX), m_sEditComma, (fY + 100000));

	return sTemp;
}




long double a1 = -0.000014723386563L;
long double a2 = 0.000013912266726L;
long double b1 = 5.223810949L;
long double b2 = -7.734590529L;



double CShapeFiles2TxtDlg::getKTM_X_byTM(double fX, double fY)
{
	long double dX = -6.0L / 1000000.0L * fX + ((a1 * fY) + b1);
	return fX - dX;
}
double CShapeFiles2TxtDlg::getKTM_Y_byTM(double fX, double fY)
{
	long double dY = -6.0L / 1000000.0L * fY + ((a2 * fX) + b2);
	return fY - dY;
}

//기존에 사용하던 TM(일본기준) -> 우리나라기준 TM
double CShapeFiles2TxtDlg::getTM_X_byKTM(double fX, double fY)
{
	// -6 / 1000000 * XX + ( (-0.000014723386563*YY) + 5.223810949)
	long double dX = -6.0L / 1000000.0L * fX + ((a1 * fY) + b1);
	return fX + dX;
}
double CShapeFiles2TxtDlg::getTM_Y_byKTM(double fX, double fY)
{
	//=-6 / 1000000 * E2 + ((0.000013912266726 * D2) -7.734590529)
	long double dY = -6.0L / 1000000.0L * fY + ((a2 * fX) + b2);
	return fY + dY;
}


void CShapeFiles2TxtDlg::OnDropFiles(HDROP hDropInfo)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.

	int nFiles;
	char szPathName[MAX_PATH];  // 파일 경로명이 들어간다.
	CString strFileName;

	// 드래그앤드롭된 파일의 갯수
	nFiles = ::DragQueryFile(hDropInfo, 0xFFFFFFFF, szPathName, MAX_PATH);


	if (nFiles < 1)
	{
		//MessageBox("폴더를 선택하세요.", "알림");
	}
	else if (nFiles > 1)
	{
		MessageBox("최 상위 폴더 1개만 선택하여 Drag & Drop 하세요.", "알림");
		return;
	}

	// 파일의 경로 얻어옴
	::DragQueryFile(hDropInfo, 0, szPathName, MAX_PATH);

	CString strFilePath = szPathName;
	DWORD dwAttrib = GetFileAttributes(strFilePath);

	// 존재하지 않거나 Folder가 아니면 Make
	if (dwAttrib == 0xffffffff || (dwAttrib & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
	{
		MessageBox("폴더만 Drag & Drop이 가능합니다.", "알림");
	}


	init();
	if (openFolder(szPathName) == TRUE)
	{
		createFieldList();
	}

	CDialogEx::OnDropFiles(hDropInfo);
}


void CShapeFiles2TxtDlg::OnBnClickedButton1()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString sPara = "http://policymap.kr/_file/POPCON_ver1.0_SW_info.pdf";
	ShellExecute(NULL, "open", sPara, NULL, NULL, SW_SHOWNORMAL);
}


void CShapeFiles2TxtDlg::OnBnClickedButton3()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString sPara = "http://policymap.kr/_file/POPCON_ver1.0_SW_info.pdf";
	ShellExecute(NULL, "open", sPara, NULL, NULL, SW_SHOWNORMAL);
}
