﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Diagnostics;

namespace sbdd
{
    class ClassFtFlag
    {
        public static string FlagFileName;
        private static bool FlagTrue;
        public static List<FlagGate> FlagEvent;

        public static void CheckFlag(sbdd form, string file)
        {
            sbdd.FlagProcTime = new Stopwatch();
            sbdd.FlagProcTime.Start();

            StreamReader strReader = new StreamReader(file);

            #region read flag block

            ReadFlagBlock(strReader);
            form.txtboxCmd.AppendText("(" + FlagEvent.Count.ToString() + " flags detected, ");
            sbdd.CmdTxt += "(" + FlagEvent.Count.ToString() + " flags detected, ";
            
            #endregion

            #region write flag file

            WriteFlagFile(form, file);

            #endregion

            sbdd.FlagProcTime.Stop();

            form.txtboxCmd.AppendText(sbdd.FlagProcTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += sbdd.FlagProcTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
            
            strReader.Close();
        }

        public static void WriteFlagFile(sbdd form, string file)
        {
            StreamReader strReader = new StreamReader(file);
            string FlagFileNameOnly = Path.GetFileNameWithoutExtension(sbdd.InputFilePath) + "_flag" + Path.GetExtension(sbdd.InputFilePath);
            FlagFileName = sbdd.WorkingDir + "\\" + FlagFileNameOnly;

            if (File.Exists(FlagFileName)) { File.Delete(FlagFileName); }
            StreamWriter strWriter = new StreamWriter(new FileStream(FlagFileName, FileMode.Create));
            
            #region modify child gates which are flags

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                if (String.Equals(Line, "ENDTREE")) { break; }
                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    if (FlagEvent.Count > 0)
                    {
                        string[] LineSplit = Line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                        
                        // change child gates which are flags
                        for (int j = 0; j < LineSplit.Length; j++)
                        {
                            for (int k = 0; k < FlagEvent.Count; k++)
                            {
                                if (LineSplit[j] == FlagEvent[k].GateName)
                                {
                                    if (FlagEvent[k].FlagTrue) LineSplit[j] = "TRUE";
                                    else LineSplit[j] = "FALSE";
                                }
                            }
                        }

                        // make new line and write
                        string NewLine = String.Empty;
                        for (int i = 0; i < LineSplit.Length; i++) NewLine += LineSplit[i] + " ";
                        strWriter.WriteLine(NewLine);
                    }
                    else
                    {
                        strWriter.WriteLine(Line);
                    }
                }
                else
                {
                    strWriter.WriteLine(Line);
                }
            }

            #endregion

            #region write rest of original file

            strWriter.WriteLine("ENDTREE");

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                strWriter.WriteLine(Line);
            }

            #endregion
            
            strReader.Close();
            strWriter.Close();
        }

        public static void ReadFlagBlock(StreamReader strReader)
        {
            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                string[] LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                if (String.Equals(LineSplit[0], "LIMIT")) break;
            }

            while (!strReader.EndOfStream)
            {
                string Line = strReader.ReadLine();
                if (String.IsNullOrEmpty(Line)) continue;

                string[] LineSplit = Line.Split(new char[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries);

                if (!String.Equals(Line.Substring(0, 1), "*"))
                {
                    if (Line == "TRUE") { FlagTrue = true; continue; }
                    if (Line == "FALSE") { FlagTrue = false; continue; }

                    FlagGate NewFlagGate;
                    NewFlagGate.GateName = LineSplit[0];
                    NewFlagGate.FlagTrue = FlagTrue;
                    FlagEvent.Add(NewFlagGate);
                }
            }
        }

    }
}
