﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using System.IO;
using System.Linq;

namespace STPATool
{
    public partial class MainForm : Form
    {
        public struct ControlAction
        {
            public string Type;
            public string Name;
            public int ID;
            public List<string> Comp;
        }

        public struct Feedback
        {
            public string Type;
            public string Name;
            public int ID;
            public List<int> CALink;
            public List<string> Comp;
        }

        public struct Component
        {
            public string Name;
            public string Desc;
            public List<string> Comp;
        }

        public MainForm()
        {
            InitializeComponent();
            chkInitFilter.Checked = true;
        }

        public static List<Feedback> FB; // feedback list (all)
        public static List<ControlAction> CA; // control action (all)
        public static List<Feedback> FBSig; // feedback list (remove duplicate)
        public static List<Component> Comp;

        public static List<string> Cont; // controller list (all)
        public static List<string> ContSel; // controller list (selected)

        public static List<int> CASel; // control action (selected)

        public static List<Feedback> FBSel; // feedback list (selected)
        public static List<string> FBSigSel; // feedback list (remove duplicate, selected)
        
        public static List<Feedback> FBSelbF = new List<Feedback>(); // before filter
        public static List<Feedback> FBSelaF = new List<Feedback>(); // after filter
        
        public static int maxcol; // max number of columns for component
        public static int[] CompNV; // number of visit for component
        public static double[] CompProp; // propagation value for component
        public static double[] CompIM; // importance measure

        private void BtnLoadCS_Click(object sender, EventArgs e)
        {
            FB = new List<Feedback>();        
            CA = new List<ControlAction>();
            FBSig = new List<Feedback>(); 
            Comp = new List<Component>();

            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Multiselect = true;
                ofd.Filter = "CA/FB/Controller files (kca, kfb, kcp)|*.kca;*.kfb;*.kcp";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    maxcol = 0;
                    foreach (string filename in ofd.FileNames)
                    {
                        string InputFilePath = filename;
                        string InputFileExt = Path.GetExtension(filename);
                        
                        if (InputFileExt == ".kca")
                        {
                            #region read CA file

                            StreamReader strReader = new StreamReader(InputFilePath);

                            while (!strReader.EndOfStream)
                            {
                                string Line = strReader.ReadLine();
                                string[] LineSplit = Line.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
                                ControlAction rt = new ControlAction();

                                string[] LineSplit0Split = LineSplit[0].Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                                rt.Type = LineSplit0Split[0];
                                rt.ID = Int32.Parse(LineSplit0Split[1]);

                                rt.Name = LineSplit[1];
                                
                                if (maxcol < LineSplit.Length - 2) { maxcol = LineSplit.Length - 2; }
                                List<string> comp = new List<string>();
                                for (int i = 2; i < LineSplit.Length; i++) comp.Add(LineSplit[i]);
                                rt.Comp = comp;
                                CA.Add(rt);                                
                            }

                            strReader.Close();

                            #endregion
                        }
                        else if(InputFileExt == ".kfb")                        
                        {
                            #region read FB file

                            StreamReader strReader = new StreamReader(InputFilePath);

                            while (!strReader.EndOfStream)
                            {
                                string Line = strReader.ReadLine();
                                string[] LineSplit = Line.Split(new char[] { '/' });
                                Feedback rt = new Feedback();

                                string[] FBName = LineSplit[0].Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                                rt.Type = FBName[0];
                                rt.ID = Int32.Parse(FBName[1]);

                                // relation to ca
                                string[] CALinkList = LineSplit[1].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                rt.CALink = new List<int>();
                                for (int i = 0; i < CALinkList.Length; i++)
                                {
                                    string[] CA_ID = CALinkList[i].Split(new char[] { '-'}, StringSplitOptions.RemoveEmptyEntries);
                                    rt.CALink.Add(Int32.Parse(CA_ID[1]));
                                }
                                
                                rt.Name = LineSplit[2];
                                
                                if (maxcol < LineSplit.Length - 3) { maxcol = LineSplit.Length - 3; }
                                List<string> comp = new List<string>();
                                for (int i = 3; i < LineSplit.Length - 1; i++) comp.Add(LineSplit[i]);
                                rt.Comp = comp;
                                FB.Add(rt);
                                if (FBSig.FindIndex(x => x.Name == rt.Name) < 0) { FBSig.Add(rt); }
                            }

                            strReader.Close();

                            #endregion
                        }
                        else // ".kcp"
                        {
                            #region read component file

                            StreamReader strReader = new StreamReader(filename);

                            while (!strReader.EndOfStream)
                            {
                                string Line = strReader.ReadLine();

                                if (!String.Equals(Line.Substring(0, 1), "*"))
                                {
                                    string[] LineSplit = Line.Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
                                    Component comp = new Component();
                                    comp.Name = LineSplit[0];
                                    comp.Desc = LineSplit[1];
                                    List<string> temp = new List<string>();
                                    for (int i = 2; i < LineSplit.Length; i++) temp.Add(LineSplit[i]);
                                    comp.Comp = temp;
                                    Comp.Add(comp);
                                }
                            }

                            #endregion
                        }
                        
                    }
                }


                #region Show table

                // controller

                DataTable table = new DataTable();
                table.Columns.Add("Controller", typeof(string));
                List<object> valueList = new List<object>();
                foreach (var array in CA)
                {
                    if (!valueList.Contains(array.Comp[0]))
                    {
                        object[] values = new object[1];
                        values[0] = array.Comp[0];
                        table.Rows.Add(values);
                        valueList.Add(array.Comp[0]);
                    }
                }

                DGV_CT.DataSource = table;

                // Control action

                table = new DataTable();
                table.Columns.Add("Description", typeof(string));
                for (int i = 0; i < maxcol; i++) { table.Columns.Add($"Component{i + 1}", typeof(string)); }
                foreach (var array in CA)
                {
                    object[] values = new object[array.Comp.Count + 1];
                    values[0] = array.Name;
                    for (int i = 1; i < values.Length; i++) { values[i] = array.Comp[i - 1]; }
                    table.Rows.Add(values);
                }

                DGV_CA.DataSource = table;

                // Feedback

                table = new DataTable();
                table.Columns.Add("Description", typeof(string));
                for (int i = 0; i < maxcol; i++) { table.Columns.Add($"Component{i + 1}", typeof(string)); }
                foreach (var array in FB)
                {
                    object[] values = new object[array.Comp.Count + 1];
                    values[0] = array.Name;
                    for (int i = 1; i < values.Length; i++) { values[i] = array.Comp[i - 1]; }
                    table.Rows.Add(values);
                }

                DGV_FB.DataSource = table;

                #endregion
            }

        }
        
        private void btnSelCont_Click(object sender, EventArgs e) // -> Cont, ContSel
        {
            Cont = new List<string>();
            ContSel = new List<string>();

            foreach (var array in CA) Cont.Add(array.Comp[0]);

            SelectCont selectcont = new SelectCont();
            selectcont.ShowDialog();

            // foreach (object itemChecked in selectcont.LB_CT.CheckedItems) ContSel.Add((string)itemChecked);

            #region show table

            DataTable table = new DataTable();
            table.Columns.Add("Controller", typeof(string));

            foreach (object itemChecked in selectcont.LB_CT.CheckedItems)
            {
                ContSel.Add((string)itemChecked);
                table.Rows.Add((string)itemChecked);
            }

            DGV_CT.DataSource = table;
            #endregion
        }

        private void BtnSelCA_Click(object sender, EventArgs e) // -> CASel
        {
            CASel = new List<int>();

            SelectCA selectCA = new SelectCA();
            selectCA.ShowDialog();
            
            DataTable table = new DataTable();
            table.Columns.Add("Description", typeof(string));
            for (int i = 0; i < maxcol; i++) { table.Columns.Add($"Component{i + 1}", typeof(string)); }

            foreach (object itemChecked in selectCA.LB_CA.CheckedItems)
            {
                foreach (var array in CA)
                {
                    object[] values = new object[array.Comp.Count + 1];
                    if (array.Name == (string)itemChecked)
                    {
                        values[0] = array.Name;
                        for (int i = 1; i < values.Length; i++) { values[i] = array.Comp[i - 1]; }
                        table.Rows.Add(values);
                        CASel.Add(array.ID);
                    }
                }
            }

            DGV_CA.DataSource = table;
        }

        private void BtnSelFB_Click(object sender, EventArgs e)
        {
            FBSigSel = new List<string>();
            FBSel = new List<Feedback>();

            SelectFB selectFB = new SelectFB();
            selectFB.ShowDialog();

            DataTable table = new DataTable();
            table.Columns.Add("Description", typeof(string));
            for (int i = 0; i < maxcol; i++) { table.Columns.Add($"Component{i + 1}", typeof(string)); }
            
            foreach (object itemChecked in selectFB.LB_FB.CheckedItems)
            {
                FBSigSel.Add((string)itemChecked);
                foreach (var array in FB)
                {
                    object[] values = new object[array.Comp.Count + 1];
                    
                    if (array.Name == (string)itemChecked && ContSel.Contains(array.Comp[array.Comp.Count-1]))
                    {
                        values[0] = array.Name;
                        for (int i = 1; i < values.Length; i++) { values[i] = array.Comp[i - 1]; }
                        table.Rows.Add(values);
                        FBSel.Add(array);
                    }
                    
                }
            }
            
            DGV_FB.DataSource = table;
        }
        
        private void BtnCalc_Click(object sender, EventArgs e)
        {
            CompNV = new int[Comp.Count];
            CompProp = new double[Comp.Count];
            CompIM = new double[Comp.Count];

            if (!FBSelaF.Any())
            {
                for (int i = 0; i < FBSel.Count; i++) FBSelaF.Add(FBSel[i]);
            }

            #region calculate number of visit

            for (int i = 0; i < FBSelaF.Count; i++)
            {
                for (int j = 0; j < FBSelaF[i].Comp.Count; j++)
                {
                    string RouteCompName = FBSelaF[i].Comp[j];
                    for (int k = 0; k < Comp.Count; k++)
                    {
                        for (int l = 0; l < Comp[k].Comp.Count; l++)
                        {
                            string CompCompName = Comp[k].Comp[l];
                            if (CompCompName == RouteCompName) CompNV[k]++;
                        }
                    }
                }
            }

            #endregion

            #region calculate propagation

            for (int k = 0; k < Comp.Count; k++)
            {
                int[] CompSigFail = Enumerable.Repeat(1, FBSigSel.Count).ToArray();
                for (int i = 0; i < FBSigSel.Count; i++)
                {
                    for (int j = 0; j < FBSelaF.Count; j++)
                    {
                        if (!(FBSelaF[j].Name == FBSigSel[i])) continue;

                        if (FBSelaF[j].Comp.Intersect(Comp[k].Comp).Any()) { CompSigFail[i] *= 1; }
                        else { CompSigFail[i] *= 0; }
                    }
                }
                CompProp[k] = (double)CompSigFail.Sum() / FBSigSel.Count;
            }

            #endregion

            #region calculate importance measure

            for (int i = 0; i < Comp.Count; i++) CompIM[i] = CompNV[i] * CompProp[i];

            #endregion

            #region report result

            ResultCalc resultcalc = new ResultCalc();
            resultcalc.ShowDialog();

            #endregion

            FBSelaF = new List<Feedback>();

        }

        private void BtnSelect_Click(object sender, EventArgs e)
        {
            string Filter1 = txtFilter1.Text;
            string Filter1Cond = cbFilter1Cond.Text;
            string Filter2 = txtFilter2.Text;
            string Filter2Cond = cbFilter2Cond.Text;
            string FilterLogic = String.Empty;
            if (radAND.Checked) { FilterLogic = "AND"; }
            if (radOR.Checked) { FilterLogic = "OR"; }

            #region define FBSelbF

            if (chkInitFilter.Checked)
            {
                FBSelbF = new List<Feedback>();
                for (int i = 0; i < FBSel.Count; i++) FBSelbF.Add(FBSel[i]);
                FBSelaF = new List<Feedback>();
            }
            else
            {
                FBSelbF = new List<Feedback>();
                for (int i = 0; i < FBSelaF.Count; i++) FBSelbF.Add(FBSelaF[i]);
                FBSelaF = new List<Feedback>();
            }

            #endregion

            if (string.IsNullOrEmpty(Filter1) && string.IsNullOrEmpty(Filter2)) // if no filter, FBSelbF -> FBSelaF
            {
                for (int i = 0; i < FBSelbF.Count; i++) FBSelaF.Add(FBSelbF[i]);
            }
            else if (string.IsNullOrEmpty(Filter2))  // if only filter1 entered, FBSelbF (with filter 1) -> FBSelaF
            {
                for (int i = 0; i < FBSelbF.Count; i++)
                {
                    if (Filter1Cond == "Included")
                    {
                        if (FBSelbF[i].Comp.Contains(Filter1)) { FBSelaF.Add(FBSelbF[i]); }
                    }
                    else
                    {
                        if (!FBSelbF[i].Comp.Contains(Filter1)) { FBSelaF.Add(FBSelbF[i]); }
                    }
                }
            }
            else if (string.IsNullOrEmpty(Filter1)) // if only filter2 entered, FBSelbF (with filter 2) -> FBSelaF
            {
                for (int i = 0; i < FBSelbF.Count; i++)
                {
                    if (Filter2Cond == "Included")
                    {
                        if (FBSelbF[i].Comp.Contains(Filter2)) { FBSelaF.Add(FBSelbF[i]); }
                    }
                    else
                    {
                        if (!FBSelbF[i].Comp.Contains(Filter2)) { FBSelaF.Add(FBSelbF[i]); }
                    }
                }
            }
            else // if both filter1, filter2 entered, FBSelbF (with filter 1 AND/OR filter 2) -> FBSelaF
            {
                for (int i = 0; i < FBSelbF.Count; i++)
                {
                    bool FBSelFilInc1 = false;
                    bool FBSelFilInc2 = false;

                    if (Filter1Cond == "Included")
                    {
                        if (FBSelbF[i].Comp.Contains(Filter1)) { FBSelFilInc1 = true; }
                        else { FBSelFilInc1 = false; }
                    }
                    else
                    {
                        if (!FBSelbF[i].Comp.Contains(Filter1)) { FBSelFilInc1 = true; }
                        else { FBSelFilInc1 = false; }
                    }

                    if (Filter2Cond == "Included")
                    {
                        if (FBSelbF[i].Comp.Contains(Filter2)) { FBSelFilInc2 = true; }
                        else { FBSelFilInc2 = false; }
                    }
                    else
                    {
                        if (!FBSelbF[i].Comp.Contains(Filter2)) { FBSelFilInc2 = true; }
                        else { FBSelFilInc2 = false; }
                    }

                    bool FBSelFilInc = false;

                    if (FilterLogic == "AND") { FBSelFilInc = FBSelFilInc1 & FBSelFilInc2; }
                    else // FilterLogic == "OR"
                    {
                        FBSelFilInc = FBSelFilInc1 | FBSelFilInc2;
                    }

                    if (FBSelFilInc) FBSelaF.Add(FBSelbF[i]);
                }
            }

            #region show table

            DataTable table = new DataTable();
            table.Columns.Add("Description", typeof(string));
            for (int i = 0; i < maxcol; i++) { table.Columns.Add($"Component{i + 1}", typeof(string)); }

            foreach (var array in FBSelaF)
            {
                object[] values = new object[array.Comp.Count + 1];
                values[0] = array.Name;
                for (int i = 1; i < values.Length; i++) { values[i] = array.Comp[i - 1]; }
                table.Rows.Add(values);
            }
            DGV_FB.DataSource = table;

            #endregion
        }

        private void ChkInitFilter_CheckedChanged(object sender, EventArgs e)
        {
            if (chkInitFilter.Checked) { chkInitFilter.Text = "From selected FB list"; }
            else { chkInitFilter.Text = "From this FB list"; }
        }
    }
}
