﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Linq;

namespace sbdd
{

    #region struct used by program 

    public struct Event
    {
        public string Name;
        public char Type; // default: 0, B: 1, +: 2, *: 3, noom: 4
        public float Prob;
        public List<int> Child;
        public int BEOrder;
        public int ite;
        public int nite;
        public int ie;
        public int ContainsNegate;
    }

    public struct Gate
    {
        public string Name;
        public char Type;
        public List<string> Child;
    }

    public struct CircGate
    {
        public int Parent;
        public List<int> Child;
    }

    public struct NegGate
    {
        public int oIndex; // original gate index
        public int nIndex; // negation gate index
    }

    public struct FlagGate
    {
        public string GateName;
        public bool FlagTrue;
    }

    public struct ModGate
    {
        public int EventIndex; // Event ID of current module
        public int ite;
        public int nite;
        public List<List<int>> CutSet;
        public List<List<int>> nCutSet;
    }

    public struct GateProbExceedOne
    {
        public string EventName;
        public float EventProb;
    }

    public struct iteDef
    {
        public int x; // pivot
        public int l; // pointer - left
        public int r; // pointer - right
        public float prob; // probability
    }

    public struct XDataType
    {
        public string BlockName; // Block name
        public int NumOfEvent; // data block에 포함된 BE수
        public string[] EventName; // Event name
        public float[] EventProb; // Event prob.
    }

    public struct XaCutSetType
    {
        public int NoElem; // # of element
        public List<int> Elems; // Cutset의 element index
        public float CutProba;
    }
    
    public struct XCutsetType
    {
        public string BlockName; // block name
        public int NumOfCutSet; // # of cutset
        public List<XaCutSetType> XaCutSet; // 이걸 list로 변경.
    }

    public struct RAWfile
    {
        public XDataType XData;
        public XCutsetType XCutset;
    }

    #endregion

    public partial class sbdd : Form
    {
        public static string sbddTitle, sbddUsage;      // by Han
        public static string InputFileName, InputFilePath, InputFileExt, InputFileNamewoExt;
        public static string OutputFileName, OutputFilePath, WorkingDir, TopName;        
        public static int TopIndex, nCutset;
        public static string CmdTxt, RstTxt;
        public static float pCutset;
        public static Stopwatch ExeTime;
        public static Stopwatch BddSolveTime;
        public static Stopwatch ReadFTTime;
        public static Stopwatch OrderTime;
        public static Stopwatch CircProcTime;
        public static Stopwatch FlagProcTime;
        public static Stopwatch NegProcTime;
        public static Stopwatch CutOffTDTime;
        public static Stopwatch ModularTime;
        public static Stopwatch RestructTime;
        public static long MemUsed;
        public static int ExetoEnd;
        public static DateTime currentTime;        

        public sbdd()
        {
            InitializeComponent();
        }

        private void bddc_Shown(object sender, EventArgs e)
        {
            
            string[] args = Environment.GetCommandLineArgs();
            int argn = args.Length;

            if (argn < 2) // no argument entered
            {
                #region windows mode

                // Enable File Drag & Drop
                AllowDrop = true;
                DragEnter += new DragEventHandler(FileDragEnter);
                DragDrop += new DragEventHandler(FileDragDrop);

                SetWinFormOption();
                
                #endregion
                
                #region print version

                PrintVersion();

                ShowHelpWin();
                
                #endregion

            }
            else
            {
                #region command mode
                RunCmd(args, argn);

                if (Constants.waitmode == 0) this.Close();

                #endregion
            }
        }
        
        void FileDragEnter(object sender, DragEventArgs e)
        {
            #region get dropped file

            if (e.Data.GetDataPresent(DataFormats.FileDrop)) e.Effect = DragDropEffects.Copy;

            #endregion
        }

        void FileDragDrop(object sender, DragEventArgs e)
        {
            #region load FT file information

            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            InputFilePath = files[0];
            InputFileExt = Path.GetExtension(InputFilePath);
            InputFileNamewoExt = Path.GetFileNameWithoutExtension(InputFilePath);
            InputFileName = InputFileNamewoExt + InputFileExt;

            WorkingDir = Path.GetDirectoryName(sbdd.InputFilePath);

            OutputFilePath = InputFileNamewoExt + ".RAW";
            

            ClassFtData.LoadFT(InputFilePath);
            txtboxInFileName.Text = InputFileName;
            txtboxOutFileName.Text = OutputFilePath;
            txtboxTopEvent.Text = TopName;
            txtboxCutoff.Text = Constants.Cutoff.ToString();

            #endregion
        }
        
        private void BtnReadFile_Click(object sender, EventArgs e)
        {
                       
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    #region load FT file information

                    InputFilePath = ofd.FileName;
                    InputFileExt = Path.GetExtension(ofd.SafeFileName);
                    InputFileNamewoExt = Path.GetFileNameWithoutExtension(ofd.SafeFileName);
                    InputFileName = InputFileNamewoExt + InputFileExt;
                    WorkingDir = Path.GetDirectoryName(sbdd.InputFilePath);

                    ClassFtData.LoadFT(InputFilePath);

                    txtboxInFileName.Text = InputFileName;
                    txtboxOutFileName.Text = InputFileName.Substring(0, OutputFilePath.Length - 4) + ".Raw";
                    txtboxTopEvent.Text = TopName;
                    txtboxCutoff.Text = Constants.Cutoff.ToString();

                    #endregion
                }
            }
            
        }

        private void BtnSolve_Click(object sender, EventArgs e)
        {
            #region initialization

            txtboxCmd.Clear();
            this.Refresh();

            ExeTime = new Stopwatch();
            ExeTime.Start();

            Initialize();

            InputFileName = txtboxInFileName.Text;
            InputFilePath = WorkingDir + "\\" + InputFileName;

            OutputFileName = txtboxOutFileName.Text;
            OutputFilePath = WorkingDir + "\\" + OutputFileName;

            TopName = txtboxTopEvent.Text;

            Constants.LogFilePath = OutputFilePath.Substring(0, OutputFilePath.Length - 4) + ".sbdd.log";
            if (File.Exists(Constants.LogFilePath)) File.Delete(Constants.LogFilePath);

            Process currentProcess = System.Diagnostics.Process.GetCurrentProcess();
            long MemBefore = currentProcess.WorkingSet64 / 1024 / 1024;

            // write to log file
            // by Han
            sbdd.RstTxt += sbddTitle;

            //sbdd.CmdTxt = String.Empty;
            //sbdd.CmdTxt += "SBDD (Small BDD Solver for Fault Tree Analysis)" + Environment.NewLine;
            //sbdd.CmdTxt += "Version 1.0 (2021.04.30)" + Environment.NewLine;
            //sbdd.CmdTxt += "Copyright(C) 2021 KAERI, all rights reserved" + Environment.NewLine;
            //sbdd.CmdTxt += "Developed by Korea Atomic Energy Research Institute" + Environment.NewLine;
            //sbdd.CmdTxt += currentTime + Environment.NewLine + Environment.NewLine;

            //sbdd.RstTxt += sbdd.CmdTxt;
            //sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();
            
            #endregion

            #region check/set option

            if (radBdd.Checked == true) Constants.mcs = 'p';
            if (radMcs.Checked == true) Constants.mcs = 'c';
            // if (chkZBdd.Checked == true) Constants.mcs = 'z';

            if (radMF.Checked == true) Constants.beorder = 0;
            if (radTD.Checked == true) Constants.beorder = 1;
            if (radBU.Checked == true) Constants.beorder = 2;
            
            if (!UInt32.TryParse(txtboxMaxPICS.Text, out Constants.maxCutset))
            {
                txtboxCmd.AppendText("Invalid format or Overflow for # of PI/CS [" + txtboxMaxPICS.Text + "]" + Environment.NewLine);
                sbdd.CmdTxt += "Invalid format or Overflow for # of PI/CS [" + txtboxMaxPICS.Text + "]" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }

            if (Constants.maxCutset > 0) Constants.CutsetSort = true;
            else Constants.CutsetSort = false;

            //if (chkFTMod.Checked == true) Constants.modular = 1;
            //else Constants.modular = 0;

            //if (chkFTSim.Checked == true) Constants.simplify = 1;
            //else Constants.simplify = 0;

            sbdd.RstTxt += "---------- INPUT ----------" + Environment.NewLine;
            sbdd.RstTxt += "Input File : " + InputFileName + Environment.NewLine;
            sbdd.RstTxt += "Output File : " + Path.GetFileName(OutputFilePath) + Environment.NewLine;
            sbdd.RstTxt += "Top Name : " + TopName + Environment.NewLine;
            sbdd.RstTxt += "Cutoff (p) : " + Constants.Cutoff.ToString() + Environment.NewLine;
            sbdd.RstTxt += "Options" + Environment.NewLine;
            sbdd.RstTxt += "  r = " + Constants.mcs.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  n = " + Constants.maxCutset.ToString() + Environment.NewLine;
            // sbdd.RstTxt += "  m = " + Constants.modular.ToString() + Environment.NewLine;
            // sbdd.RstTxt += "  s = " + Constants.simplify.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  b = " + Constants.beorder.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  w = " + Constants.waitmode.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  o = " + Path.GetFileName(Constants.LogFilePath) + Environment.NewLine + Environment.NewLine;

            txtboxCmd.AppendText(sbdd.RstTxt);

            ClassRawFile.WriteLogFile();

            #endregion

            #region check cutoff value

            if (!Single.TryParse(txtboxCutoff.Text, out Constants.Cutoff))
            {
                txtboxCmd.AppendText("Invalid format for cutoff value [" + txtboxCutoff.Text + "]" + Environment.NewLine);
                sbdd.CmdTxt += "Invalid format for cutoff value [" + txtboxCutoff.Text + "]" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }

            #endregion

            #region read fault-tree information

            sbdd.RstTxt += "---------- CALCULATION ----------" + Environment.NewLine;
            txtboxCmd.AppendText(sbdd.RstTxt);
            ClassRawFile.WriteLogFile();

            ReadFTFile(false);

            #endregion

            #region check event probability

            CheckEventProb();

            #endregion

            #region check top name

            bool ValidTopName = CheckTopName(false); // -> TopIndex
            if (!ValidTopName) return;
            
            #endregion

            #region generate ites for BEs

            GenIteforBE();

            #endregion

            #region fault-tree restructure

            if (Constants.simplify == 1)
            {
                RestructTime = new Stopwatch();
                RestructTime.Start();

                txtboxCmd.AppendText("Restructuring ... ");
                sbdd.CmdTxt += "Restructuring ... ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;                
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                ClassFtRestruct.CheckRestruct(this, TopIndex);

                RestructTime.Stop();

                txtboxCmd.AppendText(RestructTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                sbdd.CmdTxt += RestructTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;                
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();
            }

            #endregion

            #region fault-tree modularization

            if (Constants.modular == 1)
            {
                ModularTime = new Stopwatch();
                ModularTime.Start();

                txtboxCmd.AppendText("Modularizing... ");
                sbdd.CmdTxt += "Modularizing... ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                DefineBEOrder();
                ClassModular.CheckModular(this, TopIndex);

                ModularTime.Stop();

                txtboxCmd.AppendText("(" + ModularTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                sbdd.CmdTxt += "(" + ModularTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

            }

            #endregion

            #region define gate/event order
            
            // gate ordering - bottom-up
            OrderTime = new Stopwatch();
            OrderTime.Start();

            txtboxCmd.AppendText("Defining gate/basic event(s) order ... ");
            sbdd.CmdTxt += "Defining gate/basic event(s) order ... ";
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            ClassFtOrder.DefineGateOrder(TopIndex);

            // basic event ordering
            DefineBEOrder();

            OrderTime.Stop();

            txtboxCmd.AppendText("(" + OrderTime.Elapsed.TotalSeconds + "sec)" + Environment.NewLine);
            sbdd.CmdTxt += "(" + OrderTime.Elapsed.TotalSeconds + "sec)" + Environment.NewLine;
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            #endregion

            #region solve bdd

            BddSolveTime = new Stopwatch();
            BddSolveTime.Start();

            txtboxCmd.AppendText("Solving for " + TopName + Environment.NewLine);
            sbdd.CmdTxt += "Solving for " + TopName + Environment.NewLine;
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            int pT;
            try { pT = ClassSolveGate.SolveTop(this); }
            catch (System.OutOfMemoryException)
            {
                txtboxCmd.AppendText(Environment.NewLine + "OutOfMemoryException during bdd solving (too many ites) ");
                sbdd.CmdTxt += Environment.NewLine + "OutOfMemoryException during bdd solving (too many ites) ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }

            txtboxCmd.AppendText("Solved for " + TopName + " ");
            sbdd.CmdTxt += "Solved for " + TopName + " ";
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            BddSolveTime.Stop();

            txtboxCmd.AppendText("(" + BddSolveTime.Elapsed.TotalSeconds.ToString() + "sec, # of ite : " + ClassIte.IteList.Count.ToString()  + ")" + Environment.NewLine);
            sbdd.CmdTxt += "(" + BddSolveTime.Elapsed.TotalSeconds.ToString() + "sec, # of ite : " + ClassIte.IteList.Count.ToString() + ")" + Environment.NewLine;
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            #endregion

            #region top event cutoff truncation

            // TdCutoff(pT);
            // if (Constants.zbdd == 0) { TdCutoff(pT); } // top-down

            #endregion

            #region save result

            try
            {   
                SaveResult(false);
            }
            catch (System.OutOfMemoryException)
            {
                txtboxCmd.AppendText(Environment.NewLine + "OutOfMemoryException during minimizing (too many ites) ");
                sbdd.CmdTxt += Environment.NewLine + "OutOfMemoryException during minimizing (too many ites) ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }

            currentProcess = System.Diagnostics.Process.GetCurrentProcess();
            long MemAfter = currentProcess.WorkingSet64 / 1024 / 1024;
            MemUsed = MemAfter - MemBefore; // Physical memory usage

            // txtboxCmd.AppendText($"Memory Usage : {MemUsed} MB" + Environment.NewLine); // Physical memory usage            
            txtboxCmd.AppendText("# of IteList : " + ClassIte.IteList.Count.ToString() + Environment.NewLine);
            txtboxCmd.AppendText("# of BddList : " + ClassBdd.BddList.Count.ToString() + Environment.NewLine);
            txtboxCmd.AppendText("# of MinBddDict : " + ClassMcs.MinBddDict.Count.ToString() + Environment.NewLine);
            txtboxCmd.AppendText(Environment.NewLine + "---------- END ----------" + Environment.NewLine);


            this.Refresh();

            // CmdTxt += "Memory Usage : " + MemUsed + " MB\n";
            CmdTxt += "# of IteList : " + ClassIte.IteList.Count + Environment.NewLine;
            CmdTxt += "# of BddList : " + ClassBdd.BddList.Count + Environment.NewLine;
            CmdTxt += "# of MinBddDict : " + ClassMcs.MinBddDict.Count + Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;

            CmdTxt += Environment.NewLine + "---------- END ----------" + Environment.NewLine;

            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();
            
            sbdd.RstTxt += Environment.NewLine + "---------- SUMMARY ----------" + Environment.NewLine;
            sbdd.RstTxt += "Input File :\t" + InputFileName + Environment.NewLine;
            sbdd.RstTxt += "RAW File :\t" + OutputFilePath + Environment.NewLine;
            sbdd.RstTxt += "Top Event :\t" + TopName + Environment.NewLine;
            sbdd.RstTxt += "Cutoff (p) :\t" + Constants.Cutoff.ToString("e6") + Environment.NewLine;
            if ('c'.Equals(Char.ToLower(Constants.mcs))) { sbdd.RstTxt += "# of MCS :\t" + nCutset.ToString() + Environment.NewLine; }
            else if ('p'.Equals(Char.ToLower(Constants.mcs))) { sbdd.RstTxt += "# of PI :\t" + nCutset.ToString() + Environment.NewLine; }
            else // 'z', zbdd
            {
                sbdd.RstTxt += "# of MCS :\t" + nCutset.ToString() + Environment.NewLine;
            }
            sbdd.RstTxt += "Value :\t" + pCutset.ToString("e6") + Environment.NewLine;
            sbdd.RstTxt += "Runtime :\t" + ExeTime.Elapsed.TotalSeconds.ToString("N4") + " sec" + Environment.NewLine;

            ClassRawFile.WriteLogFile();


            #endregion

        }

        private void RunCmd(string[] args, int argn)
        {

            #region initialization
            
            ExeTime = new Stopwatch();
            ExeTime.Start();            
            Initialize();
            
            Process currentProcess = System.Diagnostics.Process.GetCurrentProcess();
            long MemBefore = currentProcess.WorkingSet64 / 1024 / 1024;

            #endregion

            #region print version

            PrintVersion();

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;

            #endregion

            #region check option

            if (args[1] == "/help") { ShowHelpCmd(); return; }

            if (argn < 3) { // rawfile name not defined
                
                InputFileName = args[1].ToUpper();
                if (CheckInFileName(InputFileName)) return;

                OutputFilePath = InputFileName.Substring(0, InputFileName.Length - 4) + ".RAW";
                if (CheckOutFileName(OutputFilePath)) return;
            }
            else // rawfile name defined
            {
                // check input, output files
                InputFileName = args[1].ToUpper();
                if (CheckInFileName(InputFileName)) return;

                OutputFilePath = args[2].ToUpper();
                if (CheckOutFileName(OutputFilePath)) return;
            }
            
            Constants.LogFilePath = OutputFilePath.Substring(0, OutputFilePath.Length - 4) + ".sbdd.log";

            WorkingDir = System.Environment.CurrentDirectory;
            InputFilePath = WorkingDir + "\\" + InputFileName;
            if (File.Exists(InputFilePath))
            {
                ClassFtData.LoadFT(InputFilePath); // read top name, cutoff value from FT file
            }
            else
            {
                txtboxCmd.AppendText(Environment.NewLine + "Error: " + InputFileName + " not found");
                sbdd.CmdTxt += Environment.NewLine + "Error: " + InputFileName + " not found";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                return;
            }

            // check arguments

            if (argn > 3) { TopName = args[3].ToUpper(); }
            bool invalid_option = false;
            string invalid_option_msg = String.Empty;

            for (int i = 4; i < argn; i++)
            {
                if (args[i].Contains("p=")) // Cutoff
                {
                    string cutoffvalue = args[i].Split('=')[1];
                    if (!Single.TryParse(cutoffvalue, out Constants.Cutoff))
                    {
                        if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                        else invalid_option_msg += ", " + args[i];
                        invalid_option = true;
                    }
                }
                else if (args[i].Contains("r=")) // PI or CS
                {
                    Constants.mcs = Convert.ToChar(args[i].Split('=')[1]);
                    if (!"pcz".Contains(Constants.mcs))
                    {
                        if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                        else invalid_option_msg += ", " + args[i];
                        invalid_option = true;
                    }
                }
                else if (args[i].Contains("s=")) // FT simplification option
                {
                    Constants.simplify = Convert.ToInt32(args[i].Split('=')[1]);
                    if (Constants.simplify != 0 && Constants.simplify != 1)
                    {
                        if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                        else invalid_option_msg += ", " + args[i];
                        invalid_option = true;
                    }
                }
                else if (args[i].Contains("m=")) // FT modular option
                {
                    Constants.modular = Convert.ToInt32(args[i].Split('=')[1]);
                    if (Constants.modular != 0 && Constants.modular != 1)
                    {
                        if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                        else invalid_option_msg += ", " + args[i];
                        invalid_option = true;
                    }
                }
                else if (args[i].Contains("b=")) // BE ordering option (0: most-frequent, 1: top-down, 2: bottom-up)
                {
                    Constants.beorder = Convert.ToInt32(args[i].Split('=')[1]);
                    if (Constants.beorder != 0 && Constants.beorder != 1 && Constants.beorder != 2)
                    {
                        if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                        else invalid_option_msg += ", " + args[i];
                        invalid_option = true;
                    }
                }
                else if (args[i].Contains("w=")) // wait mode
                {
                    Constants.waitmode = Convert.ToInt32(args[i].Split('=')[1]);
                    if (Constants.waitmode != 0 && Constants.waitmode != 1)
                    {
                        if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                        else invalid_option_msg += ", " + args[i];
                        invalid_option = true;
                    }
                }
                else if (args[i].Contains("n=")) // max PI number
                {
                    Constants.CutsetSort = true;
                    Constants.maxCutset = Convert.ToUInt32(args[i].Split('=')[1]);
                    if (Constants.maxCutset < 1)    
                    { Constants.maxCutset = 0; }    // by Han
                    //{
                    //    if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                    //    else invalid_option_msg += ", " + args[i];
                    //    invalid_option = true;
                    //}
                }
                else if (args[i].Contains("o=")) // log file name
                {
                    Constants.LogFilePath = args[i].Split('=')[1] + ".sbdd.log";
                }
                else
                {
                    if (String.IsNullOrEmpty(invalid_option_msg)) invalid_option_msg += args[i];
                    else invalid_option_msg += ", " + args[i];
                    invalid_option = true;
                }
            }

            if (Constants.maxCutset > 0) Constants.CutsetSort = true;   // by Han
            else Constants.CutsetSort = false;

            if (File.Exists(Constants.LogFilePath)) File.Delete(Constants.LogFilePath);

            if (invalid_option)
            {
                txtboxCmd.AppendText(Environment.NewLine + "Error: Invalid option entered [" + invalid_option_msg + "], see /help" + Environment.NewLine);
                sbdd.CmdTxt += Environment.NewLine + "Error: Invalid option entered [" + invalid_option_msg + "], see /help" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();
                return;
            }

            sbdd.RstTxt += "---------- INPUT ----------" + Environment.NewLine;
            sbdd.RstTxt += "Input File : " + InputFileName + Environment.NewLine;
            sbdd.RstTxt += "Output File : " + Path.GetFileName(OutputFilePath) + Environment.NewLine;
            sbdd.RstTxt += "Top Name : " + TopName + Environment.NewLine;
            sbdd.RstTxt += "Cutoff (p) : " + Constants.Cutoff.ToString() + Environment.NewLine;
            sbdd.RstTxt += "Options" + Environment.NewLine;
            sbdd.RstTxt += "  r = " + Constants.mcs.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  n = " + Constants.maxCutset.ToString() + Environment.NewLine;
            // sbdd.RstTxt += "  m = " + Constants.modular.ToString() + Environment.NewLine;
            // sbdd.RstTxt += "  s = " + Constants.simplify.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  b = " + Constants.beorder.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  w = " + Constants.waitmode.ToString() + Environment.NewLine;
            sbdd.RstTxt += "  o = " + Path.GetFileName(Constants.LogFilePath) + Environment.NewLine + Environment.NewLine;
            ClassRawFile.WriteLogFile();

            #endregion

            #region set winform option

            txtboxInFileName.Text = InputFileName;
            txtboxOutFileName.Text = OutputFilePath;
            txtboxTopEvent.Text = TopName;
            txtboxCutoff.Text = Constants.Cutoff.ToString("e4");
            SetWinFormOption();

            // refresh form
            this.Refresh();

            #endregion

            #region read fault-tree information

            sbdd.RstTxt += "---------- CALCULATION ----------" + Environment.NewLine;
            ClassRawFile.WriteLogFile();
            
            ReadFTFile(true);
            
            #endregion

            #region check event probability

            CheckEventProb();
            this.Refresh();

            #endregion

            #region check top name

            bool ValidTopName = CheckTopName(true); // -> TopIndex
            if (!ValidTopName) return;

            #endregion

            #region generate ites for BEs

            GenIteforBE();

            #endregion

            #region fault-tree restructure

            if (Constants.simplify == 1)
            {
                RestructTime = new Stopwatch();
                RestructTime.Start();

                txtboxCmd.AppendText("Restructuring ... ");
                CmdTxt += "Restructuring ... ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                ClassFtRestruct.CheckRestruct(this, TopIndex);
                
                RestructTime.Stop();
                txtboxCmd.AppendText(RestructTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                CmdTxt += RestructTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

            }

            #endregion

            #region fault-tree modularization          

            if (Constants.modular == 1)
            {
                ModularTime = new Stopwatch();
                ModularTime.Start();

                txtboxCmd.AppendText("Modularizing... ");
                CmdTxt += "Modularizing... ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                DefineBEOrder();
                ClassModular.CheckModular(this, TopIndex);

                ModularTime.Stop();
                txtboxCmd.AppendText("(" + ModularTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
                CmdTxt += "(" + ModularTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

            }

            #endregion

            #region define gate/event order

            // gate ordering - bottom-up
            OrderTime = new Stopwatch();
            OrderTime.Start();

            txtboxCmd.AppendText("Defining gate/basic event(s) order ... ");
            CmdTxt += "Defining gate/basic event(s) order ... ";
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            ClassFtOrder.DefineGateOrder(TopIndex);

            // basic event ordering
            DefineBEOrder();
            OrderTime.Stop();
            
            txtboxCmd.AppendText("(" + OrderTime.Elapsed.TotalSeconds + "sec)" + Environment.NewLine);
            CmdTxt += "(" + OrderTime.Elapsed.TotalSeconds + "sec)" + Environment.NewLine;
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            #endregion

            #region solve bdd

            BddSolveTime = new Stopwatch();
            BddSolveTime.Start();

            txtboxCmd.AppendText("Solving for " + TopName + Environment.NewLine);
            sbdd.CmdTxt += "Solving for " + TopName + Environment.NewLine;
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            int pT;
            try { pT = ClassSolveGate.SolveTop(this); }
            catch (System.OutOfMemoryException)
            {
                txtboxCmd.AppendText("OutOfMemoryException (too many ites) " + Environment.NewLine);
                sbdd.CmdTxt += "OutOfMemoryException (too many ites)" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }
            txtboxCmd.AppendText("Solved for " + TopName + " ");
            sbdd.CmdTxt += "Solved for " + TopName + " ";
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            BddSolveTime.Stop();

            txtboxCmd.AppendText("(" + BddSolveTime.Elapsed.TotalSeconds.ToString() + "sec, # of ite : " + ClassIte.IteList.Count.ToString() + ")" + Environment.NewLine);
            sbdd.CmdTxt += "(" + BddSolveTime.Elapsed.TotalSeconds.ToString() + "sec, # of ite : " + ClassIte.IteList.Count.ToString() + ")" + Environment.NewLine;
            this.Refresh();

            sbdd.RstTxt += sbdd.CmdTxt;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            #endregion

            #region top event cutoff truncation

            // TdCutoff(pT);

            #endregion

            #region save/report result

            try
            {
                SaveResult(true);
            }
            catch (System.OutOfMemoryException)
            {
                txtboxCmd.AppendText("OutOfMemoryException (too many ites) ");
                CmdTxt += "OutOfMemoryException (too many ites)" + Environment.NewLine;

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }

            currentProcess = System.Diagnostics.Process.GetCurrentProcess();
            long MemAfter = currentProcess.WorkingSet64 / 1024 / 1024;
            MemUsed = MemAfter - MemBefore; // Physical memory usage
            // txtboxCmd.AppendText($"Memory Usage : {MemUsed} MB" + Environment.NewLine); // Physical memory usage            
            txtboxCmd.AppendText("# of IteList : " + ClassIte.IteList.Count.ToString() + Environment.NewLine);
            txtboxCmd.AppendText("# of BddList : " + ClassBdd.BddList.Count.ToString() + Environment.NewLine);
            txtboxCmd.AppendText("# of MinBddDict : " + ClassMcs.MinBddDict.Count.ToString() + Environment.NewLine);
            txtboxCmd.AppendText(Environment.NewLine + "---------- END ----------" + Environment.NewLine);

            // CmdTxt += "Memory Usage : " + MemUsed + " MB\n";
            CmdTxt += "# of IteList : " + ClassIte.IteList.Count + Environment.NewLine;
            CmdTxt += "# of BddList : " + ClassBdd.BddList.Count + Environment.NewLine;
            CmdTxt += "# of MinBddDict : " + ClassMcs.MinBddDict.Count + Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;

            CmdTxt += Environment.NewLine + "---------- END ----------" + Environment.NewLine;
            // Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
            ClassRawFile.WriteLogFile();

            sbdd.RstTxt += Environment.NewLine + "---------- SUMMARY ----------" + Environment.NewLine;
            sbdd.RstTxt += "Input File :\t" + InputFileName + Environment.NewLine;
            sbdd.RstTxt += "RAW File :\t" + OutputFilePath + Environment.NewLine;
            sbdd.RstTxt += "Top Event :\t" + TopName + Environment.NewLine;
            sbdd.RstTxt += "Cutoff (p) :\t" + Constants.Cutoff.ToString("e6") + Environment.NewLine;
            if ('c'.Equals(Char.ToLower(Constants.mcs))) { sbdd.RstTxt += "# of MCS :\t" + nCutset.ToString() + Environment.NewLine; }
            else if ('p'.Equals(Char.ToLower(Constants.mcs))) { sbdd.RstTxt += "# of PI :\t" + nCutset.ToString() + Environment.NewLine; }
            else // 'z', zbdd
            {
                sbdd.RstTxt += "# of MCS :\t" + nCutset.ToString() + Environment.NewLine;
            }
            sbdd.RstTxt += "Value :\t" + pCutset.ToString("e6") + Environment.NewLine;
            sbdd.RstTxt += "Runtime :\t" + ExeTime.Elapsed.TotalSeconds.ToString("N4") + " sec" + Environment.NewLine;

            ClassRawFile.WriteLogFile();
            
            ExetoEnd = 1;

            #endregion

        }

        private void PrintVersion()
        {
            // by Han
            txtboxCmd.AppendText(sbddTitle);
            this.Refresh();

            CmdTxt += sbddTitle;

            //currentTime = DateTime.Now;
                
            //// write to winform
            //txtboxCmd.AppendText("SBDD (Small BDD Solver for Fault Tree Analysis)" + Environment.NewLine);
            //txtboxCmd.AppendText("Version 1.0 (2021.05.11)" + Environment.NewLine);
            //txtboxCmd.AppendText("Copyright(C) 2021 KAERI, all rights reserved" + Environment.NewLine);
            //txtboxCmd.AppendText("Developed by Korea Atomic Energy Research Institute" + Environment.NewLine);            
            //txtboxCmd.AppendText(currentTime.ToString() + Environment.NewLine + Environment.NewLine);
            //this.Refresh();

            //// write to cmd
            //CmdTxt += "SBDD (Small BDD Solver for Fault Tree Analysis)" + Environment.NewLine;
            //CmdTxt += "Version 1.0 (2021.05.11)" + Environment.NewLine;
            //CmdTxt += "Copyright(C) 2021 KAERI, all rights reserved" + Environment.NewLine;
            //CmdTxt += "Developed by Korea Atomic Energy Research Institute" + Environment.NewLine;
            //CmdTxt += currentTime + Environment.NewLine + Environment.NewLine;

        }

        private void Initialize()
        {
            #region ClassFtData variables

            ClassFtData.XEvent = new List<Event>();
            ClassFtData.NegateBeRelationList = new List<NegGate>();
            ClassFtData.NegateBeIndexList = new List<int>();
            ClassFtData.EventProbExceedOneList = new List<GateProbExceedOne>();

            #endregion

            #region ClassFtFlag variables

            ClassFtFlag.FlagEvent = new List<FlagGate>();

            #endregion

            #region ClassFtCircular variables

            ClassFtCircular.XEvent_circ = new List<Event>();
            ClassFtCircular.CircularGatePathList = new List<List<int>>();
            ClassFtCircular.CircularTopName = new List<string>(); 
            ClassFtCircular.CircularGateTopPathList = new List<List<int>>();
            ClassFtCircular.CircularPathGates = new List<int>();
            ClassFtCircular.ExpandCircularList = new List<string>();
            ClassFtCircular.CircularTopList = new List<int>();
            ClassFtCircular.CircularGate = new List<CircGate>();

            #endregion

            #region ClassFtNegate variables

            ClassFtNegate.oGateList = new List<Gate>();
            ClassFtNegate.GateList = new List<Gate>();
            ClassFtNegate.NegateGateList = new List<string>();
            ClassFtNegate.NegateGateListDone = new List<string>();
            ClassFtNegate.WriteNegateGateList = new List<string>();
            ClassFtNegate.WriteNegateBEList = new List<string>();

            #endregion

            #region ClassFtOrder variables

            ClassFtOrder.SolveGateOrder = new List<int>();
            ClassFtOrder.BEOrder = new List<int>();
            ClassFtOrder.BEList = new List<int>();
            ClassFtOrder.BEDepth = new List<int>();
            ClassFtOrder.BEFreq = new List<int>();

            #endregion

            #region ClassIte variables

            ClassIte.IteList = new List<iteDef>();
            ClassIte.IteListDict = new MultiKeyDictionary<int, int, int, int>();
            // ClassIte.IteListDict = new Dictionary<ulong, int>();

            #endregion

            #region ClassBdd variables

            ClassBdd.BddList = new List<int>();
            ClassBdd.BddListDict = new MultiKeyDictionary<int, int, int, int>();
            // ClassBdd.BddListDict = new Dictionary<ulong, int>();

            #endregion

            #region ClassMcs variables

            ClassMcs.MinBddDict = new Dictionary<int, int>();
            ClassMcs.MinByDict = new MultiKeyDictionary<int, int, int>();
            // ClassMcs.MinByDict = new Dictionary<ulong, int>();

            #endregion

            #region ClassModular variables

            ClassModular.ModularGate = new List<ModGate>();
            ClassModular.ModularGateList = new List<int>();

            #endregion

            #region ClassSaveBdd variables

            ClassSaveBdd.PrimeImplicant = new RAWfile();
            ClassSaveBdd.XCutsetppPI = new List<XaCutSetType>();
            ClassSaveBdd.ModularGatePI = new List<List<int>>();

            #endregion

            #region ClassFtRestruct variables
            ClassFtRestruct.nReduceGate = 0;
            ClassFtRestruct.nAbsorbGate = 0;

            #endregion

            #region ClassSaveMcs variables

            ClassSaveMcs.MinimalCutSet = new RAWfile();
            ClassSaveMcs.XCutsetppMCS = new List<XaCutSetType>();
            ClassSaveMcs.ModularGateCutSet = new List<List<int>>();

            #endregion

        }

        private void ReadFTFile(bool CmdMod)
        {

            if (File.Exists(InputFilePath))
            {
                txtboxCmd.AppendText("Pre-processing for fault tree " + InputFileName + " ..." + Environment.NewLine);
                sbdd.CmdTxt += "Pre-processing for fault tree " + InputFileName + " ..." + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                string TempFilePath = InputFilePath;
                if (File.Exists(TempFilePath)) { TempFilePath += "000"; }

                for (int i = 0; i < 10000; i++)
                {
                    if (File.Exists(TempFilePath))
                    {
                        TempFilePath = TempFilePath.Substring(0, TempFilePath.Length - 3) + i.ToString("D3");
                    }
                    else { break; }
                }

                string oInputFilePath = InputFilePath;
                InputFilePath = TempFilePath;
                string nInputFilePath = InputFilePath;
                File.Copy(oInputFilePath, nInputFilePath);

                // copy file
                
                #region check for flag gates

                txtboxCmd.AppendText("Checking flag gates...  ");
                sbdd.CmdTxt += "Checking flag gates...  ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                ClassFtFlag.CheckFlag(this, InputFilePath);

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                #endregion

                #region check for circular gates

                txtboxCmd.AppendText("Checking circular gates...  ");
                sbdd.CmdTxt += "Checking circular gates...  ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                InputFilePath = ClassFtFlag.FlagFileName;
                ClassFtCircular.CheckCircular(this, InputFilePath, CmdMod);
                File.Delete(InputFilePath);
                
                #endregion

                #region check for negate gates

                txtboxCmd.AppendText("Checking negate gates...  ");
                sbdd.CmdTxt += "Checking negate gates...  ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                InputFilePath = ClassFtCircular.CircFileName;
                ClassFtNegate.CheckNegate(this, InputFilePath, CmdMod);
                File.Delete(InputFilePath);
                
                #endregion

                #region read fault-tree

                txtboxCmd.AppendText("Reading fault tree... ");
                sbdd.CmdTxt += "Reading fault tree... ";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                InputFilePath = ClassFtNegate.NegFileName;
                ClassFtData.ReadFT(this, InputFilePath);
                File.Delete(InputFilePath);
                File.Delete(nInputFilePath);
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                #endregion

            }
            else
            {
                txtboxCmd.AppendText("File [" + InputFileName + "] not found" + Environment.NewLine);
                sbdd.CmdTxt += "File [" + InputFileName + "] not found" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return;
            }
        }

        private void CheckEventProb()
        {

            if (ClassFtData.EventProbExceedOne)
            {
                Constants.oCutoff = Constants.Cutoff;
                Constants.Cutoff = Constants.Cutoff / ClassFtData.EventProbMax;
            }

        }

        private bool CheckTopName(bool CmdMod)
        {
            if (ClassFtData.XEvent.FindIndex(xEvent => xEvent.Name == TopName) > -1)
            {
                TopIndex = ClassFtData.GetEventIndex(TopName);
                return true;
            }
            else
            {
                txtboxCmd.AppendText("Error: Top Event [" + TopName + "] not found" + Environment.NewLine);
                sbdd.CmdTxt += "Error: Top Event [" + TopName + "] not found" + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                if(CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return false;
            }
        }
        
        private bool CheckInFileName(string InputFileName)
        {
            string[] InputFileNameSplit = InputFileName.Split('.');
            if (InputFileNameSplit.Length == 1 || String.Compare(InputFileNameSplit[InputFileNameSplit.Length - 1], "FTP", true) < 0)
            {
                txtboxCmd.AppendText(Environment.NewLine + "Error: [InFile] '" + InputFileName + "' has wrong extension (change to .FTP)");
                sbdd.CmdTxt += Environment.NewLine + "Error: [InFile] '" + InputFileName + "' has wrong extension (change to .FTP)";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return true;
            }
            else
            {
                return false;
            }
        }

        private void sbdd_Load(object sender, EventArgs e)
        {
            // By Han
            currentTime = DateTime.Now;

            sbddTitle = String.Empty;
            sbddTitle += "SBDD (Small BDD Solver for Fault Tree Analysis)" + Environment.NewLine;
            sbddTitle += "Version 1.0 (2021.5.12)" + Environment.NewLine;
            sbddTitle += "Copyright(C) 2021 KAERI, all rights reserved" + Environment.NewLine;
            sbddTitle += "Developed by Korea Atomic Energy Research Institute" + Environment.NewLine;
            sbddTitle += currentTime + Environment.NewLine + Environment.NewLine;

            sbddUsage = "Usage (cmd): sbdd FtpFile [RawFile] [TopEvent] [Options]" + Environment.NewLine;
            sbddUsage += "  FtpFile : Fault-tree file name" + Environment.NewLine;
            sbddUsage += "  RawFile : Output file name (Default: FtpFile.Raw)" + Environment.NewLine;
            sbddUsage += "  Top Event : Top event name (Default: define in FTP File)" + Environment.NewLine;
            sbddUsage += "  Options" + Environment.NewLine;
            sbddUsage += "     p= 1e-11 : Cutoff (Default: defined in FTP file)" + Environment.NewLine;
            sbddUsage += "     r= p|c : PI or CS (p - bdd (Default), c - mcs)" + Environment.NewLine;
            sbddUsage += "     n= 100000 : Max # of PI/CS to be saved (Default: n=100000)" + Environment.NewLine;
            sbddUsage += "     b= 0|1|2 : BE Ordering (0 - most-frequent (Default), 1 - top-down, 2 - bottom-up)" + Environment.NewLine;
            sbddUsage += "     w= 0|1: Interactive mode (0 - no wait (Default), 1 - wait in interactive mode)" + Environment.NewLine;
            sbddUsage += "     o= LogName: Log file name (LogName.sbdd.log, Default: [RawFile].sbdd.log)" + Environment.NewLine;

        }

        private bool CheckOutFileName(string OutputFileName)
        {
            string[] OutputFileNameSplit = OutputFileName.Split('.');
            if (OutputFileNameSplit.Length == 1 || String.Compare(OutputFileNameSplit[OutputFileNameSplit.Length - 1], "RAW", true) < 0)
            {
                txtboxCmd.AppendText(Environment.NewLine + "Error: [OutFile] '" + OutputFileName + "' has wrong extension (change to .RAW)");
                sbdd.CmdTxt += Environment.NewLine + "Error: [OutFile] '" + OutputFileName + "' has wrong extension (change to .RAW)";
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

                return true;
            }
            else
            {
                return false;
            }
        }

        private void GenIteforBE()
        {
            iteDef ite;
            ite.x = 0; ite.l = 1; ite.r = 0; ite.prob = 0.0f; // FALSE
            ClassIte.IteList.Add(ite);
            ite.x = 1; ite.l = 1; ite.r = 0; ite.prob = 1.0f; // TRUE
            ClassIte.IteList.Add(ite);

            for (int i = 2; i < ClassFtData.XEvent.Count; i++)
            {
                if (ClassFtData.XEvent[i].Child.Count == 0)
                {
                    Event Event;
                    Event = ClassFtData.XEvent[i];
                    Event.ite = ClassIte.CreateIte(i, 1, 0);
                    ClassFtData.XEvent[i] = Event;
                }
            }
        }

        private void DefineBEOrder()
        {
            if (Constants.beorder == 0) ClassFtOrder.DefineBEOrderMF(sbdd.TopIndex);
            if (Constants.beorder == 1) ClassFtOrder.DefineBEOrderTD(sbdd.TopIndex, 0);
            if (Constants.beorder == 2) ClassFtOrder.DefineBEOrderBU(sbdd.TopIndex, 0);
        }
        
        private void TdCutoff(int pT)
        {
            if (ClassFtData.EventProbExceedOne)
            {
                txtboxCmd.AppendText("Event (");
                for (int i = 0; i < ClassFtData.EventProbExceedOneList.Count; i++)
                {
                    if (i == ClassFtData.EventProbExceedOneList.Count - 1)
                    {
                        txtboxCmd.AppendText(ClassFtData.EventProbExceedOneList[i].EventName);
                    }
                    else
                    {
                        txtboxCmd.AppendText(ClassFtData.EventProbExceedOneList[i].EventName + ", ");
                    }
                }
                txtboxCmd.AppendText(") probability exceeds 1 ... " + Environment.NewLine);
                txtboxCmd.AppendText("Truncation (normalized by " + ClassFtData.EventProbMax.ToString() + ") for " + TopName + " by " + Constants.oCutoff.ToString("e4") + " ... ");
                this.Refresh();

            }
            else
            {
                txtboxCmd.AppendText("Truncation for " + TopName + " by " + Constants.Cutoff.ToString("e4") + " ... ");                
                sbdd.CmdTxt += "Cutoff (p)  : " + Constants.Cutoff.ToString("e4") + Environment.NewLine;
                this.Refresh();

                sbdd.RstTxt += sbdd.CmdTxt;
                // Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();

            }

            CutOffTDTime = new Stopwatch();
            CutOffTDTime.Start();

            try
            {
                if ('c'.Equals(Char.ToLower(Constants.mcs))) { pT = ClassCutOff.TdIteCutoffMCS(pT, 1.0f); }
                else if ('p'.Equals(Char.ToLower(Constants.mcs))) { pT = ClassCutOff.TdIteCutoffBDD(pT, 1.0f); }
                else { } // zbdd

                if ('c'.Equals(Char.ToLower(Constants.mcs))) { pT = ClassCutOff.TdIteCutoffMCS(pT, 1.0f); }
                else if ('p'.Equals(Char.ToLower(Constants.mcs))) { pT = ClassCutOff.TdIteCutoffBDD(pT, 1.0f); }
                else // zbdd
                {
                    pT = ClassCutOff.TdIteCutoffMCS(pT, 1.0f);
                }
            }
            catch (System.OutOfMemoryException)
            {
                txtboxCmd.AppendText("OutOfMemoryException (too many ites) ");
                return;
            }

            CutOffTDTime.Stop();
            txtboxCmd.AppendText("(" + CutOffTDTime.Elapsed.TotalSeconds.ToString() + "sec)" + Environment.NewLine);
            this.Refresh();

            Event Event = ClassFtData.XEvent[sbdd.TopIndex];
            Event.ite = pT;
            ClassFtData.XEvent[sbdd.TopIndex] = Event;

        }

        private void SaveResult(bool CmdMod)
        {
            
            if ('c'.Equals(Char.ToLower(Constants.mcs)))
            {
                if (File.Exists(OutputFilePath)) File.Delete(OutputFilePath);
                ClassSaveMcs.SaveMCS(this, TopName, OutputFilePath, CmdMod);
                
                ExeTime.Stop();

                // by Han
                string sResult = Environment.NewLine + "---------- RESULT ----------" + Environment.NewLine;
                sResult += "Value : " + pCutset.ToString("e6") + Environment.NewLine;

                
                if (sbdd.nCutset == ClassSaveMcs.XCutsetppMCS.Count)
                {
                    sResult += "# of cutsets : " + nCutset.ToString() + Environment.NewLine;
                }
                else
                {
                    sResult += "# of cutsets saved : " + nCutset.ToString() + Environment.NewLine;
                    sResult += "# of cutsets generated : " + ClassSaveMcs.XCutsetppMCS.Count.ToString() + Environment.NewLine;
                }

                sResult += "Runtime : " + ExeTime.Elapsed.TotalSeconds.ToString("N4") + " sec" + Environment.NewLine;
                txtboxCmd.AppendText(sResult);
                this.Refresh();

                sbdd.RstTxt += sResult;
                
                //sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();
                
            }
            else if('p'.Equals(Char.ToLower(Constants.mcs)))
            {
                if (File.Exists(OutputFilePath)) File.Delete(OutputFilePath);
                ClassSaveBdd.SaveBDD(this, TopName, OutputFilePath, CmdMod);
                
                ExeTime.Stop();

                // by Han
                string sResult = Environment.NewLine + "---------- RESULT ----------" + Environment.NewLine;
                sResult += "Value : " + pCutset.ToString("e6") + Environment.NewLine;

                if (sbdd.nCutset == ClassSaveBdd.XCutsetppPI.Count)
                {
                    sResult += "# of prime implicants : " + nCutset.ToString() + Environment.NewLine;
                }
                else
                {
                    sResult += "# of prime implicants saved : " + sbdd.nCutset.ToString() + Environment.NewLine;
                    sResult += "# of prime implicants generated : " + ClassSaveBdd.XCutsetppPI.Count.ToString() + Environment.NewLine;
                }
                
                sResult += "Runtime : " + ExeTime.Elapsed.TotalSeconds.ToString("N4") + " sec" + Environment.NewLine;
                txtboxCmd.AppendText(sResult);
                this.Refresh();

                sbdd.RstTxt += sResult;
                
                //sbdd.RstTxt += sbdd.CmdTxt;
                // if (CmdMod) Console.Write(sbdd.CmdTxt);
                sbdd.CmdTxt = String.Empty;
                ClassRawFile.WriteLogFile();
            }
            else // zbdd
            {

            }

        }

        private void SetWinFormOption() // show options in winform
        {

            // if ('p'.Equals(Char.ToLower(Constants.mcs))) radBdd.Checked = true;
            // else if ('c'.Equals(Char.ToLower(Constants.mcs))) radMcs.Checked = true;
            // else if ('z'.Equals(Char.ToLower(Constants.mcs))) { radMcs.Checked = true; chkZBdd.Checked = true; }
            // else { radBdd.Checked = false; radMcs.Checked = false; chkZBdd.Checked = false; }

            if ('p'.Equals(Char.ToLower(Constants.mcs))) radBdd.Checked = true;
            else if ('c'.Equals(Char.ToLower(Constants.mcs))) radMcs.Checked = true;            
            
            //if (Constants.simplify == 1) chkFTSim.Checked = true;
            //else if (Constants.simplify == 0) chkFTSim.Checked = false;

            //if (Constants.modular == 1) chkFTMod.Checked = true;
            //else if (Constants.modular == 0) chkFTMod.Checked = false;

            if (Constants.beorder == 0) radMF.Checked = true;
            else if (Constants.beorder == 1) radTD.Checked = true;
            else if (Constants.beorder == 2) radBU.Checked = true;

        }

        //private void ShowHelpWin()
        //{
        //    txtboxCmd.AppendText("[Input File] : Fault-tree file name (A.FTP)" + Environment.NewLine);
        //    txtboxCmd.AppendText("[Output File] : Output file name (A.RAW)" + Environment.NewLine);
        //    txtboxCmd.AppendText("[Top Event] : Top event name in [Input File] (TOP)" + Environment.NewLine);            
        //    txtboxCmd.AppendText("[PI/CS] : Solve for BDD or MCS (Default: Bdd)" + Environment.NewLine);
        //    txtboxCmd.AppendText("[BE ordering]" + Environment.NewLine);
        //    txtboxCmd.AppendText("  * Top-down : order BE closer to [Top Event]" + Environment.NewLine);
        //    txtboxCmd.AppendText("  * Bottom-up : order BE farther from [Top Event]" + Environment.NewLine);
        //    txtboxCmd.AppendText("  * Most-frequent : order BE by frequency" + Environment.NewLine);
        //    txtboxCmd.AppendText("[Options]" + Environment.NewLine);
        //    txtboxCmd.AppendText("  * Simplification : reduce/absorb child gates" + Environment.NewLine);
        //    txtboxCmd.AppendText("  * Modularization : modularize single occurence gates/BEs" + Environment.NewLine);
        //    txtboxCmd.AppendText("  * ZBDD : enable zero-BDD calculation" + Environment.NewLine);
        //    txtboxCmd.AppendText(Environment.NewLine);
        //    this.Refresh();
        //}

        private void ShowHelpWin()
        {
            //txtboxCmd.AppendText("[Input File] : Fault-tree file name (A.FTP)" + Environment.NewLine);
            //txtboxCmd.AppendText("[Output File] : Output file name (A.RAW)" + Environment.NewLine);
            //txtboxCmd.AppendText("[Top Event] : Top event name in [Input File] (TOP)" + Environment.NewLine);
            //txtboxCmd.AppendText("[PI/CS] : Solve for BDD or MCS (Default: Bdd)" + Environment.NewLine);
            //txtboxCmd.AppendText("[BE ordering]" + Environment.NewLine);
            //txtboxCmd.AppendText("  * Top-down : order BE closer to [Top Event]" + Environment.NewLine);
            //txtboxCmd.AppendText("  * Bottom-up : order BE farther from [Top Event]" + Environment.NewLine);
            //txtboxCmd.AppendText("  * Most-frequent : order BE by frequency" + Environment.NewLine);
            //txtboxCmd.AppendText("[Options]" + Environment.NewLine);
            //txtboxCmd.AppendText("  * Simplification : reduce/absorb child gates" + Environment.NewLine);
            //txtboxCmd.AppendText("  * Modularization : modularize single occurence gates/BEs" + Environment.NewLine);
            //txtboxCmd.AppendText("  * ZBDD : enable zero-BDD calculation" + Environment.NewLine);
            //txtboxCmd.AppendText(Environment.NewLine);

            // by Han
            txtboxCmd.AppendText(sbddUsage + Environment.NewLine);
            this.Refresh();

            //txtboxCmd.AppendText("Usage (cmd): sbdd FtpFile [RawFile] [TopEvent] [Options]" + Environment.NewLine);
            //txtboxCmd.AppendText("  FtpFile : Fault-tree file name" + Environment.NewLine);
            //txtboxCmd.AppendText("  RawFile : Output file name (Default: FtpFile.Raw)" + Environment.NewLine);
            //txtboxCmd.AppendText("  Top Event : Top event name (Default: define in FTP File)" + Environment.NewLine);
            //txtboxCmd.AppendText("  [Options] " + Environment.NewLine);
            //txtboxCmd.AppendText("     /p= 1e-11 : Cutoff (Default: defined in FTP file)" + Environment.NewLine);
            //txtboxCmd.AppendText("     /r= p|c : PI or CS (p – bdd (Default), c – mcs)" + Environment.NewLine);
            //txtboxCmd.AppendText("     /n= 100000 : Max # of PI/CS to be saved (Default: n=100000)" + Environment.NewLine);
            //txtboxCmd.AppendText("     /b= 0|1|2 : BE Ordering (0 – most-frequent (Default), 1 – top-down, 2 – bottom-up)" + Environment.NewLine);            
            //txtboxCmd.AppendText("     /w= 0|1: Interactive mode (0 – no wait (Default), 1 – wait in interactive mode)" + Environment.NewLine);
            //txtboxCmd.AppendText("     /o= LogName: Log file name (LogName.sbdd.log, Default: [RawFile].sbdd.log)" + Environment.NewLine);

            //txtboxCmd.AppendText(Environment.NewLine);

            //this.Refresh();
        }

        private void ShowHelpCmd()
        {
            // by Han
            sbdd.CmdTxt += sbddUsage;

            //sbdd.CmdTxt += "Usage (cmd): sbdd FtpFile [RawFile] [TopEvent] [Options]" + Environment.NewLine;
            //sbdd.CmdTxt += "  FtpFile : Fault-tree file name" + Environment.NewLine;
            //sbdd.CmdTxt += "  RawFile : Output file name (Default: FtpFile.Raw)" + Environment.NewLine;
            //sbdd.CmdTxt += "  Top Event : Top event name (Default: define in FTP File)" + Environment.NewLine;
            //sbdd.CmdTxt += "  [Options] " + Environment.NewLine;
            //sbdd.CmdTxt += "     /p= 1e-11 : Cutoff (Default: defined in FTP file)" + Environment.NewLine;
            //sbdd.CmdTxt += "     /r= p|c : PI or CS (p - bdd (Default), c - mcs)" + Environment.NewLine;
            //sbdd.CmdTxt += "     /n= 100000 : Max # of PI/CS to be saved (Default: n=100000)" + Environment.NewLine;
            //sbdd.CmdTxt += "     /b= 0|1|2 : BE Ordering (0 - most-frequent (Default), 1 - top-down, 2 - bottom-up)" + Environment.NewLine;
            //sbdd.CmdTxt += "     /w= 0|1: Interactive mode (0 - no wait (Default), 1 - wait in interactive mode)" + Environment.NewLine;
            //sbdd.CmdTxt += "     /o= LogName: Log file name (LogName.sbdd.log, Default: [RawFile].sbdd.log)" + Environment.NewLine;

            //sbdd.CmdTxt += Environment.NewLine;

            sbdd.RstTxt += sbdd.CmdTxt;
            Console.Write(sbdd.CmdTxt);
            sbdd.CmdTxt = String.Empty;
        }

    }
}
